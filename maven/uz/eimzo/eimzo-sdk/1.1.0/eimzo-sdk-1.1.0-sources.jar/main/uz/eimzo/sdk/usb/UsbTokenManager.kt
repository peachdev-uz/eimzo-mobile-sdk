package uz.eimzo.sdk.usb

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.ftsafe.DK
import com.ftsafe.readerScheme.FTException
import com.ftsafe.readerScheme.FTReader
import kotlinx.coroutines.suspendCancellableCoroutine
import uz.eimzo.sdk.crypto.HexUtils
import uz.yt.idcard.applet.android.EImzoAppletFactory
import uz.yt.idcard.applet.android.dto.FileType
import uz.yt.idcard.applet.android.dto.State
import uz.yt.idcard.applet.android.exception.InvalidUserPINException
import java.io.ByteArrayOutputStream
import java.util.concurrent.locks.ReentrantLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * USB token signing using FT Reader.
 *
 * Sign-only. USB tokens are NEVER persisted as saved keys — each sign
 * is a transient session: open FT session, wait for token + card insert,
 * verify PIN, sign the hash, tear the session down.
 *
 * Backed by FTReaderAPI_1.0.9.6.jar + applet-android-1.7.0-SNAPSHOT.jar
 * (under eimzo-sdk/libs/). Only ONE sign may be in flight at a time —
 * the FT reader native session is exclusive.
 */
class UsbTokenManager(private val context: Context) {

    private var ftReader: FTReader? = null
    private val lock = ReentrantLock()
    private val slotIndex = 0

    private var pendingContinuation: kotlin.coroutines.Continuation<UsbSignResult>? = null
    private var pendingPin: String? = null
    private var pendingSaHashRev: ByteArray? = null

    data class UsbSignResult(
        val serialNumber: String,
        val signature: String
    )

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                DK.USB_LOG -> {
                    if ((msg.obj as? String)?.contains("USB_PERMISSION") == true) {
                        try {
                            ftReader?.readerOpen(null)
                        } catch (e: FTException) {
                            pendingContinuation?.resumeWithException(e)
                        }
                    }
                }
                DK.USB_IN -> { /* USB inserted - handled by card event */ }
                DK.USB_OUT -> {
                    pendingContinuation?.resumeWithException(Exception("USB device disconnected"))
                }
                else -> {
                    if (msg.what and DK.CARD_IN_MASK == DK.CARD_IN_MASK) {
                        processCard()
                    }
                }
            }
        }
    }

    suspend fun sign(saHashRev: ByteArray, pin: String): UsbSignResult =
        suspendCancellableCoroutine { cont ->
            pendingContinuation = cont
            pendingPin = pin
            pendingSaHashRev = saHashRev

            try {
                ftReader?.readerClose()
                ftReader = FTReader(context, handler, 0)
                ftReader?.readerFind()
            } catch (e: FTException) {
                cont.resumeWithException(Exception("USB device not found: ${e.message}"))
            }
        }

    private fun processCard() {
        if (!lock.tryLock()) return
        try {
            ftReader?.readerPowerOn(slotIndex) ?: return
            val channel = ftReader?.let { FtCardChannel(it, slotIndex) } ?: return

            try {
                val eiaf = EImzoAppletFactory()
                val applet = eiaf.get(channel)
                val asi = applet.appletStateInfo

                if (asi.state == State.PERSONALIZED) {
                    val serialOut = ByteArrayOutputStream()
                    applet.readFile(FileType.SERIAL_NUMBER, serialOut)
                    val serialNumber = HexUtils.toHex(serialOut.toByteArray())

                    applet.validatePIN(pendingPin)
                    val signatureBytes = applet.signHash(pendingSaHashRev!!)
                    val signature = HexUtils.toHex(signatureBytes)

                    eiaf.deselect(channel)
                    pendingContinuation?.resume(UsbSignResult(serialNumber, signature))
                }
            } finally {
                channel.close()
                runCatching { ftReader?.readerPowerOff(slotIndex) }
            }
        } catch (e: InvalidUserPINException) {
            pendingContinuation?.resumeWithException(
                Exception("PIN_ERROR:${e.message}")
            )
        } catch (e: Exception) {
            pendingContinuation?.resumeWithException(e)
        } finally {
            lock.unlock()
        }
    }

    fun release() {
        runCatching { ftReader?.readerClose() }
    }
}
