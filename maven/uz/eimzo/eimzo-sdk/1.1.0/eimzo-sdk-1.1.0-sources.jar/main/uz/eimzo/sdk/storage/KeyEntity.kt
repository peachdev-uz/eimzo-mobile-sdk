package uz.eimzo.sdk.storage

import androidx.room.Entity
import androidx.room.PrimaryKey
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey

@Entity(tableName = "keys")
data class KeyEntity(
    @PrimaryKey val serialNumber: String,
    val name: String,
    val organization: String?,
    val uid: String?,
    val tin: String?,
    val pinfl: String?,
    val validFrom: String,
    val validTo: String,
    val validNow: Boolean,
    val qrData: String,
    val password: String?,
    val keyType: String,
    val isDefault: Boolean = false
) {
    /**
     * Hydrate into the in-memory [PfxKey] model. The `password` column on
     * disk is GCM-encrypted (see [PasswordCipher]); decryption happens
     * here so the rest of the SDK only ever sees the plaintext password
     * in RAM.
     */
    fun toPfxKey() = PfxKey(
        serialNumber = serialNumber,
        name = name,
        organization = organization,
        uid = uid,
        tin = tin,
        pinfl = pinfl,
        validFrom = validFrom,
        validTo = validTo,
        validNow = validNow,
        qrData = qrData,
        password = PasswordCipher.decrypt(password),
        keyType = KeyType.valueOf(keyType),
        isDefault = isDefault
    )

    companion object {
        /**
         * Persist a [PfxKey] back to Room. The password is GCM-encrypted
         * with an AndroidKeyStore-bound AES-256 key before it touches
         * SQLite, so even a rooted-device DB read yields ciphertext only.
         */
        fun fromPfxKey(key: PfxKey) = KeyEntity(
            serialNumber = key.serialNumber,
            name = key.name,
            organization = key.organization,
            uid = key.uid,
            tin = key.tin,
            pinfl = key.pinfl,
            validFrom = key.validFrom,
            validTo = key.validTo,
            validNow = key.validNow,
            qrData = key.qrData,
            password = key.password?.let(PasswordCipher::encrypt),
            keyType = key.keyType.name,
            isDefault = key.isDefault
        )
    }
}
