package uz.eimzo.sdk.fullui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.SignCallback
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.models.QrHashData
import uz.eimzo.sdk.models.SignResult

class HomeViewModel : ViewModel() {

    private val sdk = EImzoSDK.get()

    val keys = sdk.getAllKeys().asLiveData()

    private val _currentKey = MutableLiveData<PfxKey?>()
    val currentKey: LiveData<PfxKey?> = _currentKey

    private val _signState = MutableLiveData<SignState>(SignState.Idle)
    val signState: LiveData<SignState> = _signState

    private val _deepLink = MutableLiveData<String?>()
    val deepLink: LiveData<String?> = _deepLink

    // seconds remaining for session
    private val _sessionTimer = MutableLiveData(90)
    val sessionTimer: LiveData<Int> = _sessionTimer

    init {
        refreshCurrentKey()
    }

    fun refreshCurrentKey() {
        viewModelScope.launch {
            _currentKey.value = sdk.getDefaultKey() ?: sdk.getAllKeysList().firstOrNull()
        }
    }

    fun setDeepLink(uri: String?) {
        _deepLink.value = uri
    }

    fun setCurrentKey(key: PfxKey) {
        _currentKey.value = key
        viewModelScope.launch { sdk.setDefaultKey(key.serialNumber) }
    }

    fun signWithCurrentKey(password: String?) {
        val key = _currentKey.value ?: return
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading

        when (key.keyType) {
            KeyType.QR_PFX -> {
                sdk.signWithQrKey(key, dl, password, object : SignCallback {
                    override fun onSuccess(result: SignResult.Success) {
                        _signState.value = SignState.Success(result)
                    }
                    override fun onError(error: SignResult.Failure) {
                        _signState.value = SignState.Error(error.error)
                    }
                })
            }
            KeyType.NFC_ID -> {
                _signState.value = SignState.WaitingNfc
            }
            KeyType.USB_TOKEN -> {
                if (password != null) signWithUsb(password)
                else _signState.value = SignState.NeedPassword(KeyType.USB_TOKEN)
            }
        }
    }

    fun signWithUsb(pin: String) {
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading
        sdk.signWithUsbToken(pin, dl, object : SignCallback {
            override fun onSuccess(result: SignResult.Success) {
                _signState.value = SignState.Success(result)
            }
            override fun onError(error: SignResult.Failure) {
                _signState.value = SignState.Error(error.error)
            }
        })
    }

    fun signWithNfcTag(tag: android.nfc.Tag, pin: String) {
        val key = _currentKey.value ?: return
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading
        sdk.signWithNfc(tag, pin, dl, object : SignCallback {
            override fun onSuccess(result: SignResult.Success) {
                _signState.value = SignState.Success(result)
            }
            override fun onError(error: SignResult.Failure) {
                _signState.value = SignState.Error(error.error)
            }
        })
    }

    fun resetSignState() {
        _signState.value = SignState.Idle
    }

    sealed class SignState {
        object Idle : SignState()
        object Loading : SignState()
        object WaitingNfc : SignState()
        data class NeedPassword(val keyType: KeyType) : SignState()
        data class Success(val result: SignResult.Success) : SignState()
        data class Error(val message: String) : SignState()
    }
}
