package uz.eimzo.sdk.fullui.addkey

import android.net.Uri
import android.nfc.Tag
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.models.PfxKey

class AddKeyViewModel : ViewModel() {

    private val sdk = EImzoSDK.get()

    private val _state = MutableLiveData<AddKeyState>(AddKeyState.Idle)
    val state: LiveData<AddKeyState> = _state

    fun importPfxFile(
        context: android.content.Context,
        uri: Uri,
        password: String,
        savePassword: Boolean = true
    ) {
        _state.value = AddKeyState.Loading
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.readBytes()
                ?: throw Exception("Faylni o'qib bo'lmadi")
            Log.i("EImzoApp", "importPfxFile: bytes=${bytes.size}, save=$savePassword")
            sdk.importPfxKey(bytes, password, savePassword, object : ImportKeyCallback {
                override fun onSuccess(key: PfxKey) {
                    Log.i("EImzoApp", "importPfxFile SUCCESS: serial=${key.serialNumber}")
                    _state.value = AddKeyState.Success(key)
                }
                override fun onError(error: String) {
                    Log.e("EImzoApp", "importPfxFile ERROR: $error")
                    _state.value = AddKeyState.Error(error)
                }
            })
        } catch (e: Exception) {
            Log.e("EImzoApp", "importPfxFile EXCEPTION", e)
            _state.value = AddKeyState.Error(e.message ?: "Xatolik")
        }
    }

    fun importNfcCard(tag: Tag, pin: String, savePassword: Boolean = true) {
        _state.value = AddKeyState.Loading
        sdk.importNfcKey(tag, pin, savePassword, object : ImportKeyCallback {
            override fun onSuccess(key: PfxKey) {
                _state.value = AddKeyState.Success(key)
            }
            override fun onError(error: String) {
                _state.value = AddKeyState.Error(error)
            }
        })
    }

    // NOTE: USB token is intentionally NOT a saved-key flow. USB token
    // signing is sign-only — see HomeFragment's "USB token bilan imzolash"
    // action, which opens an FT session, prompts for PIN, signs the
    // deeplink hash, and tears the session down without persisting
    // anything. There is no importUsbToken() here by design.

    fun resetState() {
        _state.value = AddKeyState.Idle
    }

    sealed class AddKeyState {
        object Idle : AddKeyState()
        object Loading : AddKeyState()
        data class Success(val key: PfxKey) : AddKeyState()
        data class Error(val message: String) : AddKeyState()
    }
}
