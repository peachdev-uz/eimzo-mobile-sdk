package uz.eimzo.sdk.fullui.keys

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.models.PfxKey

class KeysViewModel : ViewModel() {

    private val sdk = EImzoSDK.get()

    val keys = sdk.getAllKeys().asLiveData()

    fun setDefault(key: PfxKey) {
        viewModelScope.launch { sdk.setDefaultKey(key.serialNumber) }
    }

    fun delete(key: PfxKey) {
        viewModelScope.launch { sdk.deleteKey(key.serialNumber) }
    }
}
