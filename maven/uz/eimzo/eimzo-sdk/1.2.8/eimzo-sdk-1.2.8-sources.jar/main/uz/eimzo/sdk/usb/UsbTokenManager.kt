package uz.eimzo.sdk.usb

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.ftsafe.DK
import com.ftsafe.readerScheme.FTException
import com.ftsafe.readerScheme.FTReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import uz.eimzo.sdk.crypto.HexUtils
import uz.yt.idcard.applet.android.EImzoAppletFactory
import uz.yt.idcard.applet.android.dto.FileType
import uz.yt.idcard.applet.android.dto.State
import uz.yt.idcard.applet.android.exception.InvalidUserPINException
import java.io.ByteArrayOutputStream
import java.util.concurrent.locks.ReentrantLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * USB token signing using FT Reader.
 *
 * Sign-only. USB tokens are NEVER persisted as saved keys — each sign
 * is a transient session: open FT session, wait for token + card insert,
 * verify PIN, sign the hash, tear the session down.
 *
 * Backed by FTReaderAPI_2.0.1.7.jar + applet-android-1.7.0-SNAPSHOT.jar
 * (under eimzo-sdk/libs/). Only ONE sign may be in flight at a time —
 * the FT reader native session is exclusive.
 *
 * FTReaderAPI 2.0.1.7 addresses the reader by the Android **UsbDevice name**
 * (e.g. "/dev/bus/usb/001/003") instead of the implicit single-reader model of
 * 1.0.9.6 — [FTReader.getDeviceIndex] matches on `UsbDevice.getDeviceName()`.
 * [readerName] is captured from the USB_IN message and threaded into every
 * slot-level call (readerOpen / readerPowerOn / readerXfr / readerClose).
 */
internal class UsbTokenManager(private val context: Context) {

    private var ftReader: FTReader? = null
    private val lock = ReentrantLock()
    private val slotIndex = 0

    /** Android UsbDevice name — the handle every 2.0.1.7 slot call needs. */
    private var readerName: String? = null

    private var pendingContinuation: kotlin.coroutines.Continuation<UsbSignResult>? = null
    private var pendingPin: String? = null
    private var pendingSaHashRev: ByteArray? = null

    /** readerFind() retries consumed for the in-flight sign — see USB_LOG handler. */
    private var findRetries = 0

    data class UsbSignResult(
        val serialNumber: String,
        val signature: String
    )

    /** Atomically take the continuation (so we never resume it twice). */
    private fun drainContinuation(): kotlin.coroutines.Continuation<UsbSignResult>? {
        val c = pendingContinuation
        pendingContinuation = null
        return c
    }

    // NOTE: never log msg.obj here — USB_LOG messages carry raw APDU hex,
    // which includes the user's PIN during validatePIN.
    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                DK.USB_LOG -> {
                    // After the user grants USB permission, 2.0.1.7's broadcast
                    // receiver opens the device but NEVER posts USB_IN — the
                    // library only sends USB_IN from readerFind()'s
                    // permission-already-granted path. FEITIAN's own demo makes
                    // the user tap "Find" again after granting; we automate that
                    // retry here. The receiver logs its action string before any
                    // work, and that USB_LOG message reaches us strictly after
                    // onReceive finished (both run on the main looper), so by now
                    // hasPermission() reflects the user's answer. Denials re-throw
                    // inside readerFind and just re-request — capped by
                    // MAX_FIND_RETRIES so a user who keeps tapping "Deny" doesn't
                    // loop forever.
                    val text = msg.obj as? String
                    if (text?.contains("USB_PERMISSION") == true &&
                        pendingContinuation != null && readerName == null &&
                        findRetries < MAX_FIND_RETRIES
                    ) {
                        findRetries++
                        try {
                            ftReader?.readerFind()
                        } catch (_: FTException) {
                            // still waiting / denied — the next grant retries
                        }
                    }
                }
                DK.USB_IN -> {
                    // USB_IN carries the Android UsbDevice and fires both when
                    // permission was already granted (ft_find posts it directly)
                    // and right after the user taps "Allow" on the system dialog.
                    // 2.0.1.7 addresses every slot call by the UsbDevice NAME
                    // (FTReader.getDeviceIndex matches UsbDevice.getDeviceName()),
                    // so that string IS our reader handle — readerOpen(null) was
                    // wrong (ft_open rejects a non-String param) and so was using
                    // readerOpen()'s slot-name return value. readerOpen(name) also
                    // starts the card-presence poller that later posts CARD_IN.
                    val deviceName = (msg.obj as? UsbDevice)?.deviceName
                    if (deviceName != null) {
                        try {
                            readerName = deviceName
                            ftReader?.readerOpen(deviceName)
                            // FT JavaCard tokens expose only bulk endpoints — no
                            // interrupt endpoint — so the library's card-presence
                            // poller can never deliver CARD_IN for them. The card
                            // inside a token is permanently present anyway: query
                            // the slot over the bulk channel and start signing
                            // right away, keeping CARD_IN as the path for real
                            // removable-card readers.
                            val status = try {
                                ftReader?.readerGetSlotStatus(deviceName, slotIndex)
                            } catch (_: FTException) {
                                null
                            }
                            if (status != null && status != DK.CARD_NO_PRESENT) {
                                processCard()
                            }
                        } catch (e: FTException) {
                            drainContinuation()?.resumeWithException(e)
                        }
                    }
                }
                DK.USB_OUT -> {
                    drainContinuation()?.resumeWithException(
                        Exception("USB token uzildi")
                    )
                }
                else -> {
                    if (msg.what and DK.CARD_IN_MASK == DK.CARD_IN_MASK) {
                        processCard()
                    }
                }
            }
        }
    }

    suspend fun sign(saHashRev: ByteArray, pin: String): UsbSignResult =
        // FTReader's constructor and our `handler` field both touch the
        // current thread's Looper, so the suspendCancellableCoroutine block
        // MUST run on the main thread — IO worker threads have no Looper
        // and throw "Can't create handler inside thread Thread[…]".
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                pendingContinuation = cont
                pendingPin = pin
                pendingSaHashRev = saHashRev
                findRetries = 0

                try {
                    readerName?.let { runCatching { ftReader?.readerClose(it) } }
                    readerName = null
                    ftReader = FTReader(context, handler, 0)
                    ftReader?.readerFind()
                } catch (e: FTException) {
                    // 2.0.1.7's ft_find() calls requestPermission() and then
                    // immediately throws "Device Not Found" on the very first
                    // sign attempt — before the app holds USB permission. That
                    // is NOT a real failure: the system permission dialog is now
                    // showing, and once the user taps "Allow" the USB_IN →
                    // CARD_IN path resumes this same continuation via
                    // processCard(). So we only fail hard when no FEITIAN token
                    // is physically attached; otherwise we keep waiting for the
                    // grant. (1.0.9.6's ft_find did not throw on this path,
                    // which is why the old code never hit this regression.)
                    if (!isFeitianTokenAttached()) {
                        drainContinuation()?.resumeWithException(
                            Exception("USB token topilmadi: ${e.message}")
                        )
                    }
                }
            }
        }

    private fun processCard() {
        // Drain the pending continuation atomically — CARD_IN can fire multiple
        // times for the same physical insert (or while we're still processing
        // the first one), and resuming a continuation twice throws
        // IllegalStateException("Already resumed").
        val cont = drainContinuation() ?: return

        if (!lock.tryLock()) {
            // Another processCard is running — put the continuation back so
            // that one can complete it.
            pendingContinuation = cont
            return
        }

        try {
            try {
                val name = readerName
                    ?: throw Exception("USB token topilmadi")
                ftReader?.readerPowerOn(name, slotIndex)
                    ?: throw Exception("USB token topilmadi")
                val channel = ftReader?.let { FtCardChannel(it, name, slotIndex) }
                    ?: throw Exception("USB kanal yaratib bo'lmadi")

                try {
                    val eiaf = EImzoAppletFactory()
                    val applet = eiaf.get(channel)
                    val asi = applet.appletStateInfo

                    if (asi.state != State.PERSONALIZED) {
                        throw Exception("Token personalizatsiya qilinmagan")
                    }

                    val serialOut = ByteArrayOutputStream()
                    applet.readFile(FileType.SERIAL_NUMBER, serialOut)
                    val serialNumber = HexUtils.toHex(serialOut.toByteArray())

                    applet.validatePIN(pendingPin)
                    val signatureBytes = applet.signHash(pendingSaHashRev!!)
                    val signature = HexUtils.toHex(signatureBytes)

                    eiaf.deselect(channel)
                    cont.resume(UsbSignResult(serialNumber, signature))
                } finally {
                    // Power the slot down BEFORE closing the channel —
                    // FtCardChannel.close() calls readerClose(), which removes
                    // the device from the library's list, after which
                    // readerPowerOff can no longer resolve it ("no device
                    // connected").
                    runCatching { ftReader?.readerPowerOff(name, slotIndex) }
                    runCatching { channel.close() }
                }
            } catch (e: InvalidUserPINException) {
                cont.resumeWithException(Exception("PIN_ERROR:${e.message}"))
            } catch (e: Exception) {
                cont.resumeWithException(e)
            }
        } finally {
            // Clear request-scoped state so the next sign() starts fresh.
            pendingPin = null
            pendingSaHashRev = null
            lock.unlock()
        }
    }

    fun release() {
        readerName?.let { name -> runCatching { ftReader?.readerClose(name) } }
        readerName = null
    }

    /**
     * True when a FEITIAN reader is physically attached, matched by USB vendor
     * id. Used to tell "ft_find() is just requesting permission" apart from "no
     * token is plugged in at all" — both surface as the same "Device Not Found"
     * FTException, so the message alone can't distinguish them.
     */
    private fun isFeitianTokenAttached(): Boolean {
        val usb = context.getSystemService(Context.USB_SERVICE) as? UsbManager ?: return false
        return usb.deviceList.values.any { it.vendorId in FEITIAN_VENDOR_IDS }
    }

    companion object {
        /** FEITIAN USB vendor ids that the FTReader library itself matches on. */
        private val FEITIAN_VENDOR_IDS = setOf(2414, 1254, 1546, 5902)
        /** Max automatic readerFind() retries per sign after permission broadcasts. */
        private const val MAX_FIND_RETRIES = 3
    }
}
