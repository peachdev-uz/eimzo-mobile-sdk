package uz.eimzo.sdk.fullui.home

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import uz.eimzo.sdk.R
import uz.eimzo.sdk.databinding.EimzoUiFragmentHomeBinding
import uz.eimzo.sdk.fullui.EImzoActivity
import uz.eimzo.sdk.fullui.addkey.AddKeyBottomSheet
import uz.eimzo.sdk.fullui.scanner.QrScannerActivity
import uz.eimzo.sdk.ui.LoadingOverlay
import uz.eimzo.sdk.fullui.util.PasswordDialog
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey

class HomeFragment : Fragment() {

    private var _binding: EimzoUiFragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private var nfcAdapter: NfcAdapter? = null
    private var pendingNfcPin: String? = null

    /** True when the activity was launched (or re-entered) via an `eimzo://...` deeplink. */
    private var launchedViaDeeplink: Boolean = false

    /** Scanner for capturing a sign-document QR (deeplink). */
    private val signQrScanner = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (contents != null) {
            handleSignDeeplink(contents)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = EimzoUiFragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nfcAdapter = NfcAdapter.getDefaultAdapter(requireContext())

        // Check for deeplink from activity
        val activity = requireActivity() as EImzoActivity
        val dl = activity.getPendingDeepLink()
            ?: arguments?.getString("deepLink")
        if (dl != null) launchedViaDeeplink = true
        viewModel.setDeepLink(dl)

        setupObservers()
        setupClickListeners()
    }

    private fun setupObservers() {
        viewModel.currentKey.observe(viewLifecycleOwner) { key ->
            updateKeyCard(key)
        }

        viewModel.deepLink.observe(viewLifecycleOwner) { deepLink ->
            if (deepLink != null) {
                binding.cardDeepLink.visibility = View.VISIBLE
                binding.tvDeepLinkInfo.text = deepLink
            } else {
                binding.cardDeepLink.visibility = View.GONE
            }
        }

        viewModel.signState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is HomeViewModel.SignState.Idle -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = viewModel.currentKey.value != null
                    binding.btnSign.text = getString(R.string.eimzo_ui_sign)
                }
                is HomeViewModel.SignState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.btnSign.isEnabled = false
                    binding.btnSign.text = getString(R.string.eimzo_ui_signing)
                }
                is HomeViewModel.SignState.WaitingNfc -> {
                    binding.progressBar.visibility = View.GONE
                    showNfcPasswordDialog()
                }
                is HomeViewModel.SignState.NeedPassword -> {
                    binding.progressBar.visibility = View.GONE
                    showPasswordDialog(state.keyType)
                }
                is HomeViewModel.SignState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = false
                    binding.btnSign.text = getString(R.string.eimzo_ui_signed)
                    binding.tvSignResult.visibility = View.VISIBLE
                    binding.tvSignResult.text = "${state.result.state}: ${state.result.message ?: ""}"
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.eimzo_ui_sign_success),
                        Toast.LENGTH_SHORT
                    ).show()
                    // If we got here via an external eimzo:// deeplink, the integrator
                    // app is waiting — auto-close after a short success delay.
                    if (launchedViaDeeplink) {
                        binding.btnSign.postDelayed({
                            requireActivity().finishAndRemoveTask()
                        }, 1500)
                    }
                }
                is HomeViewModel.SignState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = viewModel.currentKey.value != null
                    binding.btnSign.text = getString(R.string.eimzo_ui_sign)
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnSign.setOnClickListener {
            val key = viewModel.currentKey.value ?: run {
                Toast.makeText(requireContext(), getString(R.string.eimzo_ui_no_key_selected), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // If no deeplink yet, scan a QR code containing the sign-deeplink first
            if (viewModel.deepLink.value == null) {
                launchSignQrScanner()
                return@setOnClickListener
            }
            initiateSign(key)
        }

        binding.btnSeeAll.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.cardKey.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.tvNoKey.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.rowAddEri.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.btnMenu.setOnClickListener {
            Toast.makeText(requireContext(), "Menu (tez orada)", Toast.LENGTH_SHORT).show()
        }

        binding.btnHelp.setOnClickListener {
            Toast.makeText(requireContext(), "Yordam (tez orada)", Toast.LENGTH_SHORT).show()
        }
    }

    /** Launch QR scanner to capture a sign-deeplink (e.g. eimzo://sign?qc=...). */
    private fun launchSignQrScanner() {
        Toast.makeText(requireContext(), getString(R.string.eimzo_ui_scan_deeplink_qr), Toast.LENGTH_SHORT).show()
        val options = ScanOptions().apply {
            setCaptureActivity(QrScannerActivity::class.java)
            setPrompt("")
            setBeepEnabled(false)
            setOrientationLocked(true)
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setBarcodeImageEnabled(false)
        }
        signQrScanner.launch(options)
    }

    /**
     * Handle a scanned/received sign-deeplink: store in ViewModel and proceed
     * with signing — using the saved password if available, otherwise prompting.
     */
    private fun handleSignDeeplink(deepLink: String) {
        viewModel.setDeepLink(deepLink)
        val key = viewModel.currentKey.value ?: return
        initiateSign(key)
    }

    /**
     * Begin the signing operation for [key]. Uses the password stored on the
     * key (if the user opted to save it at import time) — otherwise prompts.
     */
    private fun initiateSign(key: PfxKey) {
        val savedPassword = key.password
        if (!savedPassword.isNullOrEmpty()) {
            when (key.keyType) {
                KeyType.QR_PFX -> viewModel.signWithCurrentKey(savedPassword)
                KeyType.NFC_ID -> startNfcSignFlow(savedPassword)
                KeyType.USB_TOKEN -> viewModel.signWithUsb(savedPassword)
            }
        } else {
            when (key.keyType) {
                KeyType.QR_PFX -> showPasswordDialog(KeyType.QR_PFX)
                KeyType.NFC_ID -> showNfcPasswordDialog()
                KeyType.USB_TOKEN -> showPasswordDialog(KeyType.USB_TOKEN)
            }
        }
    }

    // Note: PFX/QR key import is handled in KeysFragment now —
    // Home only handles signing.

    private fun updateKeyCard(key: PfxKey?) {
        if (key == null) {
            binding.cardKey.visibility = View.GONE
            binding.tvNoKey.visibility = View.VISIBLE
            binding.headerKeys.visibility = View.GONE
            binding.btnSign.visibility = View.GONE
        } else {
            binding.cardKey.visibility = View.VISIBLE
            binding.tvNoKey.visibility = View.GONE
            binding.headerKeys.visibility = View.VISIBLE
            binding.btnSign.visibility = View.VISIBLE
            binding.btnSign.isEnabled = true
            binding.tvKeyName.text = if (key.tin != null) key.organization ?: key.name else key.name
            binding.tvKeyId.text = if (key.tin != null) key.tin else key.uid ?: ""
            binding.tvKeyPinfl.text = key.pinfl ?: getString(R.string.eimzo_ui_not_given)
            binding.tvKeyExpiry.text = key.validTo
        }
    }

    private fun showPasswordDialog(keyType: KeyType) {
        val title = when (keyType) {
            KeyType.QR_PFX -> getString(R.string.eimzo_ui_enter_eri_password)
            KeyType.NFC_ID -> getString(R.string.eimzo_ui_enter_id_pin)
            KeyType.USB_TOKEN -> getString(R.string.eimzo_ui_enter_usb_pin)
        }
        PasswordDialog.show(requireContext(), title) { password, _savePassword ->
            // Note: savePassword here would only matter if we re-stored the
            // password against the key. For now, prompt-on-demand passwords
            // are not persisted — that decision was made at import time.
            when (keyType) {
                KeyType.QR_PFX -> viewModel.signWithCurrentKey(password)
                KeyType.USB_TOKEN -> viewModel.signWithUsb(password)
                KeyType.NFC_ID -> startNfcSignFlow(password)
            }
        }
    }

    private fun startNfcSignFlow(pin: String) {
        pendingNfcPin = pin
        enableNfcForeground()
        Toast.makeText(requireContext(), getString(R.string.eimzo_ui_bring_card_close), Toast.LENGTH_LONG).show()
    }

    private fun showNfcPasswordDialog() {
        showPasswordDialog(KeyType.NFC_ID)
    }

    // ──────────────────────────────────────────────────────────────────
    // NFC Foreground dispatch
    // ──────────────────────────────────────────────────────────────────

    private fun enableNfcForeground() {
        val activity = requireActivity()
        val intent = Intent(activity, activity.javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(activity, 0, intent, PendingIntent.FLAG_MUTABLE)
        nfcAdapter?.enableForegroundDispatch(activity, pendingIntent, null, null)
    }

    private fun disableNfcForeground() {
        nfcAdapter?.disableForegroundDispatch(requireActivity())
    }

    fun onNfcTagDiscovered(tag: Tag) {
        val pin = pendingNfcPin ?: return
        pendingNfcPin = null
        disableNfcForeground()
        viewModel.signWithNfcTag(tag, pin)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshCurrentKey()
        if (pendingNfcPin != null) enableNfcForeground()
    }

    override fun onPause() {
        super.onPause()
        disableNfcForeground()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
