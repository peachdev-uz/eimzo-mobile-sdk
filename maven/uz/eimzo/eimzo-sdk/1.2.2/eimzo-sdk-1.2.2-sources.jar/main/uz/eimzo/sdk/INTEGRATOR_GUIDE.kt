/*
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║         E-IMZO Android SDK — INTEGRATORLAR UCHUN QO'LLANMA      ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * 1. AAR ni loyihangizga qo'shish:
 *    --------------------------------
 *    app/libs/ papkasiga nusxalang:
 *      - eimzo-sdk.aar           (bu kutubxona)
 *      - pfx2qr.aar
 *      - FTReaderAPI_1.0.9.6.jar
 *      - applet-android-1.7.0-SNAPSHOT.jar
 *
 *    .so fayllarini jniLibs/ ga nusxalang:
 *      - libFTReaderPCSC_1.0.9.6.so (arm64-v8a, armeabi-v7a, x86, x86_64)
 *
 *    build.gradle (app):
 *      dependencies {
 *          implementation fileTree(dir: 'libs', include: ['*.jar', '*.aar'])
 *      }
 *
 * 2. Initsializatsiya (Application.onCreate):
 *    ------------------------------------------
 *    EImzoSDK.init(context, EImzoConfig(isTestMode = false))
 *
 * 3. ERI (.pfx) kalitini import qilish:
 *    ------------------------------------
 *    val pfxBytes = File("key.pfx").readBytes()
 *    EImzoSDK.get().importPfxKey(pfxBytes, "password123", object : ImportKeyCallback {
 *        override fun onSuccess(key: PfxKey) { /* kalit saqlandi */ }
 *        override fun onError(error: String) { /* xatolik */ }
 *    })
 *
 * 4. ERI kalit bilan imzolash (deeplink):
 *    ---------------------------------------
 *    // Deeplink format: eimzo://sign?qc=<site_id>|<doc_id>|<hash>|<crc32>
 *    EImzoSDK.get().signWithQrKey(
 *        key = savedKey,
 *        deepLink = "eimzo://sign?qc=...",
 *        password = null,          // null → saqlangan paroldan foydalanadi
 *        callback = object : SignCallback {
 *            override fun onSuccess(result: SignResult.Success) {
 *                Log.d("EIMZO", "${result.state}: ${result.message}")
 *            }
 *            override fun onError(error: SignResult.Failure) {
 *                Log.e("EIMZO", error.error)
 *            }
 *        }
 *    )
 *
 * 5. NFC ID karta bilan imzolash:
 *    --------------------------------
 *    // NFC tagni olish (Activity.onNewIntent yoki ForegroundDispatch):
 *    val tag: Tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)!!
 *    EImzoSDK.get().signWithNfc(tag, pin = "12345", deepLink, callback)
 *
 * 6. USB Token bilan imzolash:
 *    ---------------------------
 *    EImzoSDK.get().signWithUsbToken(pin = "12345", deepLink, callback)
 *
 * 7. Kalitlar ro'yxati (LiveData/Flow):
 *    ------------------------------------
 *    // Fragment/Activity da:
 *    lifecycleScope.launch {
 *        EImzoSDK.get().getAllKeys().collect { keys ->
 *            // RecyclerView ni yangilang
 *        }
 *    }
 *
 * 8. AAR ni build qilish:
 *    ----------------------
 *    ./gradlew :eimzo-sdk:assembleRelease
 *    # Natija: eimzo-sdk/build/outputs/aar/eimzo-sdk-release.aar
 *
 * AndroidManifest.xml da kerakli ruxsatlar:
 *    <uses-permission android:name="android.permission.INTERNET" />
 *    <uses-permission android:name="android.permission.NFC" />
 *    <uses-feature android:name="android.hardware.usb.host" />
 *
 * Deeplink intent-filter:
 *    <intent-filter>
 *        <action android:name="android.intent.action.VIEW" />
 *        <category android:name="android.intent.category.DEFAULT" />
 *        <category android:name="android.intent.category.BROWSABLE" />
 *        <data android:scheme="eimzo" android:host="sign" />
 *    </intent-filter>
 */
