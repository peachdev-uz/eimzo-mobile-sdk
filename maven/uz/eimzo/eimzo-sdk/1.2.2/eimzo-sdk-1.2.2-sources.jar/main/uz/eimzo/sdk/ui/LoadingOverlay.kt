package uz.eimzo.sdk.ui

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import uz.eimzo.sdk.R

/**
 * Full-screen loading overlay matching Flutter's `ModalProgressHUD + eimzoSpinner`:
 * a translucent white background with the e-imzo logo in the center and a
 * Lottie spinner animation around it.
 *
 * Non-cancellable — the host fragment must call [hide] explicitly on
 * success or error.
 *
 * Usage:
 * ```
 *   val overlay = LoadingOverlay.show(parentFragmentManager)
 *   sdk.importPfxKey(bytes, password, object : ImportKeyCallback {
 *     override fun onSuccess(key: PfxKey) { overlay.hide() … }
 *     override fun onError(error: String) { overlay.hide() … }
 *   })
 * ```
 */
class LoadingOverlay : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext(), android.R.style.Theme_Translucent_NoTitleBar)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        return dialog
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.eimzo_dialog_loading, container, false)
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    /** Dismiss safely — no-op if already hidden or detached. */
    fun hide() {
        if (isAdded && !isStateSaved) {
            dismissAllowingStateLoss()
        }
    }

    companion object {
        private const val TAG = "EimzoLoadingOverlay"

        /** Shows the overlay using the given fragment manager. Returns the instance for [hide]. */
        fun show(fm: FragmentManager): LoadingOverlay {
            // Don't double-show
            (fm.findFragmentByTag(TAG) as? LoadingOverlay)?.let { return it }
            val overlay = LoadingOverlay()
            overlay.show(fm, TAG)
            return overlay
        }
    }
}
