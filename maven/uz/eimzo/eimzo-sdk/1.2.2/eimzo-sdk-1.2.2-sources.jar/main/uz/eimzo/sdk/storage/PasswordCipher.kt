package uz.eimzo.sdk.storage

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Wraps the saved-password column in Room with AES-256-GCM authenticated
 * encryption keyed by the AndroidKeyStore. The plaintext password never
 * leaves the in-memory `PfxKey` model — anything written to disk passes
 * through [encrypt], anything read back goes through [decrypt].
 *
 * Storage format (Base64-encoded):
 *
 *   [12-byte IV][ciphertext + 16-byte GCM tag]
 *
 * Threat model addressed:
 *   - Plain SQLite read on a rooted device → ciphertext only, no key
 *   - `adb backup` (despite our backup-rules exclusion) → same
 *   - Cross-device backup restore → AndroidKeyStore is per-device, the
 *     restored DB rows are mathematically unrecoverable
 *
 * The Keystore key is bound to the application UID. If the user clears
 * app data, the key is invalidated; any previously-encrypted passwords
 * become permanently undecryptable — which is the intended fail-safe.
 */
internal object PasswordCipher {

    private const val KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "uz.eimzo.sdk.passwordCipher.v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_BITS = 128
    private const val GCM_IV_BYTES = 12

    /** Lazily ensures the symmetric key exists; returns it. */
    private val secretKey: SecretKey
        get() {
            val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
            (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
            gen.init(
                KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    // Available after-first-unlock equivalent: usable in
                    // foreground without an extra biometric prompt. We
                    // deliberately don't require user authentication on each
                    // sign — that would block deeplink auto-sign UX.
                    .setRandomizedEncryptionRequired(true)
                    .build()
            )
            return gen.generateKey()
        }

    /** Encrypts [plaintext] and returns a Base64 string safe to store in SQL. */
    fun encrypt(plaintext: String): String {
        if (plaintext.isEmpty()) return ""
        val cipher = Cipher.getInstance(TRANSFORMATION).apply {
            init(Cipher.ENCRYPT_MODE, secretKey)
        }
        val iv = cipher.iv  // 12 bytes — AndroidKeyStore generates this
        val ct = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

        val out = ByteArray(iv.size + ct.size)
        System.arraycopy(iv, 0, out, 0, iv.size)
        System.arraycopy(ct, 0, out, iv.size, ct.size)
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    /**
     * Inverse of [encrypt]. Returns the original plaintext or null if the
     * input is empty / not a valid ciphertext (e.g. someone hand-edited
     * the DB row, or the AndroidKeyStore key was wiped).
     */
    fun decrypt(stored: String?): String? {
        if (stored.isNullOrEmpty()) return null
        return try {
            val blob = Base64.decode(stored, Base64.NO_WRAP)
            if (blob.size < GCM_IV_BYTES + 16) return null  // IV + GCM tag minimum

            val iv = ByteArray(GCM_IV_BYTES)
            val ct = ByteArray(blob.size - GCM_IV_BYTES)
            System.arraycopy(blob, 0, iv, 0, GCM_IV_BYTES)
            System.arraycopy(blob, GCM_IV_BYTES, ct, 0, ct.size)

            val cipher = Cipher.getInstance(TRANSFORMATION).apply {
                init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_BITS, iv))
            }
            String(cipher.doFinal(ct), Charsets.UTF_8)
        } catch (_: Exception) {
            // GCM auth tag mismatch / corrupted ciphertext / missing key —
            // treat as "no password saved" so the user is re-prompted.
            null
        }
    }
}
