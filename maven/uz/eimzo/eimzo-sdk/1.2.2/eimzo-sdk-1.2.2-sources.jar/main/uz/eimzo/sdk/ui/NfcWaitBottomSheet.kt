package uz.eimzo.sdk.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import uz.eimzo.sdk.R

/**
 * Bottom sheet for the NFC ID-card interaction. Replays Flutter's three Lottie
 * states (nfc_state_1/2/3) to give the user clear feedback while talking to
 * the card.
 *
 * Typical lifecycle:
 *   1. Fragment shows the sheet — defaults to [NfcState.WAITING]
 *   2. Tag detected → fragment calls [setState] with [NfcState.READING]
 *   3. SDK call succeeds → fragment calls [setState] with [NfcState.SUCCESS],
 *      then [dismiss] after a short delay
 *   4. SDK call fails → fragment calls [setState] with [NfcState.ERROR] or
 *      simply dismisses and shows a toast
 *
 * Optional [setHint] overrides the bottom text for a single state without
 * touching the others.
 */
class NfcWaitBottomSheet : BottomSheetDialogFragment() {

    enum class NfcState(val lottieRes: Int, val defaultText: String) {
        WAITING(R.raw.eimzo_nfc_state_1, "ID kartani qurilmangiz yaqin tuting"),
        READING(R.raw.eimzo_nfc_state_2, "O'qilmoqda…"),
        SUCCESS(R.raw.eimzo_nfc_state_3, "Ma'lumot yuklab olindi"),
        ERROR  (R.raw.eimzo_error,       "Xatolik yuz berdi")
    }

    private var pendingState: NfcState = NfcState.WAITING
    private var pendingHint: String? = null
    private var lottieView: LottieAnimationView? = null
    private var hintView: TextView? = null
    private var onDismissCallback: (() -> Unit)? = null

    fun setState(state: NfcState, customHint: String? = null): NfcWaitBottomSheet {
        pendingState = state
        pendingHint = customHint
        applyStateIfReady()
        return this
    }

    fun setHint(text: String): NfcWaitBottomSheet {
        pendingHint = text
        hintView?.text = text
        return this
    }

    fun setOnDismiss(callback: () -> Unit): NfcWaitBottomSheet {
        onDismissCallback = callback
        return this
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.eimzo_bottom_sheet_nfc_wait, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        lottieView = view.findViewById(R.id.lottieNfc)
        hintView = view.findViewById(R.id.tvNfcHint)
        applyStateIfReady()
    }

    private fun applyStateIfReady() {
        val lottie = lottieView ?: return
        val hint = hintView ?: return
        lottie.setAnimation(pendingState.lottieRes)
        lottie.playAnimation()
        hint.text = pendingHint ?: pendingState.defaultText
    }

    override fun onCancel(dialog: android.content.DialogInterface) {
        super.onCancel(dialog)
        onDismissCallback?.invoke()
    }

    companion object {
        const val TAG = "NfcWaitBottomSheet"
    }
}
