package uz.eimzo.sdk.models

data class PfxKey(
    val serialNumber: String,
    val name: String,
    val organization: String?,
    val uid: String?,
    val tin: String?,
    val pinfl: String?,
    val validFrom: String,
    val validTo: String,
    val validNow: Boolean,
    val qrData: String,
    val password: String?,
    val keyType: KeyType,
    val isDefault: Boolean = false
)
