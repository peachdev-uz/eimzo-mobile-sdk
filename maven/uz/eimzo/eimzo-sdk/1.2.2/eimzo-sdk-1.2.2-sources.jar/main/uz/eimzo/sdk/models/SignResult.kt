package uz.eimzo.sdk.models

sealed class SignResult {
    data class Success(val state: String, val message: String? = null) : SignResult()
    data class Failure(val error: String, val code: String? = null) : SignResult()
}
