package uz.eimzo.sdk.models

/**
 * Parsed e-imzo sign QR / deeplink payload.
 *
 * Wire format (concatenated hex, NOT pipe-separated):
 *   [siteId 4 hex chars][docId 8|10|12|14|16 hex chars][hash 64 hex chars][crc32 8 hex chars]
 *
 * Total length: 84/86/88/90/92 chars depending on docId length.
 *
 * Source: matches `idcard_eimzo` Flutter package `lib/util/qr_hash.dart`.
 */
data class QrHashData(
    val siteId: String,
    val docId: String,
    val hash: String,
    val crc32: String
) {
    companion object {

        private val FORMAT = Regex(
            "^([a-fA-F0-9]{4})([a-fA-F0-9]{8}|[a-fA-F0-9]{10}|[a-fA-F0-9]{12}|[a-fA-F0-9]{14}|[a-fA-F0-9]{16})([a-fA-F0-9]{64})([a-fA-F0-9]{8})$"
        )

        /**
         * Accepts either:
         *   - a full deeplink URL: `eimzo://sign?qc=<payload>`
         *   - the raw `qc` payload string (scanned from a QR code)
         *
         * Returns null on any parse / format / CRC failure.
         */
        fun fromDeepLink(input: String): QrHashData? {
            return try {
                val raw = extractQc(input.trim())
                parse(raw)
            } catch (e: Exception) {
                android.util.Log.w("QrHashData", "fromDeepLink failed: ${e.message}", e)
                null
            }
        }

        /** Pulls the `qc` parameter out of an `eimzo://...?qc=...` URL, or returns input as-is. */
        private fun extractQc(input: String): String {
            if (input.startsWith("eimzo://", ignoreCase = true) ||
                input.startsWith("http://", ignoreCase = true) ||
                input.startsWith("https://", ignoreCase = true)
            ) {
                val uri = android.net.Uri.parse(input)
                return uri.getQueryParameter("qc") ?: input
            }
            return input
        }

        /**
         * Parse the raw payload. Validates length, structure, and CRC32.
         * Throws on any failure.
         */
        fun parse(raw: String): QrHashData {
            val match = FORMAT.matchEntire(raw)
                ?: throw IllegalArgumentException(
                    "Invalid QR hash format. Expected 84-92 hex chars [siteId4][docId8-16][hash64][crc8], " +
                            "got ${raw.length} chars"
                )

            val (siteId, docId, hash, crc32) = match.destructured

            val computed = crc32OfHex(siteId + docId + hash)
            if (!computed.equals(crc32, ignoreCase = true)) {
                throw IllegalStateException("CRC32 mismatch: got=$crc32, computed=$computed")
            }

            return QrHashData(
                siteId = siteId,
                docId = docId,
                hash = hash,
                crc32 = crc32
            )
        }

        /**
         * CRC32 over the hex-decoded bytes of `hexInput`.
         * Returns lowercase 8-char hex string.
         */
        private fun crc32OfHex(hexInput: String): String {
            require(hexInput.length % 2 == 0) { "hex input must be even length" }
            val bytes = ByteArray(hexInput.length / 2)
            for (i in bytes.indices) {
                bytes[i] = hexInput.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
            val crc = java.util.zip.CRC32()
            crc.update(bytes)
            return "%08x".format(crc.value)
        }
    }
}
