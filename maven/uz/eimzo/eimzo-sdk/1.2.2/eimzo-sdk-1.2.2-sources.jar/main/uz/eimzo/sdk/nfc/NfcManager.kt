package uz.eimzo.sdk.nfc

import android.nfc.Tag
import android.nfc.tech.IsoDep
import uz.eimzo.sdk.crypto.HexUtils
import uz.yt.idcard.applet.android.EImzoApplet
import uz.yt.idcard.applet.android.EImzoAppletFactory
import uz.yt.idcard.applet.android.dto.FileType
import uz.yt.idcard.applet.android.dto.State
import uz.yt.idcard.applet.android.smartcardio.CardChannel
import uz.yt.idcard.applet.android.smartcardio.CommandAPDU
import uz.yt.idcard.applet.android.smartcardio.ResponseAPDU
import java.io.ByteArrayOutputStream

internal class NfcManager {

    fun readCardInfo(tag: Tag): NfcCardInfo? {
        val isoDep = IsoDep.get(tag) ?: return null
        return try {
            isoDep.connect()
            isoDep.timeout = 30000
            val channel = IsoDepCardChannel(isoDep)
            val applet = EImzoAppletFactory().get(channel)
            val asi = applet.getAppletStateInfo()

            if (asi.state != State.PERSONALIZED) return null

            val serialOut = ByteArrayOutputStream()
            applet.readFile(FileType.SERIAL_NUMBER, serialOut)
            val serialNumber = HexUtils.toHex(serialOut.toByteArray())

            val x500Out = ByteArrayOutputStream()
            applet.readFile(FileType.X500_NAME, x500Out)
            val x500Name = Latin5Decoder.decode(x500Out.toByteArray())

            val validityOut = ByteArrayOutputStream()
            applet.readFile(FileType.VALIDITY, validityOut)
            val validity = HexUtils.toHex(validityOut.toByteArray())

            val hardwareUid = tryGetHardwareUid(applet) ?: serialNumber

            NfcCardInfo(
                serialNumber = serialNumber,
                x500Name = x500Name,
                validity = validity,
                hardwareUid = hardwareUid
            )
        } finally {
            runCatching { isoDep.close() }
        }
    }

    fun signWithNfc(tag: Tag, pin: String, saHashRev: ByteArray): String {
        val isoDep = IsoDep.get(tag) ?: throw Exception("ISO DEP not supported")
        isoDep.connect()
        isoDep.timeout = 60000
        return try {
            val channel = IsoDepCardChannel(isoDep)
            val applet = EImzoAppletFactory().get(channel)

            val serialOut = ByteArrayOutputStream()
            applet.readFile(FileType.SERIAL_NUMBER, serialOut)

            applet.validatePIN(pin)
            val signatureBytes = applet.signHash(saHashRev)
            HexUtils.toHex(signatureBytes)
        } finally {
            runCatching { isoDep.close() }
        }
    }

    private fun tryGetHardwareUid(applet: EImzoApplet): String? {
        return try {
            val uid = applet.getCardIDInfo().getHardwareUID()
            if (uid != null) HexUtils.toHex(uid) else null
        } catch (e: Exception) {
            null
        }
    }

    data class NfcCardInfo(
        val serialNumber: String,
        val x500Name: String,
        val validity: String,
        val hardwareUid: String
    )

    private inner class IsoDepCardChannel(private val isoDep: IsoDep) : CardChannel {
        override fun transmit(command: CommandAPDU): ResponseAPDU {
            val response = isoDep.transceive(command.getBytes())
            return ResponseAPDU(response)
        }

        override fun close() {
            runCatching { isoDep.close() }
        }
    }
}
