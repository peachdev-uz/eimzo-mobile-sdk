package uz.eimzo.sdk.fullui

import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import uz.eimzo.sdk.EImzoConfig
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.R
import uz.eimzo.sdk.fullui.addkey.AddKeyFragment
import uz.eimzo.sdk.fullui.home.HomeFragment
import uz.eimzo.sdk.fullui.keys.KeysFragment

/**
 * Drop-in full UI for the E-IMZO SDK.
 *
 * Integrators can launch this Activity to get the complete e-imzo experience
 * (Home + Keys + AddKey + sign flow + license check). No need to build UI
 * themselves.
 *
 * Usage from integrator's code:
 *
 *   // Open the full UI standalone
 *   startActivity(Intent(this, EImzoActivity::class.java))
 *
 *   // Or with a pre-filled sign deeplink
 *   val intent = Intent(this, EImzoActivity::class.java).apply {
 *       data = Uri.parse("eimzo://sign?qc=...")
 *   }
 *   startActivity(intent)
 *
 * The Activity will:
 *  1. Show a loading screen
 *  2. Run LicenseGuard (BlockedAppActivity launches automatically if not registered)
 *  3. Switch to the full nav graph (Home/Keys/AddKey) on success
 *  4. If a deeplink was supplied, jump straight into the sign flow
 *
 * Integrators MUST declare this activity in their AndroidManifest if they
 * want it to receive deeplinks; otherwise it works fine when started from
 * their own code via startActivity().
 */
class EImzoActivity : AppCompatActivity() {

    private var pendingDeepLink: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show loading spinner immediately while Firebase license check is in flight.
        setContentView(R.layout.eimzo_ui_activity_loading)

        // Capture initial deeplink before any further work.
        intent.data?.toString()?.let { pendingDeepLink = it }

        EImzoSDK.checkLicenseAndInit(
            activity = this,
            config = EImzoConfig()
        ) { allowed ->
            if (!allowed) return@checkLicenseAndInit
            setContentView(R.layout.eimzo_ui_activity_main)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent == null) return

        // 1) NFC tag intent? — forward to whichever fragment is currently active.
        val action = intent.action
        if (action == NfcAdapter.ACTION_TAG_DISCOVERED ||
            action == NfcAdapter.ACTION_TECH_DISCOVERED ||
            action == NfcAdapter.ACTION_NDEF_DISCOVERED
        ) {
            val tag: Tag? = if (android.os.Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            }
            if (tag != null) {
                dispatchNfcTag(tag)
                return
            }
        }

        // 2) Otherwise treat as a deeplink intent.
        intent.data?.toString()?.let { deepLink ->
            val navHost = supportFragmentManager.findFragmentById(R.id.navHostFragment) as? NavHostFragment
                ?: return
            navHost.navController.navigate(
                R.id.homeFragment,
                Bundle().apply { putString("deepLink", deepLink) }
            )
        }
    }

    /** Find the currently-visible fragment under the nav host and deliver the NFC tag. */
    private fun dispatchNfcTag(tag: Tag) {
        val navHost = supportFragmentManager.findFragmentById(R.id.navHostFragment) as? NavHostFragment
            ?: return
        val current = navHost.childFragmentManager.fragments.firstOrNull { it.isResumed } ?: return
        when (current) {
            is HomeFragment   -> current.onNfcTagDiscovered(tag)
            is AddKeyFragment -> current.onNfcTagDiscovered(tag)
            is KeysFragment   -> current.onNfcTagDiscovered(tag)
        }
    }

    fun getPendingDeepLink(): String? {
        val dl = pendingDeepLink
        pendingDeepLink = null
        return dl
    }
}
