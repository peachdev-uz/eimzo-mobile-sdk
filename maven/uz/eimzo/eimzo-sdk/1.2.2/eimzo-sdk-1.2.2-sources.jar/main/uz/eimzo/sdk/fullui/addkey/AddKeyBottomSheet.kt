package uz.eimzo.sdk.fullui.addkey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import uz.eimzo.sdk.databinding.EimzoUiBottomSheetAddKeyBinding

class AddKeyBottomSheet : BottomSheetDialogFragment() {

    enum class Action { FILE, QR, NFC }

    var onActionSelected: ((Action) -> Unit)? = null

    private var _binding: EimzoUiBottomSheetAddKeyBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = EimzoUiBottomSheetAddKeyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.optionFile.setOnClickListener {
            onActionSelected?.invoke(Action.FILE)
            dismiss()
        }
        binding.optionQr.setOnClickListener {
            onActionSelected?.invoke(Action.QR)
            dismiss()
        }
        binding.optionNfc.setOnClickListener {
            onActionSelected?.invoke(Action.NFC)
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "AddKeyBottomSheet"
    }
}
