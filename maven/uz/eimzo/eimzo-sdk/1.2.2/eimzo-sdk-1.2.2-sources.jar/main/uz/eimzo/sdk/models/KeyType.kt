package uz.eimzo.sdk.models

enum class KeyType {
    QR_PFX,   // ERI fayl (.pfx)
    NFC_ID,   // ID karta (NFC)
    USB_TOKEN // USB token
}
