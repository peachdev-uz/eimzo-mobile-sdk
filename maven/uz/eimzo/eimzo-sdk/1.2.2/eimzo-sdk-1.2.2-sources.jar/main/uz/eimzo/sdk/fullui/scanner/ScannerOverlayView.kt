package uz.eimzo.sdk.fullui.scanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Camera scanner overlay: dim mask + transparent square cutout + 4 orange corner brackets.
 */
class ScannerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density
    private val frameSize = 260f * density
    private val cornerRadius = 18f * density
    private val cornerLength = 40f * density
    private val strokeWidth = 5f * density

    private val maskColor = 0x99000000.toInt()
    private val cornerColor = Color.parseColor("#FF7043")

    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = maskColor
    }
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }
    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = cornerColor
        style = Paint.Style.STROKE
        strokeWidth = this@ScannerOverlayView.strokeWidth
        strokeCap = Paint.Cap.ROUND
    }

    init {
        // Required for PorterDuff.CLEAR to work
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    /** Returns the framing rect in view coordinates (for callers that need it). */
    fun getFrameRect(): RectF {
        val cx = width / 2f
        val cy = height / 2f
        val half = frameSize / 2f
        return RectF(cx - half, cy - half, cx + half, cy + half)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return

        val rect = getFrameRect()

        // 1) Fill entire view with dim mask
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), maskPaint)

        // 2) Punch a rounded transparent rect in the center
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, clearPaint)

        // 3) Draw four orange L-shaped corner brackets
        drawCorner(canvas, rect.left, rect.top, +1, +1)
        drawCorner(canvas, rect.right, rect.top, -1, +1)
        drawCorner(canvas, rect.left, rect.bottom, +1, -1)
        drawCorner(canvas, rect.right, rect.bottom, -1, -1)
    }

    private fun drawCorner(canvas: Canvas, x: Float, y: Float, dx: Int, dy: Int) {
        // Pull the corner endpoint slightly inward so the bracket ends sit nicely
        // at the rounded outline of the cleared rect.
        val r = cornerRadius
        val startInsetX = dx * r
        val startInsetY = dy * r

        // Horizontal stroke
        canvas.drawLine(
            x + startInsetX, y,
            x + dx * cornerLength, y,
            cornerPaint
        )
        // Vertical stroke
        canvas.drawLine(
            x, y + startInsetY,
            x, y + dy * cornerLength,
            cornerPaint
        )
    }
}
