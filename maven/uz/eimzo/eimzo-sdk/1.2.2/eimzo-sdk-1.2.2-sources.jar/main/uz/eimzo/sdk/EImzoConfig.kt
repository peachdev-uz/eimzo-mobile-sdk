package uz.eimzo.sdk

data class EImzoConfig(
    val isTestMode: Boolean = false,
    val productionApiUrl: String = "https://m.e-imzo.uz/api/rpc",
    val testApiUrl: String = "https://m.test.e-imzo.uz/api/rpc"
) {
    val apiUrl: String get() = if (isTestMode) testApiUrl else productionApiUrl
}
