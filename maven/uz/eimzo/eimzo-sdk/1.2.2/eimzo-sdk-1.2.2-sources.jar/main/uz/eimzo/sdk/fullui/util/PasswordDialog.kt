package uz.eimzo.sdk.fullui.util

import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.textfield.TextInputEditText
import uz.eimzo.sdk.R

internal object PasswordDialog {

    /**
     * Shows a password dialog with the e-imzo-style design:
     *   - title (e.g. "ID kartaning ERI parolini kiriting")
     *   - outlined password input
     *   - "Parolni saqlash" checkbox (default ON)
     *   - "Bekor qilish" / "Qo'shish" buttons
     *
     * @param onConfirm receives (password, savePassword). The flag indicates
     *                  whether the user wants the password cached locally.
     */
    fun show(
        context: Context,
        title: String,
        positiveText: String = "Qo'shish",
        negativeText: String = "Bekor qilish",
        onConfirm: (password: String, savePassword: Boolean) -> Unit
    ) {
        val view = android.view.LayoutInflater.from(context)
            .inflate(R.layout.eimzo_ui_dialog_password, null, false)
        val input = view.findViewById<TextInputEditText>(R.id.etPassword)
        val checkbox = view.findViewById<MaterialCheckBox>(R.id.cbSavePassword)

        AlertDialog.Builder(context)
            .setTitle(title)
            .setView(view)
            .setPositiveButton(positiveText) { _, _ ->
                val text = input.text?.toString()?.trim().orEmpty()
                if (text.isNotEmpty()) {
                    onConfirm(text, checkbox.isChecked)
                }
            }
            .setNegativeButton(negativeText, null)
            .show()
    }

    /** Backwards-compatible overload — drops the savePassword flag. */
    @JvmName("showSimple")
    fun show(context: Context, title: String, onConfirm: (String) -> Unit) {
        show(context, title) { password, _ -> onConfirm(password) }
    }
}
