package uz.eimzo.sdk.usb

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

/**
 * Watches for FEITIAN / CCID-class USB smart-card readers plugged into the
 * device. Emits `true` to [isConnected] whenever at least one matching reader
 * is currently attached, `false` otherwise.
 *
 * Lifecycle-aware: register it with `lifecycle.addObserver(detector)` and the
 * broadcast receiver is wired up between `onStart` and `onStop`, so it never
 * leaks past the host fragment/activity.
 *
 * USB token signing is a transient, on-demand operation — the UI should
 * disable the "USB token orqali imzolash" button when no reader is present,
 * which is exactly what observing this LiveData lets you do.
 */
internal class UsbTokenDetector(private val context: Context) : DefaultLifecycleObserver {

    private val usbManager: UsbManager =
        context.getSystemService(Context.USB_SERVICE) as UsbManager

    private val _isConnected = MutableLiveData(false)
    val isConnected: LiveData<Boolean> = _isConnected

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            when (intent.action) {
                UsbManager.ACTION_USB_DEVICE_ATTACHED,
                UsbManager.ACTION_USB_DEVICE_DETACHED -> refreshState()
            }
        }
    }

    private var registered = false

    override fun onStart(owner: LifecycleOwner) {
        if (registered) return
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        // RECEIVER_NOT_EXPORTED — these broadcasts are system-originated, no
        // other apps need to reach our receiver.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            ContextCompat.registerReceiver(
                context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
        registered = true
        refreshState()
    }

    override fun onStop(owner: LifecycleOwner) {
        if (!registered) return
        runCatching { context.unregisterReceiver(receiver) }
        registered = false
    }

    fun refreshState() {
        val connected = usbManager.deviceList.values.any { isSupportedToken(it) }
        if (_isConnected.value != connected) _isConnected.value = connected
    }

    private fun isSupportedToken(device: UsbDevice): Boolean {
        // 1) CCID smart-card readers expose interface class 0x0B. Most FEITIAN
        //    readers (R301, ePass, etc.) match this — class-based check first
        //    so we catch new product IDs without code changes.
        for (i in 0 until device.interfaceCount) {
            if (device.getInterface(i).interfaceClass == UsbInterfaceClassCcid) {
                return true
            }
        }
        // 2) Fallback: explicit FEITIAN vendor ID for non-CCID variants.
        return device.vendorId == VendorIdFeitian
    }

    companion object {
        /** USB interface class for CCID smart-card readers. */
        private const val UsbInterfaceClassCcid = 0x0B
        /** FEITIAN Technologies USB vendor ID. */
        private const val VendorIdFeitian = 0x096E
    }
}
