package uz.eimzo.sdk.nfc

internal object Latin5Decoder {
    fun decode(bytes: ByteArray): String {
        return try {
            String(bytes, Charsets.ISO_8859_1)
        } catch (e: Exception) {
            String(bytes, Charsets.UTF_8)
        }
    }
}
