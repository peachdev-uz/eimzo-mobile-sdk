package uz.eimzo.sdk.crypto

internal object HexUtils {

    private val HEX_CHARS = "0123456789ABCDEF".toCharArray()

    fun toHex(bytes: ByteArray): String {
        val result = CharArray(bytes.size * 2)
        bytes.forEachIndexed { index, byte ->
            val v = byte.toInt() and 0xFF
            result[index * 2] = HEX_CHARS[v ushr 4]
            result[index * 2 + 1] = HEX_CHARS[v and 0x0F]
        }
        return String(result)
    }

    fun toBytes(hex: String): ByteArray {
        val len = hex.length
        require(len % 2 == 0) { "Hex string must have even length" }
        return ByteArray(len / 2) { i ->
            ((hex[i * 2].digitToInt(16) shl 4) + hex[i * 2 + 1].digitToInt(16)).toByte()
        }
    }
}
