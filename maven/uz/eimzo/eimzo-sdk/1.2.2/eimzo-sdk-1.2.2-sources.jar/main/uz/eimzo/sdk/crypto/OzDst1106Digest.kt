package uz.eimzo.sdk.crypto

internal class OzDst1106Digest {

    private val H = IntArray(32)
    private val L = IntArray(32)
    private val M = IntArray(32)
    private val Sum = IntArray(32)
    private val C = Array(4) { IntArray(32) }
    private val xBuf = IntArray(32)
    private var xBufOff = 0
    private var byteCount = 0L
    private val cipher = Gost28147Engine()

    private val C2 = intArrayOf(
        0x00, 0xFF, 0x00, 0xFF, 0x00, 0xFF, 0x00, 0xFF,
        0xFF, 0x00, 0xFF, 0x00, 0xFF, 0x00, 0xFF, 0x00,
        0x00, 0xFF, 0xFF, 0x00, 0xFF, 0x00, 0x00, 0xFF,
        0xFF, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0xFF
    )

    init { reset() }

    fun reset() {
        byteCount = 0; xBufOff = 0
        H.fill(0); L.fill(0); M.fill(0); Sum.fill(0)
        xBuf.fill(0)
        C[1].fill(0); C[3].fill(0)
        C2.copyInto(C[2])
        cipher.init(true, ByteArray(32))
    }

    fun update(inp: ByteArray) = updateBuffer(inp, 0, inp.size)

    fun updateBuffer(inp: ByteArray, inOff: Int, len: Int) {
        var off = inOff; var remaining = len
        while (xBufOff != 0 && remaining > 0) { updateByte(inp[off++].toInt() and 0xFF); remaining-- }
        while (remaining > xBuf.size) {
            inp.copyIntoIntArray(off, xBuf, 0, xBuf.size)
            sumByteArray(xBuf); processBlock(xBuf, 0)
            off += xBuf.size; remaining -= xBuf.size; byteCount += xBuf.size
        }
        while (remaining > 0) { updateByte(inp[off++].toInt() and 0xFF); remaining-- }
    }

    private fun updateByte(inp: Int) {
        xBuf[xBufOff++] = inp
        if (xBufOff == xBuf.size) { sumByteArray(xBuf); processBlock(xBuf, 0); xBufOff = 0 }
        byteCount++
    }

    fun doFinal(out: ByteArray, outOff: Int): Int {
        finish()
        H.copyIntoByteArray(out, outOff)
        reset()
        return 32
    }

    private fun finish() {
        intToLittleEndian((byteCount * 8).toInt(), L, 0)
        while (xBufOff != 0) updateByte(0)
        processBlock(L, 0)
        processBlock(Sum, 0)
    }

    private val K = IntArray(32)
    private fun P(inp: IntArray): IntArray {
        for (k in 0 until 8) {
            K[4 * k] = inp[k]; K[1 + 4 * k] = inp[8 + k]
            K[2 + 4 * k] = inp[16 + k]; K[3 + 4 * k] = inp[24 + k]
        }
        return K
    }

    private val a = IntArray(8)
    private fun A(inp: IntArray): IntArray {
        for (j in 0 until 8) a[j] = (inp[j] xor inp[j + 8]) and 0xFF
        inp.copyInto(inp, 0, 8, 32)
        a.copyInto(inp, 24)
        return inp
    }

    private fun E(key: IntArray, s: IntArray, sOff: Int, inp: IntArray, inOff: Int) {
        val keyBytes = key.toByteArray32()
        val inBytes = inp.toByteArray8(inOff)
        val outBytes = ByteArray(8)
        cipher.init(true, keyBytes)
        cipher.processBlock(inBytes, 0, outBytes, 0)
        for (i in 0 until 8) s[sOff + i] = outBytes[i].toInt() and 0xFF
    }

    private val wS = IntArray(16); private val w_S = IntArray(16)
    private fun fw(inp: IntArray) {
        cpyBytesToShort(inp, wS)
        w_S[15] = (wS[0] xor wS[1] xor wS[2] xor wS[3] xor wS[12] xor wS[15]) and 0xFFFF
        wS.copyInto(w_S, 0, 1, 16)
        cpyShortToBytes(w_S, inp)
    }

    private val S = IntArray(32); private val U = IntArray(32)
    private val V = IntArray(32); private val W = IntArray(32)
    private fun processBlock(inp: IntArray, inOff: Int) {
        inp.copyInto(M, 0, inOff, inOff + 32)
        H.copyInto(U); M.copyInto(V)
        for (j in 0 until 32) W[j] = (U[j] xor V[j]) and 0xFF
        E(P(W), S, 0, H, 0)
        for (i in 1 until 4) {
            val tmpA = A(U)
            for (j in 0 until 32) U[j] = (tmpA[j] xor C[i][j]) and 0xFF
            A(A(V))
            for (j in 0 until 32) W[j] = (U[j] xor V[j]) and 0xFF
            E(P(W), S, i * 8, H, i * 8)
        }
        for (n in 0 until 12) fw(S)
        for (n in 0 until 32) S[n] = (S[n] xor M[n]) and 0xFF
        fw(S)
        for (n in 0 until 32) S[n] = (H[n] xor S[n]) and 0xFF
        for (n in 0 until 61) fw(S)
        S.copyInto(H)
    }

    private fun sumByteArray(inp: IntArray) {
        var carry = 0
        for (i in Sum.indices) {
            val sum = (Sum[i] and 0xFF) + (inp[i] and 0xFF) + carry
            Sum[i] = sum and 0xFF; carry = (sum and 0xFFFFFF) ushr 8
        }
    }

    private fun intToLittleEndian(n: Int, bs: IntArray, off: Int) {
        bs[off] = n and 0xFF; bs[off + 1] = (n ushr 8) and 0xFF
        bs[off + 2] = (n ushr 16) and 0xFF; bs[off + 3] = (n ushr 24) and 0xFF
    }

    private fun cpyBytesToShort(s: IntArray, ws: IntArray) {
        for (i in 0 until s.size / 2) ws[i] = (((s[i * 2 + 1] shl 8) and 0xFF00) or (s[i * 2] and 0xFF)) and 0xFFFF
    }

    private fun cpyShortToBytes(ws: IntArray, s: IntArray) {
        for (i in 0 until s.size / 2) { s[i * 2 + 1] = (ws[i] ushr 8) and 0xFF; s[i * 2] = ws[i] and 0xFF }
    }

    private fun ByteArray.copyIntoIntArray(srcOff: Int, dst: IntArray, dstOff: Int, len: Int) {
        for (i in 0 until len) dst[dstOff + i] = this[srcOff + i].toInt() and 0xFF
    }

    private fun IntArray.copyIntoByteArray(dst: ByteArray, dstOff: Int) {
        for (i in indices) dst[dstOff + i] = (this[i] and 0xFF).toByte()
    }

    private fun IntArray.toByteArray32(): ByteArray {
        val b = ByteArray(32)
        for (i in 0 until 32) b[i] = (this[i] and 0xFF).toByte()
        return b
    }

    private fun IntArray.toByteArray8(off: Int): ByteArray {
        val b = ByteArray(8)
        for (i in 0 until 8) b[i] = (this[off + i] and 0xFF).toByte()
        return b
    }
}
