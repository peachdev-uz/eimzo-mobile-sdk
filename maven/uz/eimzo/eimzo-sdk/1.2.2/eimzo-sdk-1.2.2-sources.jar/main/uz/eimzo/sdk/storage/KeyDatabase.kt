package uz.eimzo.sdk.storage

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [KeyEntity::class], version = 1, exportSchema = false)
internal abstract class KeyDatabase : RoomDatabase() {

    abstract fun keyDao(): KeyDao

    companion object {
        @Volatile private var INSTANCE: KeyDatabase? = null

        fun getInstance(context: Context): KeyDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    KeyDatabase::class.java,
                    "eimzo_keys.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
