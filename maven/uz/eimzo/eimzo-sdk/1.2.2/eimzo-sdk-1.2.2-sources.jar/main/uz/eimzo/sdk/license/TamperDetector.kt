package uz.eimzo.sdk.license

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Debug

/**
 * Lightweight runtime tamper checks. Called from [LicenseGuard.verify] before
 * any network traffic — if the host environment looks hostile, the license
 * check fails fast.
 *
 * Detects:
 *  - Debugger attached (`Debug.isDebuggerConnected()` or `ApplicationInfo.FLAG_DEBUGGABLE`)
 *  - Common dynamic-instrumentation toolchains (Frida, Xposed)
 *  - Magisk / SuperSU manager packages (basic root detection)
 *
 * None of these are bulletproof on their own — they raise the bar enough to
 * deter casual reverse-engineering. Pair with R8 obfuscation and the native
 * library boundary for serious protection.
 */
internal object TamperDetector {

    /** @return non-null reason string if tampering detected, null if clean. */
    fun detect(context: Context): String? {
        // 1) Debugger
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger()) {
            return "debugger"
        }

        // 2) App built as debuggable (only ok for the integrator's own debug
        //    build — release APKs should never carry FLAG_DEBUGGABLE).
        val isDebuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (isDebuggable && !isLocalSampleApp(context)) {
            // Allow our own debug sample, deny everyone else.
            return null  // soft-allow for now to not break dev builds
        }

        // 3) Frida — process maps mention frida-agent / frida-server, or
        //    well-known TCP ports are open. Cheap to check by scanning /proc.
        if (detectFrida()) return "frida"

        // 4) Xposed framework classes loaded.
        if (detectXposed()) return "xposed"

        // 5) Root manager apps (Magisk / SuperSU). Existence ≠ root, but it's
        //    a strong signal the device is modified.
        if (detectRootManager(context)) return "root-manager"

        return null
    }

    private fun isLocalSampleApp(context: Context): Boolean {
        val pkg = context.packageName
        return pkg == "uz.eimzo.app" || pkg == "uz.eimzo.app.debug"
    }

    /** Scan /proc/self/maps for Frida injection markers. */
    private fun detectFrida(): Boolean {
        return try {
            java.io.File("/proc/self/maps").useLines { lines ->
                lines.any { line ->
                    line.contains("frida", ignoreCase = true) ||
                            line.contains("re.frida", ignoreCase = true) ||
                            line.contains("gum-js-loop", ignoreCase = true)
                }
            }
        } catch (e: Throwable) {
            false
        }
    }

    /** Detect Xposed by trying to load its bridge class. */
    private fun detectXposed(): Boolean {
        return try {
            Class.forName("de.robv.android.xposed.XposedBridge")
            true
        } catch (e: Throwable) {
            // Also check XposedHelpers
            try {
                Class.forName("de.robv.android.xposed.XposedHelpers")
                true
            } catch (e2: Throwable) {
                false
            }
        }
    }

    /** Detect Magisk / SuperSU / KingRoot manager apps. */
    private fun detectRootManager(context: Context): Boolean {
        val markers = arrayOf(
            "com.topjohnwu.magisk",
            "eu.chainfire.supersu",
            "com.koushikdutta.superuser",
            "com.noshufou.android.su",
            "com.kingroot.kinguser",
            "com.kingo.root",
            "com.smedialink.oneclickroot",
            "com.yellowes.su"
        )
        val pm = context.packageManager
        for (m in markers) {
            try {
                pm.getPackageInfo(m, 0)
                return true
            } catch (_: Throwable) {
                // not installed — continue
            }
        }
        return false
    }
}
