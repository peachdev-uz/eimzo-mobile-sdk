package uz.eimzo.sdk.models

data class CertInfo(
    val serialNumber: String,
    val cn: String,
    val o: String?,
    val uid: String?,
    val tin: String?,
    val pinfl: String?,
    val validFrom: String,
    val validTo: String,
    val validNow: Boolean,
    val state: String
)
