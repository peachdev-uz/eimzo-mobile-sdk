package uz.eimzo.sdk.crypto

import pfx2qr.Pfx2qr

/**
 * QR/PFX key crypto operations.
 *
 * pfx2qr.aar: only Pfx2qr.pfX2QR(pfxBytes, password) is available.
 * Signing and public key extraction are implemented natively via OzDST-1092.
 */
internal object QrCryptoManager {

    /** Converts .pfx bytes + password → 68-byte QR key (hex string). */
    fun pfxToQrHex(pfxBytes: ByteArray, password: String): String {
        val qrBytes = Pfx2qr.pfX2QR(pfxBytes, password)
            ?: throw Exception("PFX faylni qayta ishlashda xatolik (noto'g'ri parol?)")
        return HexUtils.toHex(qrBytes)
    }

    /** Returns (pubX, pubY) hex strings for certInfo API. */
    fun getPublicKey(qrDataHex: String, password: String): Pair<String, String> {
        val qrBytes = HexUtils.toBytes(qrDataHex)
        return OzDst1092Signer.getPublicKey(qrBytes, password)
    }

    /** Returns full EC public key (8 curve params) for pki.cert_info RPC. */
    fun getFullPublicKey(qrDataHex: String, password: String): EcPublicKey {
        val qrBytes = HexUtils.toBytes(qrDataHex)
        return OzDst1092Signer.getFullPublicKey(qrBytes, password)
    }

    /** Signs the OzDST 1106 hash of SignedAttributes (forward bytes). */
    fun sign(qrDataHex: String, password: String, saHash: ByteArray): String {
        val qrBytes = HexUtils.toBytes(qrDataHex)
        return OzDst1092Signer.sign(qrBytes, password, saHash)
    }
}
