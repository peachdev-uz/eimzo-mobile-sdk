package uz.eimzo.sdk.crypto

internal class Gost28147Engine {

    companion object {
        const val BLOCK_SIZE = 8

        val SBOX_D_A = intArrayOf(
            0xA, 0x4, 0x5, 0x6, 0x8, 0x1, 0x3, 0x7, 0xD, 0xC, 0xE, 0x0, 0x9, 0x2, 0xB, 0xF,
            0x5, 0xF, 0x4, 0x0, 0x2, 0xD, 0xB, 0x9, 0x1, 0x7, 0x6, 0x3, 0xC, 0xE, 0xA, 0x8,
            0x7, 0xF, 0xC, 0xE, 0x9, 0x4, 0x1, 0x0, 0x3, 0xB, 0x5, 0x2, 0x6, 0xA, 0x8, 0xD,
            0x4, 0xA, 0x7, 0xC, 0x0, 0xF, 0x2, 0x8, 0xE, 0x1, 0x6, 0x5, 0xD, 0xB, 0x9, 0x3,
            0x7, 0x6, 0x4, 0xB, 0x9, 0xC, 0x2, 0xA, 0x1, 0x8, 0x0, 0xE, 0xF, 0xD, 0x3, 0x5,
            0x7, 0x6, 0x2, 0x4, 0xD, 0x9, 0xF, 0x0, 0xA, 0x1, 0x5, 0xB, 0x8, 0xE, 0xC, 0x3,
            0xD, 0xE, 0x4, 0x1, 0x7, 0x0, 0x5, 0xA, 0x3, 0xC, 0x8, 0xF, 0x6, 0x2, 0x9, 0xB,
            0x1, 0x3, 0xA, 0x9, 0x5, 0xB, 0x4, 0xF, 0x8, 0x6, 0x7, 0xE, 0xD, 0x0, 0x2, 0xC
        )
    }

    private var workingKey = IntArray(8)
    private var forEncryption = false
    private val sBox = SBOX_D_A.copyOf()

    fun init(forEncryption: Boolean, key: ByteArray) {
        require(key.size == 32) { "Key must be 32 bytes" }
        this.forEncryption = forEncryption
        for (i in 0 until 8) {
            workingKey[i] = bytesToInt(key, i * 4)
        }
    }

    fun processBlock(inp: ByteArray, inOff: Int, out: ByteArray, outOff: Int) {
        gost28147Func(inp, inOff, out, outOff)
    }

    private fun mainStep(n1: Int, key: Int): Int {
        val cm = (key.toLong() + n1.toLong()).toInt()
        var om = sBox[0  + ((cm ushr (0 * 4)) and 0xF)] shl (0 * 4)
        om += sBox[16 + ((cm ushr (1 * 4)) and 0xF)] shl (1 * 4)
        om += sBox[32 + ((cm ushr (2 * 4)) and 0xF)] shl (2 * 4)
        om += sBox[48 + ((cm ushr (3 * 4)) and 0xF)] shl (3 * 4)
        om += sBox[64 + ((cm ushr (4 * 4)) and 0xF)] shl (4 * 4)
        om += sBox[80 + ((cm ushr (5 * 4)) and 0xF)] shl (5 * 4)
        om += sBox[96 + ((cm ushr (6 * 4)) and 0xF)] shl (6 * 4)
        om += sBox[112 + ((cm ushr (7 * 4)) and 0xF)] shl (7 * 4)
        return (om shl 11) or (om ushr (32 - 11))
    }

    private fun gost28147Func(inp: ByteArray, inOff: Int, out: ByteArray, outOff: Int) {
        var n1 = bytesToInt(inp, inOff)
        var n2 = bytesToInt(inp, inOff + 4)
        var tmp: Int
        if (forEncryption) {
            for (k in 0 until 3) {
                for (j in 0 until 8) {
                    tmp = n1; n1 = n2 xor mainStep(n1, workingKey[j]); n2 = tmp
                }
            }
            for (j in 7 downTo 1) {
                tmp = n1; n1 = n2 xor mainStep(n1, workingKey[j]); n2 = tmp
            }
        } else {
            for (j in 0 until 8) {
                tmp = n1; n1 = n2 xor mainStep(n1, workingKey[j]); n2 = tmp
            }
            for (k in 0 until 3) {
                for (j in 7 downTo 0) {
                    if (k == 2 && j == 0) break
                    tmp = n1; n1 = n2 xor mainStep(n1, workingKey[j]); n2 = tmp
                }
            }
        }
        n2 = n2 xor mainStep(n1, workingKey[0])
        intToBytes(n1, out, outOff)
        intToBytes(n2, out, outOff + 4)
    }

    private fun bytesToInt(inp: ByteArray, off: Int): Int =
        ((inp[off + 3].toInt() and 0xFF) shl 24) or
        ((inp[off + 2].toInt() and 0xFF) shl 16) or
        ((inp[off + 1].toInt() and 0xFF) shl 8) or
        (inp[off].toInt() and 0xFF)

    private fun intToBytes(num: Int, out: ByteArray, off: Int) {
        out[off + 3] = ((num ushr 24) and 0xFF).toByte()
        out[off + 2] = ((num ushr 16) and 0xFF).toByte()
        out[off + 1] = ((num ushr 8) and 0xFF).toByte()
        out[off]     = (num and 0xFF).toByte()
    }
}
