package uz.eimzo.sdk.license

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import uz.eimzo.sdk.R

/**
 * Full-screen "license blocked" UI shown when [LicenseGuard.verify] returns
 * `isAllowed = false`. Displays the integrator's package name and signature hash
 * so they can be sent to the YT team for registration.
 *
 * Launch from any context with [show].
 */
class BlockedAppActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.eimzo_activity_blocked_app)

        val packageName = intent.getStringExtra(EXTRA_PACKAGE).orEmpty()
        val errorMessage = intent.getStringExtra(EXTRA_ERROR).orEmpty()

        val toolbar = findViewById<Toolbar>(R.id.eimzoBlockedToolbar)
        toolbar.setNavigationOnClickListener { finishAffinity() }

        bindInfoCard(
            cardId = R.id.cardPackage,
            title = "Package Name",
            value = packageName.ifEmpty { "— (topilmadi)" },
            monospace = true,
            isError = false
        )

        val errorCardRoot = findViewById<View>(R.id.cardError)
        if (errorMessage.isNotEmpty()) {
            errorCardRoot.visibility = View.VISIBLE
            bindInfoCard(
                cardId = R.id.cardError,
                title = "Xato",
                value = errorMessage,
                monospace = false,
                isError = true
            )
        } else {
            errorCardRoot.visibility = View.GONE
        }

        val emailTv = findViewById<TextView>(R.id.tvContactEmail)
        emailTv.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:${emailTv.text}")
                putExtra(Intent.EXTRA_SUBJECT, "E-IMZO SDK integratsiya so'rovi")
                putExtra(Intent.EXTRA_TEXT, "Package: $packageName")
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                copy(emailTv.text.toString(), "Email")
            }
        }

        val btnRequest = findViewById<Button>(R.id.btnRequestAccess)
        btnRequest.setOnClickListener {
            showRequestAccessDialog()
        }
    }

    /**
     * Email kiritish va Firestore'ga pending so'rov yuborish dialogi.
     */
    private fun showRequestAccessDialog() {
        val dialogView = layoutInflater.inflate(R.layout.eimzo_dialog_request_access, null)
        val emailField = dialogView.findViewById<TextInputEditText>(R.id.etEmail)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Ruxsat so'rash")
            .setView(dialogView)
            .setPositiveButton("Yuborish", null)  // override below so we don't auto-dismiss
            .setNegativeButton("Bekor qilish", null)
            .create()

        dialog.setOnShowListener {
            val sendBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            sendBtn.setOnClickListener {
                val email = emailField.text?.toString().orEmpty().trim()
                if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    emailField.error = "Email noto'g'ri"
                    return@setOnClickListener
                }

                sendBtn.isEnabled = false
                sendBtn.text = "Yuborilmoqda…"

                lifecycleScope.launch {
                    val ok = LicenseGuard.submitAccessRequest(this@BlockedAppActivity, email)
                    dialog.dismiss()
                    if (ok) {
                        showRequestSubmittedDialog(email)
                    } else {
                        Toast.makeText(
                            this@BlockedAppActivity,
                            "So'rovni yuborib bo'lmadi. Internet ulanishini tekshiring.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        dialog.show()
    }

    private fun showRequestSubmittedDialog(email: String) {
        AlertDialog.Builder(this)
            .setTitle("So'rov yuborildi")
            .setMessage(
                "$email pochtangiz orqali so'rovingiz qabul qilindi. " +
                        "Admin tasdiqlagandan keyin ilovani qaytadan ishga tushiring.\n\n" +
                        "Tasdiqlash 1-2 ish kuni davom etishi mumkin."
            )
            .setPositiveButton("Tushundim", null)
            .show()
    }

    private fun bindInfoCard(
        cardId: Int,
        title: String,
        value: String,
        monospace: Boolean,
        isError: Boolean
    ) {
        val root = findViewById<View>(cardId)
        val titleTv = root.findViewById<TextView>(R.id.tvCardTitle)
        val valueTv = root.findViewById<TextView>(R.id.tvCardValue)

        titleTv.text = title
        valueTv.text = value

        if (isError) {
            root.setBackgroundResource(R.drawable.eimzo_blocked_info_bg_error)
            titleTv.setTextColor(0xFFC62828.toInt())
            valueTv.setTextColor(0xFFC62828.toInt())
        } else {
            root.setBackgroundResource(R.drawable.eimzo_blocked_info_bg)
            titleTv.setTextColor(0xFF757575.toInt())
            valueTv.setTextColor(0xFF212121.toInt())
        }

        if (monospace) {
            valueTv.typeface = android.graphics.Typeface.MONOSPACE
        }

        root.setOnLongClickListener {
            copy(value, title)
            true
        }
    }

    private fun copy(text: String, label: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "$label nusxalandi", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val EXTRA_PACKAGE = "package_name"
        private const val EXTRA_ERROR = "error"

        /**
         * Launch the blocked-app screen. Launches in a new task so the host
         * activity can safely call `finish()` afterwards without killing this
         * screen too.
         */
        internal fun show(context: Context, result: LicenseResult) {
            val intent = Intent(context, BlockedAppActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(EXTRA_PACKAGE, result.packageName)
                putExtra(EXTRA_ERROR, result.error)
            }
            context.startActivity(intent)
        }
    }
}
