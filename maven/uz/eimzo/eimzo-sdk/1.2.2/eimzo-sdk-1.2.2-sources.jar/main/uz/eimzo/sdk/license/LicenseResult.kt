package uz.eimzo.sdk.license

/**
 * Result of LicenseGuard.verify() — describes whether the host (integrator)
 * application is allowed to use the E-IMZO SDK.
 */
internal data class LicenseResult(
    val isAllowed: Boolean = false,
    val packageName: String = "",
    val error: String = ""
)
