package uz.eimzo.sdk.crypto

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * PKI utilities for building PKCS#7 SignedAttributes.
 *
 * Wire format (matches `idcard_eimzo` Flutter package `lib/pki/pki.dart`):
 *
 *   SignedAttributes (DER hex prefix):
 *     31 69
 *     30 18 06 09 2a 86 48 86 f7 0d 01 09 03 31 0b 06 09 2a 86 48 86 f7 0d 01 07 01
 *     30 1c 06 09 2a 86 48 86 f7 0d 01 09 05 31 0f 17 0d <utcHex>
 *     30 2f 06 09 2a 86 48 86 f7 0d 01 09 04 31 22 04 20 <hashHex>
 *
 *   Hash: OzDST 1106 (NOT SHA-256) — matches GOST 34.311 style hash.
 *   No byte reversal of the hash; pass forward bytes to OzDST 1092 signer.
 *
 * Returns three ByteArrays:
 *  [0] - DER-encoded SignedAttributes bytes (used inside PKCS#7)
 *  [1] - OzDST 1106 hash of SignedAttributes (forward bytes, ready to sign)
 *  [2] - signing time as ASCII bytes "YYMMDDHHmmssZ"
 */
internal object PkiUtils {

    private val sdf = SimpleDateFormat("yyMMddHHmmss", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun buildSignedAttributesAndHash(hashHex: String): Array<ByteArray> {
        val hashBytes = HexUtils.toBytes(hashHex)
        require(hashBytes.size == 32) { "hash must be 32 bytes (got ${hashBytes.size})" }

        // YYMMDDHHmmssZ (13 ASCII bytes)
        val timeStr = sdf.format(Date()) + "Z"
        val timeBytes = timeStr.toByteArray(Charsets.US_ASCII)
        require(timeBytes.size == 13) { "UTC time must be 13 bytes" }

        // Hex-prefix concatenation per idcard_eimzo:
        //   31 69 30 18 06 09 2a 86 48 86 f7 0d 01 09 03 31 0b 06 09 2a 86 48 86 f7 0d 01 07 01
        //   30 1c 06 09 2a 86 48 86 f7 0d 01 09 05 31 0f 17 0d <UTC 13 bytes>
        //   30 2f 06 09 2a 86 48 86 f7 0d 01 09 04 31 22 04 20 <HASH 32 bytes>
        val prefix1 = HexUtils.toBytes(
            "3169301806092a864886f70d010903310b06092a864886f70d010701" +
                    "301c06092a864886f70d010905310f170d"
        )
        val prefix2 = HexUtils.toBytes("302f06092a864886f70d01090431220420")

        val signedAttributes = prefix1 + timeBytes + prefix2 + hashBytes

        // Hash with OzDST 1106 (GOST 34.311 family) — NOT SHA-256.
        val digest = OzDst1106Digest()
        digest.update(signedAttributes)
        val saHash = ByteArray(32)
        digest.doFinal(saHash, 0)

        // No reversal: OzDST 1092 signer expects forward bytes (treats them as
        // BigInteger with index 0 = most significant byte).
        return arrayOf(signedAttributes, saHash, timeBytes)
    }
}
