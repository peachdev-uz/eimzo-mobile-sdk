package uz.eimzo.sdk.fullui.keys

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import uz.eimzo.sdk.R
import uz.eimzo.sdk.databinding.EimzoUiFragmentKeysBinding
import uz.eimzo.sdk.fullui.addkey.AddKeyBottomSheet
import uz.eimzo.sdk.fullui.scanner.QrScannerActivity
import uz.eimzo.sdk.fullui.util.PasswordDialog
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.ui.LoadingOverlay
import uz.eimzo.sdk.ui.NfcWaitBottomSheet

class KeysFragment : Fragment() {

    private var _binding: EimzoUiFragmentKeysBinding? = null
    private val binding get() = _binding!!
    private val viewModel: KeysViewModel by viewModels()
    private lateinit var adapter: KeyAdapter
    private var currentKeys: List<PfxKey> = emptyList()

    private var nfcAdapter: NfcAdapter? = null
    private var pendingNfcPin: String? = null
    private var pendingNfcSavePassword: Boolean = true
    private var nfcWaitSheet: NfcWaitBottomSheet? = null

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            PasswordDialog.show(
                requireContext(),
                getString(R.string.eimzo_ui_enter_eri_password)
            ) { password, savePassword ->
                importPfx(uri, password, savePassword)
            }
        }
    }

    private val qrScanner = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (contents != null) {
            PasswordDialog.show(
                requireContext(),
                getString(R.string.eimzo_ui_enter_eri_password)
            ) { password, savePassword ->
                importQr(contents, password, savePassword)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = EimzoUiFragmentKeysBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nfcAdapter = NfcAdapter.getDefaultAdapter(requireContext())

        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_delete -> {
                    val defaultKey = currentKeys.firstOrNull { it.isDefault }
                        ?: currentKeys.firstOrNull()
                    if (defaultKey != null) confirmDelete(defaultKey)
                    true
                }
                else -> false
            }
        }

        adapter = KeyAdapter(
            onClick = { key -> viewModel.setDefault(key) },
            onLongClick = { key -> confirmDelete(key) }
        )
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            showAddKeySheet()
        }

        viewModel.keys.observe(viewLifecycleOwner) { keys ->
            currentKeys = keys
            adapter.submitList(keys)
            binding.tvEmpty.visibility = if (keys.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun showAddKeySheet() {
        val sheet = AddKeyBottomSheet()
        sheet.onActionSelected = { action ->
            when (action) {
                AddKeyBottomSheet.Action.FILE -> filePicker.launch("application/x-pkcs12")
                AddKeyBottomSheet.Action.QR -> launchQrScanner()
                AddKeyBottomSheet.Action.NFC -> startNfcAddFlow()
            }
        }
        sheet.show(childFragmentManager, AddKeyBottomSheet.TAG)
    }

    // ──────────────────────────────────────────────────────────────────
    // NFC add-key flow (matches Flutter UX):
    //   tap "NFC orqali" → password dialog → wait-for-card bottom sheet
    //   → EImzoActivity dispatches the Tag → onNfcTagDiscovered → SDK import
    // ──────────────────────────────────────────────────────────────────

    private fun startNfcAddFlow() {
        if (nfcAdapter == null) {
            Toast.makeText(requireContext(), "Qurilmada NFC yo'q", Toast.LENGTH_LONG).show()
            return
        }
        if (nfcAdapter?.isEnabled == false) {
            Toast.makeText(requireContext(), "Iltimos NFC ni yoqing", Toast.LENGTH_LONG).show()
            return
        }
        PasswordDialog.show(
            requireContext(),
            title = "ID kartaning ERI parolini kiriting"
        ) { pin, savePassword ->
            pendingNfcPin = pin
            pendingNfcSavePassword = savePassword
            enableNfcForeground()
            showNfcWaitSheet()
        }
    }

    private fun showNfcWaitSheet() {
        nfcWaitSheet?.dismiss()
        nfcWaitSheet = NfcWaitBottomSheet()
            .setOnDismiss {
                pendingNfcPin = null
                disableNfcForeground()
                nfcWaitSheet = null
            }
        nfcWaitSheet?.show(childFragmentManager, NfcWaitBottomSheet.TAG)
    }

    private fun enableNfcForeground() {
        val activity = requireActivity()
        val intent = Intent(activity, activity.javaClass)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            activity, 0, intent,
            PendingIntent.FLAG_MUTABLE
        )
        nfcAdapter?.enableForegroundDispatch(activity, pi, null, null)
    }

    private fun disableNfcForeground() {
        try { nfcAdapter?.disableForegroundDispatch(requireActivity()) } catch (_: Exception) {}
    }

    /** Called from EImzoActivity.onNewIntent when an NFC tag arrives. */
    fun onNfcTagDiscovered(tag: Tag) {
        val pin = pendingNfcPin ?: return
        val savePassword = pendingNfcSavePassword
        pendingNfcPin = null
        disableNfcForeground()

        // Show reading-state Lottie while the SDK talks to the card
        nfcWaitSheet?.setState(NfcWaitBottomSheet.NfcState.READING)

        EImzoSDK.get().importNfcKey(tag, pin, savePassword, object : ImportKeyCallback {
            override fun onSuccess(key: PfxKey) {
                // Briefly show success state, then dismiss
                nfcWaitSheet?.setState(NfcWaitBottomSheet.NfcState.SUCCESS)
                view?.postDelayed({
                    nfcWaitSheet?.dismiss(); nfcWaitSheet = null
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.eimzo_ui_key_added_success),
                        Toast.LENGTH_SHORT
                    ).show()
                }, 1200)
            }

            override fun onError(error: String) {
                nfcWaitSheet?.setState(NfcWaitBottomSheet.NfcState.ERROR, error)
                view?.postDelayed({
                    nfcWaitSheet?.dismiss(); nfcWaitSheet = null
                    Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                }, 1500)
            }
        })
    }

    override fun onPause() {
        super.onPause()
        disableNfcForeground()
    }

    private fun launchQrScanner() {
        val options = ScanOptions().apply {
            setCaptureActivity(QrScannerActivity::class.java)
            setPrompt("")
            setBeepEnabled(false)
            setOrientationLocked(true)
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setBarcodeImageEnabled(false)
        }
        qrScanner.launch(options)
    }

    private fun importQr(qrText: String, password: String, savePassword: Boolean) {
        val overlay = LoadingOverlay.show(childFragmentManager)
        EImzoSDK.get().importQrKey(qrText, password, savePassword, object : ImportKeyCallback {
            override fun onSuccess(key: PfxKey) {
                overlay.hide()
                Toast.makeText(requireContext(), getString(R.string.eimzo_ui_key_added_success), Toast.LENGTH_SHORT).show()
            }
            override fun onError(error: String) {
                overlay.hide()
                Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun importPfx(uri: Uri, password: String, savePassword: Boolean) {
        try {
            val bytes = requireContext().contentResolver.openInputStream(uri)?.readBytes()
                ?: throw Exception("Faylni o'qib bo'lmadi")
            val overlay = LoadingOverlay.show(childFragmentManager)
            EImzoSDK.get().importPfxKey(bytes, password, savePassword, object : ImportKeyCallback {
                override fun onSuccess(key: PfxKey) {
                    overlay.hide()
                    Toast.makeText(requireContext(), getString(R.string.eimzo_ui_key_added_success), Toast.LENGTH_SHORT).show()
                }
                override fun onError(error: String) {
                    overlay.hide()
                    Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                }
            })
        } catch (e: Exception) {
            Toast.makeText(requireContext(), e.message ?: "Xatolik", Toast.LENGTH_LONG).show()
        }
    }

    /** Adjust password dialog call to new 2-arg signature. */
    private fun showPfxPasswordDialog(uri: Uri) {
        PasswordDialog.show(
            requireContext(),
            title = getString(R.string.eimzo_ui_enter_eri_password)
        ) { password, savePassword -> importPfx(uri, password, savePassword) }
    }

    private fun confirmDelete(key: PfxKey) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.eimzo_ui_delete_key))
            .setMessage(getString(R.string.eimzo_ui_delete_key_confirm, key.name))
            .setPositiveButton(getString(R.string.eimzo_ui_delete)) { _, _ -> viewModel.delete(key) }
            .setNegativeButton(getString(R.string.eimzo_ui_cancel), null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
