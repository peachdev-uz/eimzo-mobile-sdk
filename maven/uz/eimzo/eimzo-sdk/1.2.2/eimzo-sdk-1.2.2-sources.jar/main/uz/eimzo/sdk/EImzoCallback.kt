package uz.eimzo.sdk

import uz.eimzo.sdk.models.CertInfo
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.models.SignResult
import uz.eimzo.sdk.usb.UsbTokenManager

interface ImportKeyCallback {
    fun onSuccess(key: PfxKey)
    fun onError(error: String)
}

interface SignCallback {
    fun onSuccess(result: SignResult.Success)
    fun onError(error: SignResult.Failure)
}

interface CertInfoCallback {
    fun onSuccess(certInfo: CertInfo)
    fun onError(error: String)
}

/**
 * Callback for the low-level [EImzoSDK.signUsbHash] primitive.
 * `serialNumber` is hex; `signature` is hex.
 */
internal interface UsbSignCallback {
    fun onSuccess(result: UsbTokenManager.UsbSignResult)
    fun onError(error: String, code: String?)
}
