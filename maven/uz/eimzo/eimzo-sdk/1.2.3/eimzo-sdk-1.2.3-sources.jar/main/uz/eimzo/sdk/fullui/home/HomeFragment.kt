package uz.eimzo.sdk.fullui.home

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import uz.eimzo.sdk.R
import uz.eimzo.sdk.databinding.EimzoUiFragmentHomeBinding
import uz.eimzo.sdk.fullui.EImzoActivity
import uz.eimzo.sdk.fullui.addkey.AddKeyBottomSheet
import uz.eimzo.sdk.fullui.scanner.QrScannerActivity
import uz.eimzo.sdk.ui.LoadingOverlay
import uz.eimzo.sdk.ui.NfcWaitBottomSheet
import uz.eimzo.sdk.fullui.util.PasswordDialog
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.usb.UsbTokenDetector

class HomeFragment : Fragment() {

    private var _binding: EimzoUiFragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private var nfcAdapter: NfcAdapter? = null
    private var pendingNfcPin: String? = null

    /**
     * "Kartani yaqinlashtiring" bottom sheet shown during the NFC sign flow.
     * Mirrors the UX used in KeysFragment for NFC key import — the three
     * Lottie states (WAITING / READING / SUCCESS or ERROR) give the user
     * clear feedback while the SDK talks to the card. Null when not signing.
     */
    private var nfcSignWaitSheet: NfcWaitBottomSheet? = null

    /**
     * Watches USB attach/detach so the "USB Token orqali imzolash" button is
     * only active while a reader is physically plugged in. Registered as a
     * lifecycle observer on the view's lifecycle in [onViewCreated] — it
     * tears down automatically in onStop / onDestroyView.
     */
    private lateinit var usbTokenDetector: UsbTokenDetector

    /**
     * Remembered across re-renders so a SignState callback (Idle/Error) can
     * restore the correct enabled state without re-querying the system.
     */
    private var usbTokenConnected: Boolean = false

    /** True when the activity was launched (or re-entered) via an `eimzo://...` deeplink. */
    private var launchedViaDeeplink: Boolean = false

    /** Scanner for capturing a sign-document QR (deeplink) — saved-key sign. */
    private val signQrScanner = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (contents != null) {
            handleSignDeeplink(contents)
        }
    }

    /**
     * Scanner for capturing a sign-document QR — but the post-scan action
     * is USB-token sign instead of saved-key sign. We keep this as a
     * separate launcher (rather than threading state through `signQrScanner`)
     * so the two flows can't accidentally collide. After the QR resolves
     * we hand off to [promptUsbPinAndSign].
     */
    private val signWithUsbQrScanner = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents ?: return@registerForActivityResult
        viewModel.setDeepLink(contents)
        promptUsbPinAndSign()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = EimzoUiFragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nfcAdapter = NfcAdapter.getDefaultAdapter(requireContext())

        usbTokenDetector = UsbTokenDetector(requireContext().applicationContext)
        viewLifecycleOwner.lifecycle.addObserver(usbTokenDetector)

        // Check for deeplink from activity. Only push it into the ViewModel
        // if one isn't already in flight — otherwise re-entering this screen
        // after a back-stack pop would reset the running 103-second timer.
        val activity = requireActivity() as EImzoActivity
        val dl = activity.getPendingDeepLink()
            ?: arguments?.getString("deepLink")
        if (dl != null) {
            launchedViaDeeplink = true
            if (viewModel.deepLink.value.isNullOrEmpty()) {
                viewModel.setDeepLink(dl)
            }
        } else if (!viewModel.deepLink.value.isNullOrEmpty()) {
            // We came back from the Keys screen and there is already an
            // active sign session in progress — keep the back affordance
            // on so the user can still bail out to the calling app.
            launchedViaDeeplink = true
        }

        setupObservers()
        setupClickListeners()
    }

    private fun setupObservers() {
        usbTokenDetector.isConnected.observe(viewLifecycleOwner) { connected ->
            usbTokenConnected = connected
            // Only flip the button state while we're Idle/Error — leave Loading
            // and Success alone so an in-flight or completed sign isn't visually
            // disturbed by a detach event mid-flow.
            val state = viewModel.signState.value
            if (state is HomeViewModel.SignState.Idle || state is HomeViewModel.SignState.Error) {
                applyUsbButtonState(connected)
            }
        }

        viewModel.currentKey.observe(viewLifecycleOwner) { key ->
            updateKeyCard(key)
        }

        viewModel.deepLink.observe(viewLifecycleOwner) { deepLink ->
            // Only toggle the card visibility — we intentionally don't
            // surface the raw QR hash, since it's a meaningless hex blob
            // to the end user. tvDeepLinkInfo is kept in the layout as
            // an ABI-compat shim but stays GONE.
            binding.cardDeepLink.visibility = if (deepLink != null) View.VISIBLE else View.GONE
        }

        // Tick down the 103-second sign session and reflect it in the card.
        // The ViewModel owns the countdown coroutine so it survives
        // Home → Keys → Home navigation (the user can leave to add a key
        // and come back without losing time).
        viewModel.sessionRemaining.observe(viewLifecycleOwner) { secs ->
            if (secs > 0) {
                binding.tvSessionTimer.visibility = View.VISIBLE
                val m = secs / 60
                val s = secs % 60
                binding.tvSessionTimer.text =
                    getString(R.string.eimzo_ui_session_remaining, m, s)
            } else {
                binding.tvSessionTimer.visibility = View.GONE
            }
        }

        // One-shot toast on natural session expiry. The ViewModel flips
        // this back to false after we consume it so it doesn't re-fire
        // on config changes. We deliberately DO NOT close the activity or
        // clear the deeplink — the user might still be mid-flow (e.g. adding
        // an NFC key, which routinely takes longer than the 103-second
        // window). If the server-side QR is truly expired, the signing call
        // will fail with a normal error, which the user can see and act on.
        viewModel.sessionExpired.observe(viewLifecycleOwner) { expired ->
            if (expired) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.eimzo_ui_session_expired),
                    Toast.LENGTH_LONG
                ).show()
                viewModel.acknowledgeSessionExpired()
            }
        }

        viewModel.signState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is HomeViewModel.SignState.Idle -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = viewModel.currentKey.value != null
                    binding.btnSign.text = getString(R.string.eimzo_ui_sign)
                    applyUsbButtonState(usbTokenConnected)
                }
                is HomeViewModel.SignState.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.btnSign.isEnabled = false
                    binding.btnSign.text = getString(R.string.eimzo_ui_signing)
                    binding.btnSignWithUsb.isEnabled = false
                }
                is HomeViewModel.SignState.WaitingNfc -> {
                    binding.progressBar.visibility = View.GONE
                    showNfcPasswordDialog()
                }
                is HomeViewModel.SignState.NeedPassword -> {
                    binding.progressBar.visibility = View.GONE
                    showPasswordDialog(state.keyType)
                }
                is HomeViewModel.SignState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = false
                    binding.btnSign.text = getString(R.string.eimzo_ui_signed)
                    binding.btnSignWithUsb.isEnabled = false
                    binding.tvSignResult.visibility = View.VISIBLE
                    binding.tvSignResult.text = "${state.result.state}: ${state.result.message ?: ""}"
                    // Briefly flash the NFC wait sheet's SUCCESS lottie (if it
                    // was the NFC sign path) before dismissing it.
                    nfcSignWaitSheet?.let { sheet ->
                        sheet.setState(NfcWaitBottomSheet.NfcState.SUCCESS)
                        view?.postDelayed({
                            sheet.dismiss()
                            nfcSignWaitSheet = null
                        }, 1000)
                    }
                    Toast.makeText(
                        requireContext(),
                        getString(R.string.eimzo_ui_sign_success),
                        Toast.LENGTH_SHORT
                    ).show()
                    // If we got here via an external eimzo:// deeplink, the integrator
                    // app is waiting — auto-close after a short success delay.
                    if (launchedViaDeeplink) {
                        binding.btnSign.postDelayed({
                            requireActivity().finishAndRemoveTask()
                        }, 1500)
                    }
                }
                is HomeViewModel.SignState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.btnSign.isEnabled = viewModel.currentKey.value != null
                    binding.btnSign.text = getString(R.string.eimzo_ui_sign)
                    applyUsbButtonState(usbTokenConnected)
                    // Flash ERROR lottie on the NFC wait sheet if it's still
                    // up, then dismiss after a moment. Toast remains the
                    // primary error surface so the user has a persistent log.
                    nfcSignWaitSheet?.let { sheet ->
                        sheet.setState(NfcWaitBottomSheet.NfcState.ERROR, state.message)
                        view?.postDelayed({
                            sheet.dismiss()
                            nfcSignWaitSheet = null
                        }, 1500)
                    }
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnSign.setOnClickListener {
            val key = viewModel.currentKey.value ?: run {
                Toast.makeText(requireContext(), getString(R.string.eimzo_ui_no_key_selected), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // If no deeplink yet, scan a QR code containing the sign-deeplink first
            if (viewModel.deepLink.value == null) {
                launchSignQrScanner()
                return@setOnClickListener
            }
            initiateSign(key)
        }

        // USB token sign — sign-only path that does NOT need a saved key.
        //   1. Get a deeplink (scan QR if we don't have one yet)
        //   2. Prompt for PIN
        //   3. sdk.signWithUsbToken(pin, deepLink, …)
        //
        // Each tap opens a fresh FT-reader session. Nothing about the
        // token is persisted. Button is only clickable while a USB reader
        // is plugged in — gated by [usbTokenConnected] via [UsbTokenDetector].
        binding.btnSignWithUsb.setOnClickListener {
            if (!usbTokenConnected) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.eimzo_ui_usb_token_not_connected),
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            if (viewModel.deepLink.value == null) {
                Toast.makeText(
                    requireContext(),
                    getString(R.string.eimzo_ui_scan_deeplink_qr),
                    Toast.LENGTH_SHORT
                ).show()
                val options = ScanOptions().apply {
                    setCaptureActivity(QrScannerActivity::class.java)
                    setPrompt("")
                    setBeepEnabled(false)
                    setOrientationLocked(true)
                    setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                    setBarcodeImageEnabled(false)
                }
                signWithUsbQrScanner.launch(options)
            } else {
                promptUsbPinAndSign()
            }
        }

        binding.btnSeeAll.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.cardKey.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.tvNoKey.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.rowAddEri.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_keys)
        }

        binding.btnMenu.setOnClickListener {
            Toast.makeText(requireContext(), "Menu (tez orada)", Toast.LENGTH_SHORT).show()
        }

        binding.btnHelp.setOnClickListener {
            Toast.makeText(requireContext(), "Yordam (tez orada)", Toast.LENGTH_SHORT).show()
        }

        // Back affordance: only shown when the SDK was opened via an external
        // eimzo:// deeplink (i.e. the integrator app is waiting). Tapping it
        // tears down the SDK task and returns control to the caller. In
        // standalone-launch mode the back arrow stays hidden — the user can
        // exit via the system back button as before.
        if (launchedViaDeeplink) {
            binding.btnBack.visibility = View.VISIBLE
            binding.btnMenu.visibility = View.GONE
            binding.btnBack.setOnClickListener {
                viewModel.clearDeepLinkSession()
                requireActivity().finishAndRemoveTask()
            }
        }
    }

    /** Launch QR scanner to capture a sign-deeplink (e.g. eimzo://sign?qc=...). */
    private fun launchSignQrScanner() {
        Toast.makeText(requireContext(), getString(R.string.eimzo_ui_scan_deeplink_qr), Toast.LENGTH_SHORT).show()
        val options = ScanOptions().apply {
            setCaptureActivity(QrScannerActivity::class.java)
            setPrompt("")
            setBeepEnabled(false)
            setOrientationLocked(true)
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setBarcodeImageEnabled(false)
        }
        signQrScanner.launch(options)
    }

    /**
     * Handle a scanned/received sign-deeplink: store in ViewModel and proceed
     * with signing — using the saved password if available, otherwise prompting.
     */
    private fun handleSignDeeplink(deepLink: String) {
        viewModel.setDeepLink(deepLink)
        val key = viewModel.currentKey.value ?: return
        initiateSign(key)
    }

    /**
     * Prompt for the USB token PIN, then kick off the sign via the
     * ViewModel. We use the simpler PasswordDialog overload (no
     * save-password callback) — USB token sign is intentionally transient
     * and nothing is persisted. The "Parolni saqlash" checkbox in the
     * dialog UI is ignored for this flow.
     */
    private fun promptUsbPinAndSign() {
        PasswordDialog.show(
            requireContext(),
            getString(R.string.eimzo_ui_enter_usb_pin)
        ) { pin ->
            Toast.makeText(
                requireContext(),
                getString(R.string.eimzo_ui_usb_token_hint),
                Toast.LENGTH_LONG
            ).show()
            viewModel.signWithUsb(pin)
        }
    }

    /**
     * Begin the signing operation for [key]. Uses the password stored on the
     * key (if the user opted to save it at import time) — otherwise prompts.
     */
    private fun initiateSign(key: PfxKey) {
        val savedPassword = key.password
        if (!savedPassword.isNullOrEmpty()) {
            when (key.keyType) {
                KeyType.QR_PFX -> viewModel.signWithCurrentKey(savedPassword)
                KeyType.NFC_ID -> startNfcSignFlow(savedPassword)
                KeyType.USB_TOKEN -> viewModel.signWithUsb(savedPassword)
            }
        } else {
            when (key.keyType) {
                KeyType.QR_PFX -> showPasswordDialog(KeyType.QR_PFX)
                KeyType.NFC_ID -> showNfcPasswordDialog()
                KeyType.USB_TOKEN -> showPasswordDialog(KeyType.USB_TOKEN)
            }
        }
    }

    // Note: PFX/QR key import is handled in KeysFragment now —
    // Home only handles signing.

    private fun updateKeyCard(key: PfxKey?) {
        if (key == null) {
            binding.cardKey.visibility = View.GONE
            binding.tvNoKey.visibility = View.VISIBLE
            binding.headerKeys.visibility = View.GONE
            binding.btnSign.visibility = View.GONE
        } else {
            binding.cardKey.visibility = View.VISIBLE
            binding.tvNoKey.visibility = View.GONE
            binding.headerKeys.visibility = View.VISIBLE
            binding.btnSign.visibility = View.VISIBLE
            binding.btnSign.isEnabled = true
            binding.tvKeyName.text = if (key.tin != null) key.organization ?: key.name else key.name
            binding.tvKeyId.text = if (key.tin != null) key.tin else key.uid ?: ""
            binding.tvKeyPinfl.text = key.pinfl ?: getString(R.string.eimzo_ui_not_given)
            binding.tvKeyExpiry.text = key.validTo
        }
    }

    /**
     * Reflect USB connection state on the "USB Token orqali imzolash" button.
     * When [connected] is false the button is disabled and shows a "ulang"
     * hint label; when true it returns to the regular call-to-action label.
     * Only called from Idle/Error states — Loading/Success/WaitingNfc manage
     * their own button visuals.
     */
    private fun applyUsbButtonState(connected: Boolean) {
        if (_binding == null) return
        binding.btnSignWithUsb.isEnabled = connected
        binding.btnSignWithUsb.text = if (connected) {
            getString(R.string.eimzo_ui_sign_with_usb)
        } else {
            getString(R.string.eimzo_ui_usb_token_not_connected)
        }
    }

    private fun showPasswordDialog(keyType: KeyType) {
        val title = when (keyType) {
            KeyType.QR_PFX -> getString(R.string.eimzo_ui_enter_eri_password)
            KeyType.NFC_ID -> getString(R.string.eimzo_ui_enter_id_pin)
            KeyType.USB_TOKEN -> getString(R.string.eimzo_ui_enter_usb_pin)
        }
        PasswordDialog.show(requireContext(), title) { password, _savePassword ->
            // Note: savePassword here would only matter if we re-stored the
            // password against the key. For now, prompt-on-demand passwords
            // are not persisted — that decision was made at import time.
            when (keyType) {
                KeyType.QR_PFX -> viewModel.signWithCurrentKey(password)
                KeyType.USB_TOKEN -> viewModel.signWithUsb(password)
                KeyType.NFC_ID -> startNfcSignFlow(password)
            }
        }
    }

    private fun startNfcSignFlow(pin: String) {
        pendingNfcPin = pin
        enableNfcForeground()
        showNfcSignWaitSheet()
    }

    /**
     * Show the "Kartani yaqinlashtiring" bottom sheet for the sign flow.
     * Replays the same Lottie WAITING animation used by the key-import
     * flow. Dismissing the sheet (user swipe / outside tap) cancels the
     * NFC sign attempt — pin is cleared and foreground dispatch torn down.
     */
    private fun showNfcSignWaitSheet() {
        nfcSignWaitSheet?.dismiss()
        nfcSignWaitSheet = NfcWaitBottomSheet()
            .setOnDismiss {
                pendingNfcPin = null
                disableNfcForeground()
                nfcSignWaitSheet = null
            }
        nfcSignWaitSheet?.show(childFragmentManager, NfcWaitBottomSheet.TAG)
    }

    private fun showNfcPasswordDialog() {
        showPasswordDialog(KeyType.NFC_ID)
    }

    // ──────────────────────────────────────────────────────────────────
    // NFC Foreground dispatch
    // ──────────────────────────────────────────────────────────────────

    private fun enableNfcForeground() {
        val activity = requireActivity()
        val intent = Intent(activity, activity.javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pendingIntent = PendingIntent.getActivity(activity, 0, intent, PendingIntent.FLAG_MUTABLE)
        nfcAdapter?.enableForegroundDispatch(activity, pendingIntent, null, null)
    }

    private fun disableNfcForeground() {
        // disableForegroundDispatch throws IllegalStateException if the
        // activity is not RESUMED. When this is called from
        // onNfcTagDiscovered (the OS-dispatched intent path), the activity
        // is mid-pause→resume and the call will throw. Catching the
        // exception is the documented workaround — the system unregisters
        // foreground dispatch automatically when the activity pauses, so
        // missing this call is a no-op.
        try { nfcAdapter?.disableForegroundDispatch(requireActivity()) } catch (_: Exception) {}
    }

    fun onNfcTagDiscovered(tag: Tag) {
        val pin = pendingNfcPin ?: return
        pendingNfcPin = null
        disableNfcForeground()
        // Flip the wait sheet to its "reading" Lottie state — gives the
        // user feedback while the SDK is talking to the card.
        nfcSignWaitSheet?.setState(NfcWaitBottomSheet.NfcState.READING)
        viewModel.signWithNfcTag(tag, pin)
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshCurrentKey()
        if (pendingNfcPin != null) enableNfcForeground()
    }

    override fun onPause() {
        super.onPause()
        disableNfcForeground()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
