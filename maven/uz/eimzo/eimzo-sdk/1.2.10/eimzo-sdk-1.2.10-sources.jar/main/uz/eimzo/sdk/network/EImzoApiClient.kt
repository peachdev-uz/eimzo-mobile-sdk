package uz.eimzo.sdk.network

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

internal class EImzoApiClient(private val apiUrl: String) {

    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private suspend fun <T> rpcCall(method: String, params: Any, type: Class<T>): T {
        android.util.Log.i("EImzoApi", "rpcCall $method START → $apiUrl")
        val request = JsonRpcRequest(method = method, params = params)
        val json = gson.toJson(request)
        android.util.Log.i("EImzoApi", "rpcCall $method JSON built, len=${json.length}")
        val body = json.toRequestBody(jsonMediaType)
        val httpRequest = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", "e-imzo-mobile")
            .header("Accept", "application/json")
            .post(body)
            .build()
        android.util.Log.i("EImzoApi", "rpcCall $method Request built")

        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            android.util.Log.i("EImzoApi", "rpcCall $method executing...")
            val response = client.newCall(httpRequest).execute()
            android.util.Log.i("EImzoApi", "rpcCall $method HTTP ${response.code}")
            val responseBody = response.body?.string() ?: throw Exception("Empty response")
            android.util.Log.i("EImzoApi", "$method response: $responseBody")
            val rpcType = TypeToken.getParameterized(JsonRpcResponse::class.java, type).type
            val rpcResponse: JsonRpcResponse<T> = gson.fromJson(responseBody, rpcType)
            rpcResponse.error?.let { err ->
                val msg = when {
                    err.isJsonObject -> {
                        val obj = err.asJsonObject
                        val code = obj.get("code")?.asString ?: "?"
                        val message = obj.get("message")?.asString ?: obj.toString()
                        "RPC Error $code: $message"
                    }
                    err.isJsonPrimitive -> err.asString
                    else -> err.toString()
                }
                throw Exception(msg)
            }
            rpcResponse.result ?: throw Exception("Null result from server")
        }
    }

    suspend fun certInfo(pubKey: uz.eimzo.sdk.crypto.EcPublicKey): uz.eimzo.sdk.models.CertInfo {
        val r = rpcCall(
            method = "pki.cert_info",
            params = CertInfoParams(
                p = pubKey.p, q = pubKey.q, a = pubKey.a, b = pubKey.b,
                gx = pubKey.gx, gy = pubKey.gy, qx = pubKey.qx, qy = pubKey.qy
            ),
            type = CertInfoResult::class.java
        )

        // serial_number is the key's identity. Without it the cert is
        // unusable — and a null here would otherwise propagate into Room and
        // crash with the opaque "Parameter specified as non-null is null:
        // …RoomSQLiteQuery.bindString". Reject it here with a clear message
        // instead (typical for an invalid / unregistered key, e.g. a test
        // key not enrolled on the current server).
        val serial = r.serialNumber?.takeIf { it.isNotBlank() }
            ?: throw Exception(
                "Kalitni tekshirib bo'lmadi: sertifikat yaroqsiz yoki " +
                    "ro'yxatdan o'tmagan (state=${r.state ?: "?"})"
            )

        // Cosmetic fields: coalesce so a partial server response can never
        // hand a null to a non-null Room column.
        return uz.eimzo.sdk.models.CertInfo(
            serialNumber = serial,
            cn = r.cn?.takeIf { it.isNotBlank() } ?: serial,
            o = r.o,
            uid = r.uid,
            tin = r.tin,
            pinfl = r.pinfl,
            validFrom = r.validFrom ?: "",
            validTo = r.validTo ?: "",
            validNow = r.validNow,
            state = r.state ?: ""
        )
    }

    suspend fun siteInfo(siteId: String): SiteInfoResult {
        return rpcCall(
            method = "pki.site_info",
            params = SiteInfoParams(siteId = siteId),
            type = SiteInfoResult::class.java
        )
    }

    suspend fun sendPkcs7(
        siteId: String,
        docId: String,
        hash: String,
        signature: String,
        serialNumber: String,
        timestamp: String
    ): Pkcs7Result {
        return rpcCall(
            method = "pki.send_pkcs7",
            params = SendPkcs7Params(
                siteId = siteId,
                docId = docId,
                hash = hash,
                signature = signature,
                serialNumber = serialNumber,
                timestamp = timestamp
            ),
            type = Pkcs7Result::class.java
        )
    }
}
