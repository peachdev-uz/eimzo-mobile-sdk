package uz.eimzo.sdk.network

import com.google.gson.annotations.SerializedName

// NOTE: every field is nullable. Gson instantiates this class via Unsafe,
// bypassing the Kotlin constructor — so the `= ""` style defaults are NEVER
// applied. Any key the server omits arrives here as a genuine `null`, even on
// a type declared non-null. Declaring them nullable keeps that honest; the
// mapping in EImzoApiClient.certInfo() validates and coalesces before the
// values reach Room (a null serial_number used to crash the @Insert/@Query
// path with "Parameter specified as non-null is null: …RoomSQLiteQuery").
internal data class CertInfoResult(
    @SerializedName("state") val state: String? = null,
    @SerializedName("serial_number") val serialNumber: String? = null,
    @SerializedName("cn") val cn: String? = null,
    @SerializedName("o") val o: String? = null,
    @SerializedName("uid") val uid: String? = null,
    @SerializedName("tin") val tin: String? = null,
    @SerializedName("pinfl") val pinfl: String? = null,
    @SerializedName("valid_from") val validFrom: String? = null,
    @SerializedName("valid_to") val validTo: String? = null,
    @SerializedName("valid_now") val validNow: Boolean = false
)

internal data class SiteInfoResult(
    @SerializedName("state") val state: String,
    @SerializedName("domain_name") val domainName: String = ""
)

internal data class Pkcs7Result(
    @SerializedName("state") val state: String,
    @SerializedName("message") val message: String = ""
)

// Params for pki.cert_info RPC call (8 EC curve parameters)
internal data class CertInfoParams(
    @SerializedName("p") val p: String,
    @SerializedName("q") val q: String,
    @SerializedName("a") val a: String,
    @SerializedName("b") val b: String,
    @SerializedName("gx") val gx: String,
    @SerializedName("gy") val gy: String,
    @SerializedName("qx") val qx: String,
    @SerializedName("qy") val qy: String
)

internal data class SiteInfoParams(
    @SerializedName("site_id") val siteId: String
)

internal data class SendPkcs7Params(
    @SerializedName("site_id") val siteId: String,
    @SerializedName("doc_id") val docId: String,
    @SerializedName("hash") val hash: String,
    @SerializedName("signature") val signature: String,
    @SerializedName("serial_number") val serialNumber: String,
    @SerializedName("utc_time") val timestamp: String
)
