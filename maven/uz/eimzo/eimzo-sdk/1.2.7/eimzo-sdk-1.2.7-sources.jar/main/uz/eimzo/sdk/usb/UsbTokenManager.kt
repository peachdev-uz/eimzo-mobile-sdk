package uz.eimzo.sdk.usb

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Message
import com.ftsafe.DK
import com.ftsafe.readerScheme.FTException
import com.ftsafe.readerScheme.FTReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import uz.eimzo.sdk.crypto.HexUtils
import uz.yt.idcard.applet.android.EImzoAppletFactory
import uz.yt.idcard.applet.android.dto.FileType
import uz.yt.idcard.applet.android.dto.State
import uz.yt.idcard.applet.android.exception.InvalidUserPINException
import java.io.ByteArrayOutputStream
import java.util.concurrent.locks.ReentrantLock
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * USB token signing using FT Reader.
 *
 * Sign-only. USB tokens are NEVER persisted as saved keys — each sign
 * is a transient session: open FT session, wait for token + card insert,
 * verify PIN, sign the hash, tear the session down.
 *
 * Backed by FTReaderAPI_2.0.1.7.jar + applet-android-1.7.0-SNAPSHOT.jar
 * (under eimzo-sdk/libs/). Only ONE sign may be in flight at a time —
 * the FT reader native session is exclusive.
 *
 * FTReaderAPI 2.0.1.7 addresses the reader by **name** (the string returned
 * from [FTReader.readerOpen]) instead of the implicit single-reader model of
 * 1.0.9.6. [readerName] is captured on USB_PERMISSION and threaded into every
 * slot-level call.
 */
internal class UsbTokenManager(private val context: Context) {

    private var ftReader: FTReader? = null
    private val lock = ReentrantLock()
    private val slotIndex = 0

    /** Reader name from readerOpen() — required by all 2.0.1.7 slot calls. */
    private var readerName: String? = null

    private var pendingContinuation: kotlin.coroutines.Continuation<UsbSignResult>? = null
    private var pendingPin: String? = null
    private var pendingSaHashRev: ByteArray? = null

    data class UsbSignResult(
        val serialNumber: String,
        val signature: String
    )

    /** Atomically take the continuation (so we never resume it twice). */
    private fun drainContinuation(): kotlin.coroutines.Continuation<UsbSignResult>? {
        val c = pendingContinuation
        pendingContinuation = null
        return c
    }

    private val handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                DK.USB_LOG -> {
                    if ((msg.obj as? String)?.contains("USB_PERMISSION") == true) {
                        try {
                            // 2.0.1.7: readerOpen() returns the connected
                            // reader name(s). We keep the first — it's the
                            // handle every later slot call needs.
                            val names = ftReader?.readerOpen(null)
                            readerName = names?.firstOrNull()
                        } catch (e: FTException) {
                            drainContinuation()?.resumeWithException(e)
                        }
                    }
                }
                DK.USB_IN -> { /* USB inserted - handled by card event */ }
                DK.USB_OUT -> {
                    drainContinuation()?.resumeWithException(
                        Exception("USB token uzildi")
                    )
                }
                else -> {
                    if (msg.what and DK.CARD_IN_MASK == DK.CARD_IN_MASK) {
                        processCard()
                    }
                }
            }
        }
    }

    suspend fun sign(saHashRev: ByteArray, pin: String): UsbSignResult =
        // FTReader's constructor and our `handler` field both touch the
        // current thread's Looper, so the suspendCancellableCoroutine block
        // MUST run on the main thread — IO worker threads have no Looper
        // and throw "Can't create handler inside thread Thread[…]".
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                pendingContinuation = cont
                pendingPin = pin
                pendingSaHashRev = saHashRev

                try {
                    readerName?.let { runCatching { ftReader?.readerClose(it) } }
                    readerName = null
                    ftReader = FTReader(context, handler, 0)
                    ftReader?.readerFind()
                } catch (e: FTException) {
                    drainContinuation()?.resumeWithException(
                        Exception("USB token topilmadi: ${e.message}")
                    )
                }
            }
        }

    private fun processCard() {
        // Drain the pending continuation atomically — CARD_IN can fire multiple
        // times for the same physical insert (or while we're still processing
        // the first one), and resuming a continuation twice throws
        // IllegalStateException("Already resumed").
        val cont = drainContinuation() ?: return

        if (!lock.tryLock()) {
            // Another processCard is running — put the continuation back so
            // that one can complete it.
            pendingContinuation = cont
            return
        }

        try {
            try {
                val name = readerName
                    ?: throw Exception("USB token topilmadi")
                ftReader?.readerPowerOn(name, slotIndex)
                    ?: throw Exception("USB token topilmadi")
                val channel = ftReader?.let { FtCardChannel(it, name, slotIndex) }
                    ?: throw Exception("USB kanal yaratib bo'lmadi")

                try {
                    val eiaf = EImzoAppletFactory()
                    val applet = eiaf.get(channel)
                    val asi = applet.appletStateInfo

                    if (asi.state != State.PERSONALIZED) {
                        throw Exception("Token personalizatsiya qilinmagan")
                    }

                    val serialOut = ByteArrayOutputStream()
                    applet.readFile(FileType.SERIAL_NUMBER, serialOut)
                    val serialNumber = HexUtils.toHex(serialOut.toByteArray())

                    applet.validatePIN(pendingPin)
                    val signatureBytes = applet.signHash(pendingSaHashRev!!)
                    val signature = HexUtils.toHex(signatureBytes)

                    eiaf.deselect(channel)
                    cont.resume(UsbSignResult(serialNumber, signature))
                } finally {
                    runCatching { channel.close() }
                    runCatching { ftReader?.readerPowerOff(name, slotIndex) }
                }
            } catch (e: InvalidUserPINException) {
                cont.resumeWithException(Exception("PIN_ERROR:${e.message}"))
            } catch (e: Exception) {
                cont.resumeWithException(e)
            }
        } finally {
            // Clear request-scoped state so the next sign() starts fresh.
            pendingPin = null
            pendingSaHashRev = null
            lock.unlock()
        }
    }

    fun release() {
        readerName?.let { name -> runCatching { ftReader?.readerClose(name) } }
        readerName = null
    }
}
