package uz.eimzo.sdk.usb

import com.ftsafe.readerScheme.FTException
import com.ftsafe.readerScheme.FTReader
import uz.yt.idcard.applet.android.exception.CardException
import uz.yt.idcard.applet.android.smartcardio.CardChannel
import uz.yt.idcard.applet.android.smartcardio.CommandAPDU
import uz.yt.idcard.applet.android.smartcardio.ResponseAPDU

/**
 * APDU channel over an FT reader slot.
 *
 * FTReaderAPI 2.0.1.7 identifies the connected reader by **name** — the
 * string returned from `readerOpen()`. Every slot-level call now takes that
 * name as its first argument (`readerXfr(name, slot, apdu)`,
 * `readerClose(name)`), unlike the 1.0.9.6 API which addressed the single
 * implicit reader by slot index alone.
 */
internal class FtCardChannel(
    private val reader: FTReader,
    private val readerName: String,
    private val slotIndex: Int
) : CardChannel {

    override fun transmit(command: CommandAPDU): ResponseAPDU {
        return try {
            val bytes = reader.readerXfr(readerName, slotIndex, command.getBytes())
            ResponseAPDU(bytes)
        } catch (e: FTException) {
            throw CardException(e)
        }
    }

    override fun close() {
        try {
            reader.readerClose(readerName)
        } catch (e: FTException) {
            throw CardException(e)
        }
    }
}
