package uz.eimzo.sdk.models

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PfxKey(
    val serialNumber: String,
    val name: String,
    val organization: String?,
    val uid: String?,
    val tin: String?,
    val pinfl: String?,
    val validFrom: String,
    val validTo: String,
    val validNow: Boolean,
    val qrData: String,
    val password: String?,
    val keyType: KeyType,
    val isDefault: Boolean = false
) {
    /**
     * `true` if the certificate's `validTo` timestamp has passed at the
     * moment of the call. Re-evaluated each invocation — `validNow` only
     * reflects the server's verdict at *import* time, which can drift over
     * time as the cert nears / passes expiry.
     *
     * Falls back to `validNow` if the timestamp can't be parsed (e.g. an
     * NFC card returned a non-standard format) — better to risk a stale
     * "valid" verdict than to lock the user out incorrectly.
     */
    fun isExpired(): Boolean {
        val end = parseTimestamp(validTo) ?: return !validNow
        return end.time < System.currentTimeMillis()
    }

    private fun parseTimestamp(s: String): Date? {
        if (s.isBlank()) return null
        // Soliq server returns "yyyy.MM.dd HH:mm:ss". NFC layer returns
        // "yyyy.MM.dd". Try the longer pattern first.
        TIMESTAMP_PATTERNS.forEach { pattern ->
            try {
                return SimpleDateFormat(pattern, Locale.US).parse(s)
            } catch (_: Exception) { /* try next */ }
        }
        return null
    }

    private companion object {
        val TIMESTAMP_PATTERNS = listOf(
            "yyyy.MM.dd HH:mm:ss",
            "yyyy.MM.dd",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd"
        )
    }
}
