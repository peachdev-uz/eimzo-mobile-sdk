package uz.eimzo.sdk.fullui.keys

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import uz.eimzo.sdk.databinding.EimzoUiItemKeyBinding
import uz.eimzo.sdk.models.PfxKey

internal class KeyAdapter(
    private val onClick: (PfxKey) -> Unit,
    private val onLongClick: (PfxKey) -> Unit
) : ListAdapter<PfxKey, KeyAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = EimzoUiItemKeyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: EimzoUiItemKeyBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(key: PfxKey) {
            binding.tvId.text = if (key.tin != null) key.tin else key.uid ?: "—"
            binding.tvName.text = if (key.tin != null) key.organization ?: key.name else key.name
            binding.tvPinfl.text = key.pinfl ?: "—"
            binding.tvExpiry.text = key.validTo
            binding.ivDefault.visibility = if (key.isDefault)
                android.view.View.VISIBLE else android.view.View.GONE

            // Red "Muddati tugagan" pill on the card when the cert's
            // validTo timestamp has passed. The card stays tappable so
            // the user can still select / delete the expired key — only
            // the sign flow on Home gates against it.
            val expired = key.isExpired()
            binding.tvExpiredBadge.visibility = if (expired)
                android.view.View.VISIBLE else android.view.View.GONE
            // Slight visual dim so expired keys read as "inactive" in the
            // list without obscuring information.
            binding.root.alpha = if (expired) 0.7f else 1.0f

            binding.root.setOnClickListener { onClick(key) }
            binding.root.setOnLongClickListener {
                onLongClick(key)
                true
            }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PfxKey>() {
            override fun areItemsTheSame(a: PfxKey, b: PfxKey) = a.serialNumber == b.serialNumber
            override fun areContentsTheSame(a: PfxKey, b: PfxKey) = a == b
        }
    }
}
