package uz.eimzo.sdk.fullui.addkey

import android.app.Activity
import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import uz.eimzo.sdk.R
import uz.eimzo.sdk.databinding.EimzoUiFragmentAddKeyBinding
import uz.eimzo.sdk.fullui.util.PasswordDialog

class AddKeyFragment : Fragment() {

    private var _binding: EimzoUiFragmentAddKeyBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddKeyViewModel by viewModels()
    private var nfcAdapter: NfcAdapter? = null
    private var waitingNfc = false

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            PasswordDialog.show(requireContext(), getString(R.string.eimzo_ui_enter_eri_password)) { password ->
                viewModel.importPfxFile(requireContext(), uri, password)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = EimzoUiFragmentAddKeyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(requireContext())

        // Toolbar back navigation — single tap returns the user to whichever
        // fragment pushed AddKey onto the back stack (typically Home or Keys).
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        binding.btnAddPfx.setOnClickListener {
            filePicker.launch("application/x-pkcs12")
        }

        binding.btnAddNfc.setOnClickListener {
            PasswordDialog.show(requireContext(), getString(R.string.eimzo_ui_enter_id_pin)) { pin ->
                enableNfcForeground()
                waitingNfc = true
                binding.tvNfcHint.visibility = View.VISIBLE
                Toast.makeText(requireContext(), getString(R.string.eimzo_ui_bring_card_close), Toast.LENGTH_LONG).show()
                // pin stored in viewmodel via pending action
                _pendingNfcPin = pin
            }
        }

        // USB token is sign-only — see HomeFragment's "USB token bilan
        // imzolash" button. We hide the legacy "USB Token qo'shish" button
        // here so the AddKey screen reflects what's actually addable
        // (PFX file + NFC ID card).
        binding.btnAddUsbToken.visibility = View.GONE

        viewModel.state.observe(viewLifecycleOwner) { state ->
            when (state) {
                is AddKeyViewModel.AddKeyState.Idle -> binding.progressBar.visibility = View.GONE
                is AddKeyViewModel.AddKeyState.Loading -> binding.progressBar.visibility = View.VISIBLE
                is AddKeyViewModel.AddKeyState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), getString(R.string.eimzo_ui_key_added_success), Toast.LENGTH_SHORT).show()
                    findNavController().navigateUp()
                }
                is AddKeyViewModel.AddKeyState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private var _pendingNfcPin: String? = null

    fun onNfcTagDiscovered(tag: Tag) {
        val pin = _pendingNfcPin ?: return
        _pendingNfcPin = null
        waitingNfc = false
        binding.tvNfcHint.visibility = View.GONE
        disableNfcForeground()
        viewModel.importNfcCard(tag, pin)
    }

    private fun enableNfcForeground() {
        val activity = requireActivity()
        val intent = Intent(activity, activity.javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(activity, 0, intent, PendingIntent.FLAG_MUTABLE)
        nfcAdapter?.enableForegroundDispatch(activity, pi, null, null)
    }

    private fun disableNfcForeground() {
        nfcAdapter?.disableForegroundDispatch(requireActivity())
    }

    override fun onPause() {
        super.onPause()
        disableNfcForeground()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
