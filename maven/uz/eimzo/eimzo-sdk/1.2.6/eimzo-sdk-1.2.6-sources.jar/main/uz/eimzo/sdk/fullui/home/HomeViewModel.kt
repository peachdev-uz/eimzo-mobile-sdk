package uz.eimzo.sdk.fullui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.eimzo.sdk.EImzoSDK
import uz.eimzo.sdk.ImportKeyCallback
import uz.eimzo.sdk.SignCallback
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.models.QrHashData
import uz.eimzo.sdk.models.SignResult

internal class HomeViewModel : ViewModel() {

    private val sdk = EImzoSDK.get()

    val keys = sdk.getAllKeys().asLiveData()

    private val _currentKey = MutableLiveData<PfxKey?>()
    val currentKey: LiveData<PfxKey?> = _currentKey

    private val _signState = MutableLiveData<SignState>(SignState.Idle)
    val signState: LiveData<SignState> = _signState

    private val _deepLink = MutableLiveData<String?>()
    val deepLink: LiveData<String?> = _deepLink

    /**
     * Seconds remaining in the deep-link sign session. Set to
     * [SESSION_DURATION_SECONDS] when a deep link is received, ticks down
     * once per second via [sessionJob], and falls to 0 on natural expiry or
     * explicit [clearDeepLinkSession]. A value of 0 means "no active session".
     *
     * UI observes this and:
     *   - shows the countdown in the deep-link card while > 0
     *   - hides the card and toasts "Sessiya tugadi" on the 0 transition
     */
    private val _sessionRemaining = MutableLiveData(0)
    val sessionRemaining: LiveData<Int> = _sessionRemaining

    /**
     * Emits exactly once when the running session naturally times out
     * (countdown reached 0 on its own, NOT via explicit clear / signed
     * successfully). The fragment uses this as the trigger to show the
     * "session expired" toast — a stand-alone LiveData on `sessionRemaining`
     * could not distinguish expiry from a user-initiated clear.
     */
    private val _sessionExpired = MutableLiveData<Boolean>(false)
    val sessionExpired: LiveData<Boolean> = _sessionExpired

    private var sessionJob: Job? = null

    init {
        refreshCurrentKey()
    }

    fun refreshCurrentKey() {
        viewModelScope.launch {
            _currentKey.value = sdk.getDefaultKey() ?: sdk.getAllKeysList().firstOrNull()
        }
    }

    /**
     * Set (or replace) the pending sign deeplink and start a fresh 103-second
     * session. Passing `null` stops any running session without firing the
     * "expired" event — used when the integrator cancels.
     *
     * If a session was already running, its job is cancelled and replaced —
     * the timer resets to [SESSION_DURATION_SECONDS] every time a new deep
     * link arrives, even mid-flow.
     */
    fun setDeepLink(uri: String?) {
        sessionJob?.cancel()
        _deepLink.value = uri
        if (uri.isNullOrEmpty()) {
            _sessionRemaining.value = 0
        } else {
            startSession()
        }
    }

    /**
     * Cleanly tear down the current deep-link session without flagging
     * expiry. Call this on successful sign (the deeplink has been "used"
     * and shouldn't sit around with a ticking clock).
     */
    fun clearDeepLinkSession() {
        sessionJob?.cancel()
        sessionJob = null
        _sessionRemaining.value = 0
        _deepLink.value = null
    }

    /** Called from the fragment after it has consumed [sessionExpired]. */
    fun acknowledgeSessionExpired() {
        _sessionExpired.value = false
    }

    private fun startSession() {
        sessionJob = viewModelScope.launch {
            var remaining = SESSION_DURATION_SECONDS
            while (remaining > 0) {
                _sessionRemaining.value = remaining
                delay(1000L)
                remaining--
            }
            // Natural expiry — flag for the one-shot toast observer, but
            // KEEP the deeplink in place. Adding a key (especially via NFC)
            // realistically takes longer than 103 seconds; clearing the
            // deeplink on timer-zero would strand the user with no way to
            // complete the flow they were sent here for. The server-side
            // QR validity is the source of truth — if it's expired by sign
            // time the server will reject and we surface that as a normal
            // SignState.Error. The countdown is informational only.
            _sessionRemaining.value = 0
            _sessionExpired.value = true
        }
    }

    fun setCurrentKey(key: PfxKey) {
        _currentKey.value = key
        viewModelScope.launch { sdk.setDefaultKey(key.serialNumber) }
    }

    fun signWithCurrentKey(password: String?) {
        val key = _currentKey.value ?: return
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading

        when (key.keyType) {
            KeyType.QR_PFX -> {
                sdk.signWithQrKey(key, dl, password, object : SignCallback {
                    override fun onSuccess(result: SignResult.Success) {
                        sessionJob?.cancel()
                        _signState.value = SignState.Success(result)
                    }
                    override fun onError(error: SignResult.Failure) {
                        _signState.value = SignState.Error(error.error)
                    }
                })
            }
            KeyType.NFC_ID -> {
                _signState.value = SignState.WaitingNfc
            }
            KeyType.USB_TOKEN -> {
                if (password != null) signWithUsb(password)
                else _signState.value = SignState.NeedPassword(KeyType.USB_TOKEN)
            }
        }
    }

    fun signWithUsb(pin: String) {
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading
        sdk.signWithUsbToken(pin, dl, object : SignCallback {
            override fun onSuccess(result: SignResult.Success) {
                sessionJob?.cancel()
                _signState.value = SignState.Success(result)
            }
            override fun onError(error: SignResult.Failure) {
                _signState.value = SignState.Error(error.error)
            }
        })
    }

    fun signWithNfcTag(tag: android.nfc.Tag, pin: String) {
        val key = _currentKey.value ?: return
        val dl = _deepLink.value ?: return
        _signState.value = SignState.Loading
        sdk.signWithNfc(tag, pin, dl, object : SignCallback {
            override fun onSuccess(result: SignResult.Success) {
                sessionJob?.cancel()
                _signState.value = SignState.Success(result)
            }
            override fun onError(error: SignResult.Failure) {
                _signState.value = SignState.Error(error.error)
            }
        })
    }

    fun resetSignState() {
        _signState.value = SignState.Idle
    }

    sealed class SignState {
        object Idle : SignState()
        object Loading : SignState()
        object WaitingNfc : SignState()
        data class NeedPassword(val keyType: KeyType) : SignState()
        data class Success(val result: SignResult.Success) : SignState()
        data class Error(val message: String) : SignState()
    }

    companion object {
        /**
         * Duration of the pending-deeplink session, in seconds. After this
         * many seconds without the user signing, the deep link is cleared
         * and a "session expired" toast is shown.
         *
         * 103 seconds is the contract with the issuing portals — the QR
         * code embedded in `eimzo://sign?qc=...` is server-side valid for
         * roughly that window. Keeping the client-side timer in sync avoids
         * letting users complete signing only to get a 4xx from the soliq
         * server.
         */
        const val SESSION_DURATION_SECONDS = 103
    }
}
