package uz.eimzo.sdk.storage

import androidx.room.Entity
import androidx.room.PrimaryKey
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey

@Entity(tableName = "keys")
data class KeyEntity(
    @PrimaryKey val serialNumber: String,
    val name: String,
    val organization: String?,
    val uid: String?,
    val tin: String?,
    val pinfl: String?,
    val validFrom: String,
    val validTo: String,
    val validNow: Boolean,
    val qrData: String,
    val password: String?,
    val keyType: String,
    val isDefault: Boolean = false
) {
    fun toPfxKey() = PfxKey(
        serialNumber = serialNumber,
        name = name,
        organization = organization,
        uid = uid,
        tin = tin,
        pinfl = pinfl,
        validFrom = validFrom,
        validTo = validTo,
        validNow = validNow,
        qrData = qrData,
        password = password,
        keyType = KeyType.valueOf(keyType),
        isDefault = isDefault
    )

    companion object {
        fun fromPfxKey(key: PfxKey) = KeyEntity(
            serialNumber = key.serialNumber,
            name = key.name,
            organization = key.organization,
            uid = key.uid,
            tin = key.tin,
            pinfl = key.pinfl,
            validFrom = key.validFrom,
            validTo = key.validTo,
            validNow = key.validNow,
            qrData = key.qrData,
            password = key.password,
            keyType = key.keyType.name,
            isDefault = key.isDefault
        )
    }
}
