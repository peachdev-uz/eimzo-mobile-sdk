package uz.eimzo.sdk.storage;

import androidx.annotation.NonNull;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.RoomDatabase;
import androidx.room.RoomOpenHelper;
import androidx.room.migration.AutoMigrationSpec;
import androidx.room.migration.Migration;
import androidx.room.util.DBUtil;
import androidx.room.util.TableInfo;
import androidx.sqlite.db.SupportSQLiteDatabase;
import androidx.sqlite.db.SupportSQLiteOpenHelper;
import java.lang.Class;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.processing.Generated;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class KeyDatabase_Impl extends KeyDatabase {
  private volatile KeyDao _keyDao;

  @Override
  @NonNull
  protected SupportSQLiteOpenHelper createOpenHelper(@NonNull final DatabaseConfiguration config) {
    final SupportSQLiteOpenHelper.Callback _openCallback = new RoomOpenHelper(config, new RoomOpenHelper.Delegate(1) {
      @Override
      public void createAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `keys` (`serialNumber` TEXT NOT NULL, `name` TEXT NOT NULL, `organization` TEXT, `uid` TEXT, `tin` TEXT, `pinfl` TEXT, `validFrom` TEXT NOT NULL, `validTo` TEXT NOT NULL, `validNow` INTEGER NOT NULL, `qrData` TEXT NOT NULL, `password` TEXT, `keyType` TEXT NOT NULL, `isDefault` INTEGER NOT NULL, PRIMARY KEY(`serialNumber`))");
        db.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
        db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '44c31eb63ca8b56ceada5772882eac5f')");
      }

      @Override
      public void dropAllTables(@NonNull final SupportSQLiteDatabase db) {
        db.execSQL("DROP TABLE IF EXISTS `keys`");
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onDestructiveMigration(db);
          }
        }
      }

      @Override
      public void onCreate(@NonNull final SupportSQLiteDatabase db) {
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onCreate(db);
          }
        }
      }

      @Override
      public void onOpen(@NonNull final SupportSQLiteDatabase db) {
        mDatabase = db;
        internalInitInvalidationTracker(db);
        final List<? extends RoomDatabase.Callback> _callbacks = mCallbacks;
        if (_callbacks != null) {
          for (RoomDatabase.Callback _callback : _callbacks) {
            _callback.onOpen(db);
          }
        }
      }

      @Override
      public void onPreMigrate(@NonNull final SupportSQLiteDatabase db) {
        DBUtil.dropFtsSyncTriggers(db);
      }

      @Override
      public void onPostMigrate(@NonNull final SupportSQLiteDatabase db) {
      }

      @Override
      @NonNull
      public RoomOpenHelper.ValidationResult onValidateSchema(
          @NonNull final SupportSQLiteDatabase db) {
        final HashMap<String, TableInfo.Column> _columnsKeys = new HashMap<String, TableInfo.Column>(13);
        _columnsKeys.put("serialNumber", new TableInfo.Column("serialNumber", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("name", new TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("organization", new TableInfo.Column("organization", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("uid", new TableInfo.Column("uid", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("tin", new TableInfo.Column("tin", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("pinfl", new TableInfo.Column("pinfl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("validFrom", new TableInfo.Column("validFrom", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("validTo", new TableInfo.Column("validTo", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("validNow", new TableInfo.Column("validNow", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("qrData", new TableInfo.Column("qrData", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("password", new TableInfo.Column("password", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("keyType", new TableInfo.Column("keyType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        _columnsKeys.put("isDefault", new TableInfo.Column("isDefault", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY));
        final HashSet<TableInfo.ForeignKey> _foreignKeysKeys = new HashSet<TableInfo.ForeignKey>(0);
        final HashSet<TableInfo.Index> _indicesKeys = new HashSet<TableInfo.Index>(0);
        final TableInfo _infoKeys = new TableInfo("keys", _columnsKeys, _foreignKeysKeys, _indicesKeys);
        final TableInfo _existingKeys = TableInfo.read(db, "keys");
        if (!_infoKeys.equals(_existingKeys)) {
          return new RoomOpenHelper.ValidationResult(false, "keys(uz.eimzo.sdk.storage.KeyEntity).\n"
                  + " Expected:\n" + _infoKeys + "\n"
                  + " Found:\n" + _existingKeys);
        }
        return new RoomOpenHelper.ValidationResult(true, null);
      }
    }, "44c31eb63ca8b56ceada5772882eac5f", "2457c907863d06fa2a45f3b280215d98");
    final SupportSQLiteOpenHelper.Configuration _sqliteConfig = SupportSQLiteOpenHelper.Configuration.builder(config.context).name(config.name).callback(_openCallback).build();
    final SupportSQLiteOpenHelper _helper = config.sqliteOpenHelperFactory.create(_sqliteConfig);
    return _helper;
  }

  @Override
  @NonNull
  protected InvalidationTracker createInvalidationTracker() {
    final HashMap<String, String> _shadowTablesMap = new HashMap<String, String>(0);
    final HashMap<String, Set<String>> _viewTables = new HashMap<String, Set<String>>(0);
    return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "keys");
  }

  @Override
  public void clearAllTables() {
    super.assertNotMainThread();
    final SupportSQLiteDatabase _db = super.getOpenHelper().getWritableDatabase();
    try {
      super.beginTransaction();
      _db.execSQL("DELETE FROM `keys`");
      super.setTransactionSuccessful();
    } finally {
      super.endTransaction();
      _db.query("PRAGMA wal_checkpoint(FULL)").close();
      if (!_db.inTransaction()) {
        _db.execSQL("VACUUM");
      }
    }
  }

  @Override
  @NonNull
  protected Map<Class<?>, List<Class<?>>> getRequiredTypeConverters() {
    final HashMap<Class<?>, List<Class<?>>> _typeConvertersMap = new HashMap<Class<?>, List<Class<?>>>();
    _typeConvertersMap.put(KeyDao.class, KeyDao_Impl.getRequiredConverters());
    return _typeConvertersMap;
  }

  @Override
  @NonNull
  public Set<Class<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecs() {
    final HashSet<Class<? extends AutoMigrationSpec>> _autoMigrationSpecsSet = new HashSet<Class<? extends AutoMigrationSpec>>();
    return _autoMigrationSpecsSet;
  }

  @Override
  @NonNull
  public List<Migration> getAutoMigrations(
      @NonNull final Map<Class<? extends AutoMigrationSpec>, AutoMigrationSpec> autoMigrationSpecs) {
    final List<Migration> _autoMigrations = new ArrayList<Migration>();
    return _autoMigrations;
  }

  @Override
  public KeyDao keyDao() {
    if (_keyDao != null) {
      return _keyDao;
    } else {
      synchronized(this) {
        if(_keyDao == null) {
          _keyDao = new KeyDao_Impl(this);
        }
        return _keyDao;
      }
    }
  }
}
