package uz.eimzo.sdk.storage;

import android.database.Cursor;
import android.os.CancellationSignal;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.CoroutinesRoom;
import androidx.room.EntityDeletionOrUpdateAdapter;
import androidx.room.EntityInsertionAdapter;
import androidx.room.RoomDatabase;
import androidx.room.RoomDatabaseKt;
import androidx.room.RoomSQLiteQuery;
import androidx.room.SharedSQLiteStatement;
import androidx.room.util.CursorUtil;
import androidx.room.util.DBUtil;
import androidx.sqlite.db.SupportSQLiteStatement;
import java.lang.Class;
import java.lang.Exception;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import javax.annotation.processing.Generated;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.Flow;

@Generated("androidx.room.RoomProcessor")
@SuppressWarnings({"unchecked", "deprecation"})
public final class KeyDao_Impl implements KeyDao {
  private final RoomDatabase __db;

  private final EntityInsertionAdapter<KeyEntity> __insertionAdapterOfKeyEntity;

  private final EntityDeletionOrUpdateAdapter<KeyEntity> __deletionAdapterOfKeyEntity;

  private final SharedSQLiteStatement __preparedStmtOfDeleteKeyBySerial;

  private final SharedSQLiteStatement __preparedStmtOfClearAllDefaults;

  private final SharedSQLiteStatement __preparedStmtOfSetDefault;

  public KeyDao_Impl(@NonNull final RoomDatabase __db) {
    this.__db = __db;
    this.__insertionAdapterOfKeyEntity = new EntityInsertionAdapter<KeyEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "INSERT OR REPLACE INTO `keys` (`serialNumber`,`name`,`organization`,`uid`,`tin`,`pinfl`,`validFrom`,`validTo`,`validNow`,`qrData`,`password`,`keyType`,`isDefault`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final KeyEntity entity) {
        statement.bindString(1, entity.getSerialNumber());
        statement.bindString(2, entity.getName());
        if (entity.getOrganization() == null) {
          statement.bindNull(3);
        } else {
          statement.bindString(3, entity.getOrganization());
        }
        if (entity.getUid() == null) {
          statement.bindNull(4);
        } else {
          statement.bindString(4, entity.getUid());
        }
        if (entity.getTin() == null) {
          statement.bindNull(5);
        } else {
          statement.bindString(5, entity.getTin());
        }
        if (entity.getPinfl() == null) {
          statement.bindNull(6);
        } else {
          statement.bindString(6, entity.getPinfl());
        }
        statement.bindString(7, entity.getValidFrom());
        statement.bindString(8, entity.getValidTo());
        final int _tmp = entity.getValidNow() ? 1 : 0;
        statement.bindLong(9, _tmp);
        statement.bindString(10, entity.getQrData());
        if (entity.getPassword() == null) {
          statement.bindNull(11);
        } else {
          statement.bindString(11, entity.getPassword());
        }
        statement.bindString(12, entity.getKeyType());
        final int _tmp_1 = entity.isDefault() ? 1 : 0;
        statement.bindLong(13, _tmp_1);
      }
    };
    this.__deletionAdapterOfKeyEntity = new EntityDeletionOrUpdateAdapter<KeyEntity>(__db) {
      @Override
      @NonNull
      protected String createQuery() {
        return "DELETE FROM `keys` WHERE `serialNumber` = ?";
      }

      @Override
      protected void bind(@NonNull final SupportSQLiteStatement statement,
          @NonNull final KeyEntity entity) {
        statement.bindString(1, entity.getSerialNumber());
      }
    };
    this.__preparedStmtOfDeleteKeyBySerial = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "DELETE FROM keys WHERE serialNumber = ?";
        return _query;
      }
    };
    this.__preparedStmtOfClearAllDefaults = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE keys SET isDefault = 0";
        return _query;
      }
    };
    this.__preparedStmtOfSetDefault = new SharedSQLiteStatement(__db) {
      @Override
      @NonNull
      public String createQuery() {
        final String _query = "UPDATE keys SET isDefault = 1 WHERE serialNumber = ?";
        return _query;
      }
    };
  }

  @Override
  public Object insertKey(final KeyEntity key, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __insertionAdapterOfKeyEntity.insert(key);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object deleteKey(final KeyEntity key, final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        __db.beginTransaction();
        try {
          __deletionAdapterOfKeyEntity.handle(key);
          __db.setTransactionSuccessful();
          return Unit.INSTANCE;
        } finally {
          __db.endTransaction();
        }
      }
    }, $completion);
  }

  @Override
  public Object setDefaultKey(final String serialNumber,
      final Continuation<? super Unit> $completion) {
    return RoomDatabaseKt.withTransaction(__db, (__cont) -> KeyDao.DefaultImpls.setDefaultKey(KeyDao_Impl.this, serialNumber, __cont), $completion);
  }

  @Override
  public Object deleteKeyBySerial(final String serialNumber,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfDeleteKeyBySerial.acquire();
        int _argIndex = 1;
        _stmt.bindString(_argIndex, serialNumber);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfDeleteKeyBySerial.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object clearAllDefaults(final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfClearAllDefaults.acquire();
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfClearAllDefaults.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Object setDefault(final String serialNumber,
      final Continuation<? super Unit> $completion) {
    return CoroutinesRoom.execute(__db, true, new Callable<Unit>() {
      @Override
      @NonNull
      public Unit call() throws Exception {
        final SupportSQLiteStatement _stmt = __preparedStmtOfSetDefault.acquire();
        int _argIndex = 1;
        _stmt.bindString(_argIndex, serialNumber);
        try {
          __db.beginTransaction();
          try {
            _stmt.executeUpdateDelete();
            __db.setTransactionSuccessful();
            return Unit.INSTANCE;
          } finally {
            __db.endTransaction();
          }
        } finally {
          __preparedStmtOfSetDefault.release(_stmt);
        }
      }
    }, $completion);
  }

  @Override
  public Flow<List<KeyEntity>> getAllKeys() {
    final String _sql = "SELECT * FROM keys ORDER BY isDefault DESC, name ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    return CoroutinesRoom.createFlow(__db, false, new String[] {"keys"}, new Callable<List<KeyEntity>>() {
      @Override
      @NonNull
      public List<KeyEntity> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfSerialNumber = CursorUtil.getColumnIndexOrThrow(_cursor, "serialNumber");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfOrganization = CursorUtil.getColumnIndexOrThrow(_cursor, "organization");
          final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
          final int _cursorIndexOfTin = CursorUtil.getColumnIndexOrThrow(_cursor, "tin");
          final int _cursorIndexOfPinfl = CursorUtil.getColumnIndexOrThrow(_cursor, "pinfl");
          final int _cursorIndexOfValidFrom = CursorUtil.getColumnIndexOrThrow(_cursor, "validFrom");
          final int _cursorIndexOfValidTo = CursorUtil.getColumnIndexOrThrow(_cursor, "validTo");
          final int _cursorIndexOfValidNow = CursorUtil.getColumnIndexOrThrow(_cursor, "validNow");
          final int _cursorIndexOfQrData = CursorUtil.getColumnIndexOrThrow(_cursor, "qrData");
          final int _cursorIndexOfPassword = CursorUtil.getColumnIndexOrThrow(_cursor, "password");
          final int _cursorIndexOfKeyType = CursorUtil.getColumnIndexOrThrow(_cursor, "keyType");
          final int _cursorIndexOfIsDefault = CursorUtil.getColumnIndexOrThrow(_cursor, "isDefault");
          final List<KeyEntity> _result = new ArrayList<KeyEntity>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final KeyEntity _item;
            final String _tmpSerialNumber;
            _tmpSerialNumber = _cursor.getString(_cursorIndexOfSerialNumber);
            final String _tmpName;
            _tmpName = _cursor.getString(_cursorIndexOfName);
            final String _tmpOrganization;
            if (_cursor.isNull(_cursorIndexOfOrganization)) {
              _tmpOrganization = null;
            } else {
              _tmpOrganization = _cursor.getString(_cursorIndexOfOrganization);
            }
            final String _tmpUid;
            if (_cursor.isNull(_cursorIndexOfUid)) {
              _tmpUid = null;
            } else {
              _tmpUid = _cursor.getString(_cursorIndexOfUid);
            }
            final String _tmpTin;
            if (_cursor.isNull(_cursorIndexOfTin)) {
              _tmpTin = null;
            } else {
              _tmpTin = _cursor.getString(_cursorIndexOfTin);
            }
            final String _tmpPinfl;
            if (_cursor.isNull(_cursorIndexOfPinfl)) {
              _tmpPinfl = null;
            } else {
              _tmpPinfl = _cursor.getString(_cursorIndexOfPinfl);
            }
            final String _tmpValidFrom;
            _tmpValidFrom = _cursor.getString(_cursorIndexOfValidFrom);
            final String _tmpValidTo;
            _tmpValidTo = _cursor.getString(_cursorIndexOfValidTo);
            final boolean _tmpValidNow;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfValidNow);
            _tmpValidNow = _tmp != 0;
            final String _tmpQrData;
            _tmpQrData = _cursor.getString(_cursorIndexOfQrData);
            final String _tmpPassword;
            if (_cursor.isNull(_cursorIndexOfPassword)) {
              _tmpPassword = null;
            } else {
              _tmpPassword = _cursor.getString(_cursorIndexOfPassword);
            }
            final String _tmpKeyType;
            _tmpKeyType = _cursor.getString(_cursorIndexOfKeyType);
            final boolean _tmpIsDefault;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfIsDefault);
            _tmpIsDefault = _tmp_1 != 0;
            _item = new KeyEntity(_tmpSerialNumber,_tmpName,_tmpOrganization,_tmpUid,_tmpTin,_tmpPinfl,_tmpValidFrom,_tmpValidTo,_tmpValidNow,_tmpQrData,_tmpPassword,_tmpKeyType,_tmpIsDefault);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
        }
      }

      @Override
      protected void finalize() {
        _statement.release();
      }
    });
  }

  @Override
  public Object getAllKeysList(final Continuation<? super List<KeyEntity>> $completion) {
    final String _sql = "SELECT * FROM keys ORDER BY isDefault DESC, name ASC";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<List<KeyEntity>>() {
      @Override
      @NonNull
      public List<KeyEntity> call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfSerialNumber = CursorUtil.getColumnIndexOrThrow(_cursor, "serialNumber");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfOrganization = CursorUtil.getColumnIndexOrThrow(_cursor, "organization");
          final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
          final int _cursorIndexOfTin = CursorUtil.getColumnIndexOrThrow(_cursor, "tin");
          final int _cursorIndexOfPinfl = CursorUtil.getColumnIndexOrThrow(_cursor, "pinfl");
          final int _cursorIndexOfValidFrom = CursorUtil.getColumnIndexOrThrow(_cursor, "validFrom");
          final int _cursorIndexOfValidTo = CursorUtil.getColumnIndexOrThrow(_cursor, "validTo");
          final int _cursorIndexOfValidNow = CursorUtil.getColumnIndexOrThrow(_cursor, "validNow");
          final int _cursorIndexOfQrData = CursorUtil.getColumnIndexOrThrow(_cursor, "qrData");
          final int _cursorIndexOfPassword = CursorUtil.getColumnIndexOrThrow(_cursor, "password");
          final int _cursorIndexOfKeyType = CursorUtil.getColumnIndexOrThrow(_cursor, "keyType");
          final int _cursorIndexOfIsDefault = CursorUtil.getColumnIndexOrThrow(_cursor, "isDefault");
          final List<KeyEntity> _result = new ArrayList<KeyEntity>(_cursor.getCount());
          while (_cursor.moveToNext()) {
            final KeyEntity _item;
            final String _tmpSerialNumber;
            _tmpSerialNumber = _cursor.getString(_cursorIndexOfSerialNumber);
            final String _tmpName;
            _tmpName = _cursor.getString(_cursorIndexOfName);
            final String _tmpOrganization;
            if (_cursor.isNull(_cursorIndexOfOrganization)) {
              _tmpOrganization = null;
            } else {
              _tmpOrganization = _cursor.getString(_cursorIndexOfOrganization);
            }
            final String _tmpUid;
            if (_cursor.isNull(_cursorIndexOfUid)) {
              _tmpUid = null;
            } else {
              _tmpUid = _cursor.getString(_cursorIndexOfUid);
            }
            final String _tmpTin;
            if (_cursor.isNull(_cursorIndexOfTin)) {
              _tmpTin = null;
            } else {
              _tmpTin = _cursor.getString(_cursorIndexOfTin);
            }
            final String _tmpPinfl;
            if (_cursor.isNull(_cursorIndexOfPinfl)) {
              _tmpPinfl = null;
            } else {
              _tmpPinfl = _cursor.getString(_cursorIndexOfPinfl);
            }
            final String _tmpValidFrom;
            _tmpValidFrom = _cursor.getString(_cursorIndexOfValidFrom);
            final String _tmpValidTo;
            _tmpValidTo = _cursor.getString(_cursorIndexOfValidTo);
            final boolean _tmpValidNow;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfValidNow);
            _tmpValidNow = _tmp != 0;
            final String _tmpQrData;
            _tmpQrData = _cursor.getString(_cursorIndexOfQrData);
            final String _tmpPassword;
            if (_cursor.isNull(_cursorIndexOfPassword)) {
              _tmpPassword = null;
            } else {
              _tmpPassword = _cursor.getString(_cursorIndexOfPassword);
            }
            final String _tmpKeyType;
            _tmpKeyType = _cursor.getString(_cursorIndexOfKeyType);
            final boolean _tmpIsDefault;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfIsDefault);
            _tmpIsDefault = _tmp_1 != 0;
            _item = new KeyEntity(_tmpSerialNumber,_tmpName,_tmpOrganization,_tmpUid,_tmpTin,_tmpPinfl,_tmpValidFrom,_tmpValidTo,_tmpValidNow,_tmpQrData,_tmpPassword,_tmpKeyType,_tmpIsDefault);
            _result.add(_item);
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getKey(final String serialNumber,
      final Continuation<? super KeyEntity> $completion) {
    final String _sql = "SELECT * FROM keys WHERE serialNumber = ?";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 1);
    int _argIndex = 1;
    _statement.bindString(_argIndex, serialNumber);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<KeyEntity>() {
      @Override
      @Nullable
      public KeyEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfSerialNumber = CursorUtil.getColumnIndexOrThrow(_cursor, "serialNumber");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfOrganization = CursorUtil.getColumnIndexOrThrow(_cursor, "organization");
          final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
          final int _cursorIndexOfTin = CursorUtil.getColumnIndexOrThrow(_cursor, "tin");
          final int _cursorIndexOfPinfl = CursorUtil.getColumnIndexOrThrow(_cursor, "pinfl");
          final int _cursorIndexOfValidFrom = CursorUtil.getColumnIndexOrThrow(_cursor, "validFrom");
          final int _cursorIndexOfValidTo = CursorUtil.getColumnIndexOrThrow(_cursor, "validTo");
          final int _cursorIndexOfValidNow = CursorUtil.getColumnIndexOrThrow(_cursor, "validNow");
          final int _cursorIndexOfQrData = CursorUtil.getColumnIndexOrThrow(_cursor, "qrData");
          final int _cursorIndexOfPassword = CursorUtil.getColumnIndexOrThrow(_cursor, "password");
          final int _cursorIndexOfKeyType = CursorUtil.getColumnIndexOrThrow(_cursor, "keyType");
          final int _cursorIndexOfIsDefault = CursorUtil.getColumnIndexOrThrow(_cursor, "isDefault");
          final KeyEntity _result;
          if (_cursor.moveToFirst()) {
            final String _tmpSerialNumber;
            _tmpSerialNumber = _cursor.getString(_cursorIndexOfSerialNumber);
            final String _tmpName;
            _tmpName = _cursor.getString(_cursorIndexOfName);
            final String _tmpOrganization;
            if (_cursor.isNull(_cursorIndexOfOrganization)) {
              _tmpOrganization = null;
            } else {
              _tmpOrganization = _cursor.getString(_cursorIndexOfOrganization);
            }
            final String _tmpUid;
            if (_cursor.isNull(_cursorIndexOfUid)) {
              _tmpUid = null;
            } else {
              _tmpUid = _cursor.getString(_cursorIndexOfUid);
            }
            final String _tmpTin;
            if (_cursor.isNull(_cursorIndexOfTin)) {
              _tmpTin = null;
            } else {
              _tmpTin = _cursor.getString(_cursorIndexOfTin);
            }
            final String _tmpPinfl;
            if (_cursor.isNull(_cursorIndexOfPinfl)) {
              _tmpPinfl = null;
            } else {
              _tmpPinfl = _cursor.getString(_cursorIndexOfPinfl);
            }
            final String _tmpValidFrom;
            _tmpValidFrom = _cursor.getString(_cursorIndexOfValidFrom);
            final String _tmpValidTo;
            _tmpValidTo = _cursor.getString(_cursorIndexOfValidTo);
            final boolean _tmpValidNow;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfValidNow);
            _tmpValidNow = _tmp != 0;
            final String _tmpQrData;
            _tmpQrData = _cursor.getString(_cursorIndexOfQrData);
            final String _tmpPassword;
            if (_cursor.isNull(_cursorIndexOfPassword)) {
              _tmpPassword = null;
            } else {
              _tmpPassword = _cursor.getString(_cursorIndexOfPassword);
            }
            final String _tmpKeyType;
            _tmpKeyType = _cursor.getString(_cursorIndexOfKeyType);
            final boolean _tmpIsDefault;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfIsDefault);
            _tmpIsDefault = _tmp_1 != 0;
            _result = new KeyEntity(_tmpSerialNumber,_tmpName,_tmpOrganization,_tmpUid,_tmpTin,_tmpPinfl,_tmpValidFrom,_tmpValidTo,_tmpValidNow,_tmpQrData,_tmpPassword,_tmpKeyType,_tmpIsDefault);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @Override
  public Object getDefaultKey(final Continuation<? super KeyEntity> $completion) {
    final String _sql = "SELECT * FROM keys WHERE isDefault = 1 LIMIT 1";
    final RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire(_sql, 0);
    final CancellationSignal _cancellationSignal = DBUtil.createCancellationSignal();
    return CoroutinesRoom.execute(__db, false, _cancellationSignal, new Callable<KeyEntity>() {
      @Override
      @Nullable
      public KeyEntity call() throws Exception {
        final Cursor _cursor = DBUtil.query(__db, _statement, false, null);
        try {
          final int _cursorIndexOfSerialNumber = CursorUtil.getColumnIndexOrThrow(_cursor, "serialNumber");
          final int _cursorIndexOfName = CursorUtil.getColumnIndexOrThrow(_cursor, "name");
          final int _cursorIndexOfOrganization = CursorUtil.getColumnIndexOrThrow(_cursor, "organization");
          final int _cursorIndexOfUid = CursorUtil.getColumnIndexOrThrow(_cursor, "uid");
          final int _cursorIndexOfTin = CursorUtil.getColumnIndexOrThrow(_cursor, "tin");
          final int _cursorIndexOfPinfl = CursorUtil.getColumnIndexOrThrow(_cursor, "pinfl");
          final int _cursorIndexOfValidFrom = CursorUtil.getColumnIndexOrThrow(_cursor, "validFrom");
          final int _cursorIndexOfValidTo = CursorUtil.getColumnIndexOrThrow(_cursor, "validTo");
          final int _cursorIndexOfValidNow = CursorUtil.getColumnIndexOrThrow(_cursor, "validNow");
          final int _cursorIndexOfQrData = CursorUtil.getColumnIndexOrThrow(_cursor, "qrData");
          final int _cursorIndexOfPassword = CursorUtil.getColumnIndexOrThrow(_cursor, "password");
          final int _cursorIndexOfKeyType = CursorUtil.getColumnIndexOrThrow(_cursor, "keyType");
          final int _cursorIndexOfIsDefault = CursorUtil.getColumnIndexOrThrow(_cursor, "isDefault");
          final KeyEntity _result;
          if (_cursor.moveToFirst()) {
            final String _tmpSerialNumber;
            _tmpSerialNumber = _cursor.getString(_cursorIndexOfSerialNumber);
            final String _tmpName;
            _tmpName = _cursor.getString(_cursorIndexOfName);
            final String _tmpOrganization;
            if (_cursor.isNull(_cursorIndexOfOrganization)) {
              _tmpOrganization = null;
            } else {
              _tmpOrganization = _cursor.getString(_cursorIndexOfOrganization);
            }
            final String _tmpUid;
            if (_cursor.isNull(_cursorIndexOfUid)) {
              _tmpUid = null;
            } else {
              _tmpUid = _cursor.getString(_cursorIndexOfUid);
            }
            final String _tmpTin;
            if (_cursor.isNull(_cursorIndexOfTin)) {
              _tmpTin = null;
            } else {
              _tmpTin = _cursor.getString(_cursorIndexOfTin);
            }
            final String _tmpPinfl;
            if (_cursor.isNull(_cursorIndexOfPinfl)) {
              _tmpPinfl = null;
            } else {
              _tmpPinfl = _cursor.getString(_cursorIndexOfPinfl);
            }
            final String _tmpValidFrom;
            _tmpValidFrom = _cursor.getString(_cursorIndexOfValidFrom);
            final String _tmpValidTo;
            _tmpValidTo = _cursor.getString(_cursorIndexOfValidTo);
            final boolean _tmpValidNow;
            final int _tmp;
            _tmp = _cursor.getInt(_cursorIndexOfValidNow);
            _tmpValidNow = _tmp != 0;
            final String _tmpQrData;
            _tmpQrData = _cursor.getString(_cursorIndexOfQrData);
            final String _tmpPassword;
            if (_cursor.isNull(_cursorIndexOfPassword)) {
              _tmpPassword = null;
            } else {
              _tmpPassword = _cursor.getString(_cursorIndexOfPassword);
            }
            final String _tmpKeyType;
            _tmpKeyType = _cursor.getString(_cursorIndexOfKeyType);
            final boolean _tmpIsDefault;
            final int _tmp_1;
            _tmp_1 = _cursor.getInt(_cursorIndexOfIsDefault);
            _tmpIsDefault = _tmp_1 != 0;
            _result = new KeyEntity(_tmpSerialNumber,_tmpName,_tmpOrganization,_tmpUid,_tmpTin,_tmpPinfl,_tmpValidFrom,_tmpValidTo,_tmpValidNow,_tmpQrData,_tmpPassword,_tmpKeyType,_tmpIsDefault);
          } else {
            _result = null;
          }
          return _result;
        } finally {
          _cursor.close();
          _statement.release();
        }
      }
    }, $completion);
  }

  @NonNull
  public static List<Class<?>> getRequiredConverters() {
    return Collections.emptyList();
  }
}
