package uz.eimzo.sdk.crypto

import java.math.BigInteger
import java.security.SecureRandom

// ─── EC Point ────────────────────────────────────────────────────────────────

internal data class EcPoint(val x: BigInteger, val y: BigInteger, val a: BigInteger, val p: BigInteger) {

    operator fun plus(other: EcPoint): EcPoint {
        var dy = other.y - y; if (dy < BigInteger.ZERO) dy += p
        var dx = other.x - x; if (dx < BigInteger.ZERO) dx += p
        var m = (dy * dx.modInverse(p)).mod(p)
        if (m < BigInteger.ZERO) m += p
        var rx = (m * m - x - other.x).mod(p); if (rx < BigInteger.ZERO) rx += p
        var ry = (m * (x - rx) - y).mod(p);    if (ry < BigInteger.ZERO) ry += p
        return EcPoint(rx, ry, a, p)
    }

    fun double(): EcPoint {
        var dy = x.pow(2) * BigInteger.valueOf(3) + a
        var dx = y * BigInteger.TWO
        if (dx < BigInteger.ZERO) dx += p
        if (dy < BigInteger.ZERO) dy += p
        var m = (dy * dx.modInverse(p)).mod(p)
        var rx = (m * m - x - x).mod(p); if (rx < BigInteger.ZERO) rx += p
        var ry = (m * (x - rx) - y).mod(p); if (ry < BigInteger.ZERO) ry += p
        return EcPoint(rx, ry, a, p)
    }

    operator fun times(k: BigInteger): EcPoint {
        var scalar = k - BigInteger.ONE
        var p = this
        var temp = this
        while (scalar != BigInteger.ZERO) {
            if (scalar.testBit(0)) {
                temp = if (temp.x == p.x || temp.y == p.y) temp.double() else p + temp
                scalar -= BigInteger.ONE
            }
            scalar = scalar.shiftRight(1)
            p = p.double()
        }
        return temp
    }
}

// ─── Curve Parameters ────────────────────────────────────────────────────────

internal class EcParameters(val p: BigInteger, val a: BigInteger, val b: BigInteger, val G: EcPoint, val n: BigInteger)

/** Full EC public key (8 hex strings) for pki.cert_info RPC. */
data class EcPublicKey(
    val p: String, val q: String, val a: String, val b: String,
    val gx: String, val gy: String, val qx: String, val qy: String
)

internal object OzDst1092Curves {

    val CURVE_A: EcParameters by lazy {
        val p = BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639319")
        val n = BigInteger("115792089237316195423570985008687907853073762908499243225378155805079068850323")
        val a = BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639316")
        val b = BigInteger("166")
        val gx = BigInteger.ONE
        val gy = BigInteger("64033881142927202683649881450433473985931760268884941288852745803908878638612")
        EcParameters(p, a, b, EcPoint(gx, gy, a, p), n)
    }

    val CURVE_B: EcParameters by lazy {
        val p = BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823193")
        val n = BigInteger("57896044618658097711785492504343953927102133160255826820068844496087732066703")
        val a = BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823190")
        val b = BigInteger("28091019353058090096996979000309560759124368558014865957655842872397301267595")
        val gx = BigInteger.ONE
        val gy = BigInteger("28792665814854611296992347458380284135028636778229113005756334730996303888124")
        EcParameters(p, a, b, EcPoint(gx, gy, a, p), n)
    }

    val CURVE_C: EcParameters by lazy {
        val p = BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502619")
        val n = BigInteger("70390085352083305199547718019018437840920882647164081035322601458352298396601")
        val a = BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502616")
        val b = BigInteger("32858")
        val gx = BigInteger.ZERO
        val gy = BigInteger("29818893917731240733471273240314769927240550812383695689146495261604565990247")
        EcParameters(p, a, b, EcPoint(gx, gy, a, p), n)
    }

    fun fromType(curveType: Int): EcParameters = when (curveType) {
        1 -> CURVE_A
        2 -> CURVE_B
        3 -> CURVE_C
        else -> throw IllegalArgumentException("Unknown QR key curve type: $curveType")
    }
}

// ─── QR Key Decrypt + Sign ───────────────────────────────────────────────────

internal object OzDst1092Signer {

    private const val KEY_ITERATIONS = 1000
    private val rng = SecureRandom()

    /** Decrypts QR bytes and returns (privateKeyBigInt, curve). */
    fun decryptQrKey(qrBytes: ByteArray, password: String): Pair<BigInteger, EcParameters> {
        require(qrBytes.size == 68) { "QR key must be 68 bytes, got ${qrBytes.size}" }
        require(qrBytes[0].toInt() and 0xFF == 0xE7) { "Bad QR key header byte 0" }
        require(qrBytes[1].toInt() and 0xFF == 0x31) { "Bad QR key header byte 1" }
        require(qrBytes[2].toInt() and 0xFF == 0x01) { "Bad QR key version" }

        val curve = OzDst1092Curves.fromType(qrBytes[3].toInt() and 0xFF)
        val encKey = deriveKey(password)

        val encContent = qrBytes.copyOfRange(4, 68)
        val decContent = decryptGost(encKey, encContent)

        val prvKeyBytes = decContent.copyOfRange(0, 32)
        val storedHash = decContent.copyOfRange(32, 64)
        val computedHash = ozDst1106Hash(prvKeyBytes)

        require(computedHash.contentEquals(storedHash)) { "Noto'g'ri parol" }

        val d = BigInteger(1, prvKeyBytes)
        return Pair(d, curve)
    }

    /** Returns (pubX hex, pubY hex) for certInfo API. */
    fun getPublicKey(qrBytes: ByteArray, password: String): Pair<String, String> {
        val (d, curve) = decryptQrKey(qrBytes, password)
        val Q = curve.G * d
        val x = Q.x.toString(16).padStart(64, '0')
        val y = Q.y.toString(16).padStart(64, '0')
        return Pair(x, y)
    }

    /** Returns all 8 EC curve parameters for pki.cert_info RPC call. */
    fun getFullPublicKey(qrBytes: ByteArray, password: String): EcPublicKey {
        val (d, curve) = decryptQrKey(qrBytes, password)
        val Q = curve.G * d
        return EcPublicKey(
            p = curve.p.toString(16),
            q = curve.n.toString(16),
            a = curve.a.toString(16),
            b = curve.b.toString(16),
            gx = curve.G.x.toString(16),
            gy = curve.G.y.toString(16),
            qx = Q.x.toString(16),
            qy = Q.y.toString(16)
        )
    }

    /**
     * Signs the OzDST 1106 hash of SignedAttributes (forward bytes — NOT reversed)
     * with the QR key's private key. Returns hex `s||r` (128 chars = 64 bytes).
     */
    fun sign(qrBytes: ByteArray, password: String, saHash: ByteArray): String {
        val (d, curve) = decryptQrKey(qrBytes, password)
        val n = curve.n
        val G = curve.G

        val z = BigInteger(1, saHash)
        var e = z.mod(n)
        if (e == BigInteger.ZERO) e = BigInteger.ONE

        val byteSize = (n.bitLength() + 7) / 8
        var r: BigInteger; var s: BigInteger
        do {
            var k: BigInteger
            do { k = BigInteger(byteSize * 8, rng).mod(n) } while (k <= BigInteger.ZERO || k >= n)
            val C = G * k
            r = C.x.mod(n)
            s = (r * d + k * e).mod(n)
        } while (r == BigInteger.ZERO || s == BigInteger.ZERO)

        return s.toString(16).padStart(64, '0') + r.toString(16).padStart(64, '0')
    }

    // ── helpers ──

    private fun deriveKey(password: String): ByteArray {
        val digest = OzDst1106Digest()
        var key: ByteArray = password.toByteArray(Charsets.UTF_8)
        val h = ByteArray(32)
        repeat(KEY_ITERATIONS) {
            digest.reset()
            digest.updateBuffer(key, 0, key.size)
            digest.doFinal(h, 0)
            key = h.copyOf()
        }
        return key
    }

    private fun decryptGost(key: ByteArray, enc: ByteArray): ByteArray {
        val engine = Gost28147Engine()
        engine.init(false, key)
        val out = ByteArray(enc.size)
        for (i in 0 until enc.size / Gost28147Engine.BLOCK_SIZE) {
            engine.processBlock(enc, i * Gost28147Engine.BLOCK_SIZE, out, i * Gost28147Engine.BLOCK_SIZE)
        }
        return out
    }

    private fun ozDst1106Hash(data: ByteArray): ByteArray {
        val digest = OzDst1106Digest()
        digest.update(data)
        val out = ByteArray(32)
        digest.doFinal(out, 0)
        return out
    }
}
