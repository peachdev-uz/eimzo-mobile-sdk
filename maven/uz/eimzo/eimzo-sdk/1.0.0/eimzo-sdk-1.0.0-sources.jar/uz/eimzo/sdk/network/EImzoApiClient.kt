package uz.eimzo.sdk.network

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class EImzoApiClient(private val apiUrl: String) {

    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private suspend fun <T> rpcCall(method: String, params: Any, type: Class<T>): T {
        val request = JsonRpcRequest(method = method, params = params)
        val body = gson.toJson(request).toRequestBody(jsonMediaType)
        val httpRequest = Request.Builder()
            .url(apiUrl)
            .header("User-Agent", "e-imzo-mobile")
            .header("Accept", "application/json")
            .post(body)
            .build()

        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val response = client.newCall(httpRequest).execute()
            val responseBody = response.body?.string() ?: throw Exception("Empty response")
            android.util.Log.i("EImzoApi", "$method response: $responseBody")
            val rpcType = TypeToken.getParameterized(JsonRpcResponse::class.java, type).type
            val rpcResponse: JsonRpcResponse<T> = gson.fromJson(responseBody, rpcType)
            rpcResponse.error?.let { err ->
                val msg = when {
                    err.isJsonObject -> {
                        val obj = err.asJsonObject
                        val code = obj.get("code")?.asString ?: "?"
                        val message = obj.get("message")?.asString ?: obj.toString()
                        "RPC Error $code: $message"
                    }
                    err.isJsonPrimitive -> err.asString
                    else -> err.toString()
                }
                throw Exception(msg)
            }
            rpcResponse.result ?: throw Exception("Null result from server")
        }
    }

    suspend fun certInfo(pubKey: uz.eimzo.sdk.crypto.EcPublicKey): CertInfoResult {
        return rpcCall(
            method = "pki.cert_info",
            params = CertInfoParams(
                p = pubKey.p, q = pubKey.q, a = pubKey.a, b = pubKey.b,
                gx = pubKey.gx, gy = pubKey.gy, qx = pubKey.qx, qy = pubKey.qy
            ),
            type = CertInfoResult::class.java
        )
    }

    suspend fun siteInfo(siteId: String): SiteInfoResult {
        return rpcCall(
            method = "pki.site_info",
            params = SiteInfoParams(siteId = siteId),
            type = SiteInfoResult::class.java
        )
    }

    suspend fun sendPkcs7(
        siteId: String,
        docId: String,
        hash: String,
        signature: String,
        serialNumber: String,
        timestamp: String
    ): Pkcs7Result {
        return rpcCall(
            method = "pki.send_pkcs7",
            params = SendPkcs7Params(
                siteId = siteId,
                docId = docId,
                hash = hash,
                signature = signature,
                serialNumber = serialNumber,
                timestamp = timestamp
            ),
            type = Pkcs7Result::class.java
        )
    }
}
