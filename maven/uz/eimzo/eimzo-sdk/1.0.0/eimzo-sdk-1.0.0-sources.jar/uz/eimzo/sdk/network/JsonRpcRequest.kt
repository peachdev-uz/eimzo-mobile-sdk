package uz.eimzo.sdk.network

import com.google.gson.JsonElement
import com.google.gson.annotations.SerializedName

data class JsonRpcRequest(
    @SerializedName("jsonrpc") val jsonrpc: String = "2.0",
    @SerializedName("method") val method: String,
    @SerializedName("params") val params: Any,
    @SerializedName("id") val id: String = System.currentTimeMillis().toString()
)

data class JsonRpcResponse<T>(
    @SerializedName("jsonrpc") val jsonrpc: String,
    @SerializedName("result") val result: T?,
    @SerializedName("error") val error: JsonElement?,
    @SerializedName("id") val id: String?
)
