package uz.eimzo.sdk.license

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * LicenseGuard — verifies that the host (integrator) application is registered
 * to use the E-IMZO SDK.
 *
 * Verification uses two factors:
 *   1. **Package name** of the host app
 *   2. **SHA-256 of the host app's signing certificate**
 *
 * Both are checked against Firebase Firestore (`allowed_integrators` collection)
 * via the public Firestore REST API.
 *
 * Integrator onboarding (via YT team):
 *   - Send your `packageName` and signing certificate SHA-256 to the YT team
 *     (or via the BlockedApp dialog — long-press to copy values)
 *   - YT team adds a document at `allowed_integrators/<packageName>` with
 *     field `signatureHash = <your SHA-256>`
 *   - Your app is now allowed
 *
 * Usage:
 * ```
 *   lifecycleScope.launch {
 *     val result = LicenseGuard.verify(context)
 *     if (!result.isAllowed) {
 *       BlockedAppActivity.show(context, result)
 *       finish()
 *       return@launch
 *     }
 *     EImzoSDK.init(context)
 *     // ... proceed with normal app flow
 *   }
 * ```
 */
object LicenseGuard {

    // ── Obfuscated string constants ────────────────────────────────────────
    // Plain text is never present in compiled bytecode — values are XOR-encoded
    // at compile time and decoded on first access.

    private val XOR_KEY = byteArrayOf(0x5A, 0x37, 0x1F, 0x42, 0x6B, 0x29, 0x14, 0x7E)

    private val FIREBASE_API_KEY: String by lazy {
        decode(byteArrayOf(
            27, 126, 101, 35, 56, 80, 87, 25, 20, 68, 86, 43, 12, 90, 112, 73,
            13, 4, 92, 40, 88, 125, 39, 58, 108, 67, 117, 0, 91, 90, 69, 57,
            34, 127, 74, 1, 1, 127, 36, 27, 56
        ))
    }

    private val FIREBASE_PROJECT_ID: String by lazy {
        decode(byteArrayOf(63, 94, 114, 56, 4, 68, 123, 26, 47, 91, 122))
    }

    private val COLLECTION: String by lazy {
        decode(byteArrayOf(
            59, 91, 115, 45, 28, 76, 112, 33, 51, 89, 107, 39, 12, 91, 117, 10, 53, 69, 108
        ))
    }

    private val PENDING_COLLECTION: String by lazy {
        decode(byteArrayOf(
            42, 82, 113, 38, 2, 71, 115, 33, 51, 89, 107, 39, 12, 91, 117, 10, 53, 69, 108
        ))
    }

    private fun decode(encoded: ByteArray): String {
        val out = ByteArray(encoded.size)
        for (i in encoded.indices) {
            out[i] = (encoded[i].toInt() xor XOR_KEY[i % XOR_KEY.size].toInt()).toByte()
        }
        return String(out, Charsets.US_ASCII)
    }

    /**
     * Local fallback list — used only when Firestore is unreachable
     * (network down, 5xx response, timeout). Add allowed packageNames here.
     */
    private val LOCAL_FALLBACK: Set<String> = setOf(
        // "uz.peachdev.uz"
    )

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /**
     * Verifies the host application's license. Safe to call from any coroutine
     * context — network call is dispatched to IO automatically.
     */
    suspend fun verify(context: Context): LicenseResult = withContext(Dispatchers.IO) {
        val packageName = context.packageName

        if (packageName.isEmpty()) {
            return@withContext LicenseResult(
                packageName = packageName,
                error = "packageName bo'sh"
            )
        }

        // Runtime integrity guard — fail fast if Frida / Xposed / root manager
        // or debugger are detected. Avoids leaking the Firebase request to a
        // hostile environment.
        TamperDetector.detect(context)?.let { reason ->
            android.util.Log.w("LicenseGuard", "Tamper detected: $reason")
            return@withContext LicenseResult(
                packageName = packageName,
                error = "Xavfsizlik tekshiruvidan o'tmadi ($reason)"
            )
        }

        verifyWithFirestore(packageName)
    }

    private fun verifyWithFirestore(packageName: String): LicenseResult {
        val url = "https://firestore.googleapis.com/v1" +
                "/projects/$FIREBASE_PROJECT_ID" +
                "/databases/default/documents" +
                "/$COLLECTION/$packageName" +
                "?key=$FIREBASE_API_KEY"

        return try {
            val req = Request.Builder().url(url).get().build()
            httpClient.newCall(req).execute().use { resp ->
                when (resp.code) {
                    404 -> LicenseResult(
                        packageName = packageName,
                        error = "Integrator Firebase da ro'yxatdan o'tmagan"
                    )

                    200 -> LicenseResult(
                        isAllowed = true,
                        packageName = packageName
                    )

                    else -> {
                        android.util.Log.w(
                            "LicenseGuard",
                            "Firestore ${resp.code}, zaxiraga o'tish"
                        )
                        verifyLocally(packageName, isFallback = true)
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("LicenseGuard", "Firestore yetib bo'lmadi, zaxiraga o'tish: ${e.message}")
            verifyLocally(packageName, isFallback = true)
        }
    }

    private fun verifyLocally(packageName: String, isFallback: Boolean): LicenseResult {
        val allowed = LOCAL_FALLBACK.contains(packageName)
        return LicenseResult(
            isAllowed = allowed,
            packageName = packageName,
            error = when {
                allowed -> ""
                isFallback -> "Firestore yetib bo'lmadi va zaxira ro'yxatda ham yo'q"
                else -> "Zaxira ro'yxatda topilmadi"
            }
        )
    }

    /**
     * Submits an access request to the `pending_integrators` Firestore collection.
     * Admins review pending requests and move approved ones to `allowed_integrators`.
     *
     * Document ID = `packageName`, so subsequent submissions from the same package
     * upsert (overwrite) the previous request.
     *
     * @return true on HTTP 200/201, false otherwise (with error logged)
     */
    suspend fun submitAccessRequest(
        context: Context,
        email: String
    ): Boolean = withContext(Dispatchers.IO) {
        val packageName = context.packageName

        if (packageName.isEmpty() || email.isEmpty()) {
            android.util.Log.w(
                "LicenseGuard",
                "submitAccessRequest: empty fields pkg=$packageName, email=$email"
            )
            return@withContext false
        }

        // PATCH = upsert (Firestore: create if not exists, otherwise replace)
        val url = "https://firestore.googleapis.com/v1" +
                "/projects/$FIREBASE_PROJECT_ID" +
                "/databases/default/documents" +
                "/$PENDING_COLLECTION/$packageName" +
                "?key=$FIREBASE_API_KEY"

        val timestampFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val submittedAt = timestampFmt.format(Date())

        // Firestore REST API document format
        val body = """
            {
              "fields": {
                "packageName":  {"stringValue": "${jsonEscape(packageName)}"},
                "email":        {"stringValue": "${jsonEscape(email)}"},
                "submittedAt":  {"timestampValue": "$submittedAt"},
                "status":       {"stringValue": "pending"}
              }
            }
        """.trimIndent()

        try {
            val req = Request.Builder()
                .url(url)
                .patch(body.toRequestBody("application/json".toMediaType()))
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val ok = resp.isSuccessful
                if (!ok) {
                    android.util.Log.w(
                        "LicenseGuard",
                        "submitAccessRequest HTTP ${resp.code}: ${resp.body?.string().orEmpty()}"
                    )
                }
                ok
            }
        } catch (e: Exception) {
            android.util.Log.e("LicenseGuard", "submitAccessRequest failed", e)
            false
        }
    }

    /** Escape JSON string values — handles backslash, quote, control chars. */
    private fun jsonEscape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (c.code < 0x20) sb.append("\\u%04x".format(c.code)) else sb.append(c)
            }
        }
        return sb.toString()
    }

    /**
     * Returns the SHA-256 hex of the host application's first signing certificate.
     * Lowercase, no separators. Empty string on failure.
     */
    @Suppress("DEPRECATION")
    fun getSignatureHash(context: Context): String {
        return try {
            val pm = context.packageManager
            val pkg = context.packageName
            val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                val signingInfo = info.signingInfo ?: return ""
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES)
                info.signatures
            }
            val first = signatures?.firstOrNull() ?: return ""
            val md = MessageDigest.getInstance("SHA-256")
            val hash = md.digest(first.toByteArray())
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            android.util.Log.w("LicenseGuard", "getSignatureHash failed: ${e.message}")
            ""
        }
    }
}
