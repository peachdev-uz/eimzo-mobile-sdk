package uz.eimzo.sdk.usb

import com.ftsafe.readerScheme.FTException
import com.ftsafe.readerScheme.FTReader
import uz.yt.idcard.applet.android.exception.CardException
import uz.yt.idcard.applet.android.smartcardio.CardChannel
import uz.yt.idcard.applet.android.smartcardio.CommandAPDU
import uz.yt.idcard.applet.android.smartcardio.ResponseAPDU

class FtCardChannel(
    private val reader: FTReader,
    private val slotIndex: Int
) : CardChannel {

    override fun transmit(command: CommandAPDU): ResponseAPDU {
        return try {
            val bytes = reader.readerXfr(slotIndex, command.getBytes())
            ResponseAPDU(bytes)
        } catch (e: FTException) {
            throw CardException(e)
        }
    }

    override fun close() {
        try {
            reader.readerClose()
        } catch (e: FTException) {
            throw CardException(e)
        }
    }
}
