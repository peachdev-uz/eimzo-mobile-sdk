package uz.eimzo.sdk

import android.content.Context
import android.nfc.Tag
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.eimzo.sdk.crypto.HexUtils
import uz.eimzo.sdk.crypto.PkiUtils
import uz.eimzo.sdk.crypto.QrCryptoManager
import uz.eimzo.sdk.license.BlockedAppActivity
import uz.eimzo.sdk.license.LicenseGuard
import uz.eimzo.sdk.license.LicenseResult
import uz.eimzo.sdk.models.CertInfo
import uz.eimzo.sdk.models.KeyType
import uz.eimzo.sdk.models.PfxKey
import uz.eimzo.sdk.models.QrHashData
import uz.eimzo.sdk.models.SignResult
import uz.eimzo.sdk.network.EImzoApiClient
import uz.eimzo.sdk.nfc.NfcManager
import uz.eimzo.sdk.storage.KeyDatabase
import uz.eimzo.sdk.storage.KeyEntity
import uz.eimzo.sdk.usb.UsbTokenManager

/**
 * E-IMZO Android SDK.
 *
 * Integrator usage:
 *
 *   // Initialize (once, in Application.onCreate)
 *   EImzoSDK.init(context, EImzoConfig(isTestMode = false))
 *
 *   // Import PFX key from file
 *   EImzoSDK.get().importPfxKey(pfxBytes, password, callback)
 *
 *   // Sign with QR key via deeplink
 *   EImzoSDK.get().signWithQrKey(key, deepLink, password, callback)
 *
 *   // Sign with NFC ID card
 *   EImzoSDK.get().signWithNfc(tag, pin, deepLink, callback)
 *
 *   // Sign with USB token
 *   EImzoSDK.get().signWithUsbToken(activity, pin, deepLink, callback)
 */
class EImzoSDK private constructor(
    private val context: Context,
    private val config: EImzoConfig
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val api = EImzoApiClient(config.apiUrl)
    private val db = KeyDatabase.getInstance(context)
    private val dao = db.keyDao()
    private val nfcManager = NfcManager()
    private val usbManager = UsbTokenManager(context)

    // ──────────────────────────────────────────────────────────────────
    // Key storage
    // ──────────────────────────────────────────────────────────────────

    fun getAllKeys(): Flow<List<PfxKey>> =
        dao.getAllKeys().map { list -> list.map { it.toPfxKey() } }

    suspend fun getAllKeysList(): List<PfxKey> =
        dao.getAllKeysList().map { it.toPfxKey() }

    suspend fun getDefaultKey(): PfxKey? = dao.getDefaultKey()?.toPfxKey()

    suspend fun setDefaultKey(serialNumber: String) = dao.setDefaultKey(serialNumber)

    suspend fun deleteKey(serialNumber: String) = dao.deleteKeyBySerial(serialNumber)

    // ──────────────────────────────────────────────────────────────────
    // Import QR/PFX key
    // ──────────────────────────────────────────────────────────────────

    fun importPfxKey(
        pfxBytes: ByteArray,
        password: String,
        savePassword: Boolean = true,
        callback: ImportKeyCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                android.util.Log.i("EImzoSDK", "importPfxKey: bytes=${pfxBytes.size}, savePassword=$savePassword")
                val qrHex = QrCryptoManager.pfxToQrHex(pfxBytes, password)
                android.util.Log.i("EImzoSDK", "  pfxToQrHex OK, qrHex len=${qrHex.length}")
                val pubKey = QrCryptoManager.getFullPublicKey(qrHex, password)
                android.util.Log.i("EImzoSDK", "  getFullPublicKey OK")
                val certInfo = api.certInfo(pubKey)
                android.util.Log.i("EImzoSDK", "  certInfo OK, serial=${certInfo.serialNumber}")

                if (dao.getKey(certInfo.serialNumber) != null) {
                    throw Exception("Bu kalit allaqachon mavjud")
                }

                val key = PfxKey(
                    serialNumber = certInfo.serialNumber,
                    name = certInfo.cn,
                    organization = certInfo.o,
                    uid = certInfo.uid,
                    tin = certInfo.tin,
                    pinfl = certInfo.pinfl,
                    validFrom = certInfo.validFrom,
                    validTo = certInfo.validTo,
                    validNow = certInfo.validNow,
                    qrData = qrHex,
                    password = if (savePassword) password else null,
                    keyType = KeyType.QR_PFX,
                    isDefault = dao.getAllKeysList().isEmpty()
                )
                dao.insertKey(KeyEntity.fromPfxKey(key))
                key
            }.fold(
                onSuccess = { key ->
                    launch(Dispatchers.Main) { callback.onSuccess(key) }
                },
                onFailure = { e ->
                    android.util.Log.e("EImzoSDK", "importPfxKey FAILED", e)
                    launch(Dispatchers.Main) { callback.onError(e.message ?: "Xatolik") }
                }
            )
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Import QR key (scanned from QR code)
    // ──────────────────────────────────────────────────────────────────

    fun importQrKey(
        qrHex: String,
        password: String,
        savePassword: Boolean = true,
        callback: ImportKeyCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                android.util.Log.i("EImzoSDK", "importQrKey: qrHex len=${qrHex.length}, savePassword=$savePassword")

                // Validate QR format: must be 136 hex chars starting with E73101
                val normalized = qrHex.trim().lowercase()
                require(normalized.length == 136) {
                    "Noto'g'ri QR formati: uzunlik ${normalized.length}, 136 belgi kerak"
                }
                require(normalized.startsWith("e73101")) {
                    "Noto'g'ri QR formati: sarlavha mos kelmaydi"
                }
                require(normalized.all { it in "0123456789abcdef" }) {
                    "Noto'g'ri QR formati: hex emas"
                }

                val pubKey = QrCryptoManager.getFullPublicKey(normalized, password)
                android.util.Log.i("EImzoSDK", "  getFullPublicKey OK")
                val certInfo = api.certInfo(pubKey)
                android.util.Log.i("EImzoSDK", "  certInfo OK, serial=${certInfo.serialNumber}")

                if (dao.getKey(certInfo.serialNumber) != null) {
                    throw Exception("Bu kalit allaqachon mavjud")
                }

                val key = PfxKey(
                    serialNumber = certInfo.serialNumber,
                    name = certInfo.cn,
                    organization = certInfo.o,
                    uid = certInfo.uid,
                    tin = certInfo.tin,
                    pinfl = certInfo.pinfl,
                    validFrom = certInfo.validFrom,
                    validTo = certInfo.validTo,
                    validNow = certInfo.validNow,
                    qrData = normalized,
                    password = if (savePassword) password else null,
                    keyType = KeyType.QR_PFX,
                    isDefault = dao.getAllKeysList().isEmpty()
                )
                dao.insertKey(KeyEntity.fromPfxKey(key))
                key
            }.fold(
                onSuccess = { key ->
                    launch(Dispatchers.Main) { callback.onSuccess(key) }
                },
                onFailure = { e ->
                    android.util.Log.e("EImzoSDK", "importQrKey FAILED", e)
                    launch(Dispatchers.Main) { callback.onError(e.message ?: "Xatolik") }
                }
            )
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Import NFC ID card key
    // ──────────────────────────────────────────────────────────────────

    fun importNfcKey(
        tag: Tag,
        pin: String,
        savePassword: Boolean = true,
        callback: ImportKeyCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                val cardInfo = nfcManager.readCardInfo(tag)
                    ?: throw Exception("Kartani o'qib bo'lmadi")

                if (dao.getKey(cardInfo.serialNumber) != null) {
                    throw Exception("Bu kalit allaqachon mavjud")
                }

                val (name, pinfl) = parseX500Name(cardInfo.x500Name)
                val (validFrom, validTo) = parseValidity(cardInfo.validity)

                val key = PfxKey(
                    serialNumber = cardInfo.serialNumber,
                    name = name,
                    organization = null,
                    uid = "Mavjud emas",
                    tin = null,
                    pinfl = pinfl,
                    validFrom = validFrom,
                    validTo = validTo,
                    validNow = true,
                    qrData = cardInfo.hardwareUid,
                    password = if (savePassword) pin else null,
                    keyType = KeyType.NFC_ID,
                    isDefault = dao.getAllKeysList().isEmpty()
                )
                dao.insertKey(KeyEntity.fromPfxKey(key))
                key
            }.fold(
                onSuccess = { key ->
                    launch(Dispatchers.Main) { callback.onSuccess(key) }
                },
                onFailure = { e ->
                    launch(Dispatchers.Main) { callback.onError(e.message ?: "Xatolik") }
                }
            )
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Sign with QR/PFX key
    // ──────────────────────────────────────────────────────────────────

    fun signWithQrKey(
        key: PfxKey,
        deepLink: String,
        password: String?,
        callback: SignCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                android.util.Log.i("EImzoSDK", "signWithQrKey: deepLink=$deepLink")
                val qrHash = QrHashData.fromDeepLink(deepLink)
                    ?: throw Exception("Deeplink noto'g'ri format: '$deepLink'")
                android.util.Log.i("EImzoSDK", "  parsed: siteId=${qrHash.siteId}, docId=${qrHash.docId}, hashLen=${qrHash.hash.length}")
                signQrKeyInternal(key, qrHash, password ?: key.password ?: "", callback)
            }.onFailure { e ->
                android.util.Log.e("EImzoSDK", "signWithQrKey FAILED", e)
                launch(Dispatchers.Main) {
                    callback.onError(SignResult.Failure(e.message ?: "Xatolik"))
                }
            }
        }
    }

    fun signWithQrKey(
        key: PfxKey,
        qrHash: QrHashData,
        password: String?,
        callback: SignCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                signQrKeyInternal(key, qrHash, password ?: key.password ?: "", callback)
            }.onFailure { e ->
                launch(Dispatchers.Main) {
                    callback.onError(SignResult.Failure(e.message ?: "Xatolik"))
                }
            }
        }
    }

    private suspend fun signQrKeyInternal(
        key: PfxKey,
        qrHash: QrHashData,
        password: String,
        callback: SignCallback
    ) {
        android.util.Log.i("EImzoSDK", "signQrKeyInternal: siteId=${qrHash.siteId}")
        val siteInfo = api.siteInfo(qrHash.siteId)
        android.util.Log.i("EImzoSDK", "  siteInfo state=${siteInfo.state}, domain=${siteInfo.domainName}")
        if (siteInfo.state != "site") {
            throw Exception("Sayt ro'yxatdan o'tmagan: ${qrHash.siteId} (state=${siteInfo.state})")
        }

        val sah = PkiUtils.buildSignedAttributesAndHash(qrHash.hash)
        val signedAttrs = sah[0]
        val saHash = sah[1]
        // Reverse hash bytes before signing — matches Flutter's signIn flow:
        //   var saHashRev = sah[1].reversed.toList();
        //   signature = privateKey.generateSignature(rng, Hex.fromBytes(saHashRev));
        val saHashRev = saHash.reversedArray()
        val timestamp = String(sah[2], Charsets.US_ASCII)
        android.util.Log.i("EImzoSDK", "  PKI: timestamp=$timestamp")
        android.util.Log.i("EImzoSDK", "  PKI: saHash    =${HexUtils.toHex(saHash)}")
        android.util.Log.i("EImzoSDK", "  PKI: saHashRev =${HexUtils.toHex(saHashRev)}")

        val pubKey = QrCryptoManager.getFullPublicKey(key.qrData, password)
        val certInfo = api.certInfo(pubKey)
        android.util.Log.i("EImzoSDK", "  certInfo OK, serial=${certInfo.serialNumber}, state=${certInfo.state}")

        val signature = QrCryptoManager.sign(key.qrData, password, saHashRev)
        android.util.Log.i("EImzoSDK", "  signature(${signature.length})=$signature")

        val result = api.sendPkcs7(
            siteId = qrHash.siteId,
            docId = qrHash.docId,
            hash = qrHash.hash,
            signature = signature,
            serialNumber = certInfo.serialNumber,
            timestamp = timestamp
        )
        android.util.Log.i("EImzoSDK", "  sendPkcs7 OK: state=${result.state}, msg=${result.message}")

        // Server may respond with state="signature.invalid" or similar without throwing.
        // Treat anything other than "success"/"signature.valid" as a failure.
        if (result.state.contains("invalid", ignoreCase = true) ||
            result.state.contains("error", ignoreCase = true)
        ) {
            throw Exception("Imzolash rad etildi: ${result.state}")
        }

        withContext(Dispatchers.Main) {
            callback.onSuccess(SignResult.Success(result.state, result.message))
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Sign with NFC ID card
    // ──────────────────────────────────────────────────────────────────

    fun signWithNfc(
        tag: Tag,
        pin: String,
        deepLink: String,
        callback: SignCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                val qrHash = QrHashData.fromDeepLink(deepLink)
                    ?: throw Exception("Deeplink noto'g'ri format")

                val siteInfo = api.siteInfo(qrHash.siteId)
                if (siteInfo.state != "site") {
                    throw Exception("Sayt ro'yxatdan o'tmagan: ${qrHash.siteId}")
                }

                val sah = PkiUtils.buildSignedAttributesAndHash(qrHash.hash)
                val saHashRev = sah[1]
                val timestamp = String(sah[2], Charsets.US_ASCII)

                val signature = nfcManager.signWithNfc(tag, pin, saHashRev)

                // Get serial number from stored key or read from card
                val storedKey = dao.getAllKeysList()
                    .firstOrNull { it.keyType == KeyType.NFC_ID.name }
                val serialNumber = storedKey?.serialNumber ?: ""

                val result = api.sendPkcs7(
                    siteId = qrHash.siteId,
                    docId = qrHash.docId,
                    hash = qrHash.hash,
                    signature = signature,
                    serialNumber = serialNumber,
                    timestamp = timestamp
                )

                launch(Dispatchers.Main) {
                    callback.onSuccess(SignResult.Success(result.state, result.message))
                }
            }.onFailure { e ->
                launch(Dispatchers.Main) {
                    callback.onError(SignResult.Failure(e.message ?: "Xatolik"))
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Sign with USB token
    // ──────────────────────────────────────────────────────────────────

    fun signWithUsbToken(
        pin: String,
        deepLink: String,
        callback: SignCallback
    ) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                val qrHash = QrHashData.fromDeepLink(deepLink)
                    ?: throw Exception("Deeplink noto'g'ri format")

                val siteInfo = api.siteInfo(qrHash.siteId)
                if (siteInfo.state != "site") {
                    throw Exception("Sayt ro'yxatdan o'tmagan: ${qrHash.siteId}")
                }

                val sah = PkiUtils.buildSignedAttributesAndHash(qrHash.hash)
                val saHashRev = sah[1]
                val timestamp = String(sah[2], Charsets.US_ASCII)

                val usbResult = usbManager.sign(saHashRev, pin)

                val result = api.sendPkcs7(
                    siteId = qrHash.siteId,
                    docId = qrHash.docId,
                    hash = qrHash.hash,
                    signature = usbResult.signature,
                    serialNumber = usbResult.serialNumber,
                    timestamp = timestamp
                )

                launch(Dispatchers.Main) {
                    callback.onSuccess(SignResult.Success(result.state, result.message))
                }
            }.onFailure { e ->
                launch(Dispatchers.Main) {
                    val isPinError = e.message?.startsWith("PIN_ERROR") == true
                    callback.onError(
                        SignResult.Failure(
                            error = if (isPinError) "Noto'g'ri parol" else (e.message ?: "Xatolik"),
                            code = if (isPinError) "401" else null
                        )
                    )
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Certificate info
    // ──────────────────────────────────────────────────────────────────

    fun getCertInfo(key: PfxKey, password: String, callback: CertInfoCallback) {
        scope.launch(Dispatchers.IO) {
            runCatching {
                val pubKey = QrCryptoManager.getFullPublicKey(key.qrData, password)
                val result = api.certInfo(pubKey)
                CertInfo(
                    serialNumber = result.serialNumber,
                    cn = result.cn,
                    o = result.o,
                    uid = result.uid,
                    tin = result.tin,
                    pinfl = result.pinfl,
                    validFrom = result.validFrom,
                    validTo = result.validTo,
                    validNow = result.validNow,
                    state = result.state
                )
            }.fold(
                onSuccess = { info -> launch(Dispatchers.Main) { callback.onSuccess(info) } },
                onFailure = { e -> launch(Dispatchers.Main) { callback.onError(e.message ?: "Xatolik") } }
            )
        }
    }

    // ──────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────

    private fun parseX500Name(x500Name: String): Pair<String, String> {
        var name = ""
        var pinfl = ""
        x500Name.split(",").forEach { part ->
            when {
                part.startsWith("CN=") -> name = part.removePrefix("CN=")
                part.startsWith("1.2.860.3.16.1.2=") -> pinfl = part.removePrefix("1.2.860.3.16.1.2=")
            }
        }
        return Pair(name, pinfl)
    }

    private fun parseValidity(validity: String): Pair<String, String> {
        if (validity.length < 28) return Pair("Не указано", "Не указано")
        return try {
            val start = validity.substring(0, 14)
            val end = validity.substring(14, 28)
            Pair(formatValidityDate(start), formatValidityDate(end))
        } catch (e: Exception) {
            Pair("Не указано", "Не указано")
        }
    }

    private fun formatValidityDate(raw: String): String {
        return try {
            val withT = raw.substring(0, 8) + "T" + raw.substring(8)
            val sdf = java.text.SimpleDateFormat("yyyyMMdd'T'HHmmss", java.util.Locale.US)
            val outSdf = java.text.SimpleDateFormat("yyyy.MM.dd HH:mm:ss", java.util.Locale.US)
            outSdf.format(sdf.parse(withT)!!)
        } catch (e: Exception) {
            raw
        }
    }

    fun release() {
        usbManager.release()
    }

    // ──────────────────────────────────────────────────────────────────
    // Singleton
    // ──────────────────────────────────────────────────────────────────

    companion object {
        @Volatile private var instance: EImzoSDK? = null

        /** Self-test: hashes "abc" with OzDST 1106 and logs result vs expected. */
        private fun selfTestHash() {
            val expected = "b285056dbf18d7392d7677369524dd14747459ed8143997e163b2986f92fd42c"
            val digest = uz.eimzo.sdk.crypto.OzDst1106Digest()
            digest.update("abc".toByteArray())
            val out = ByteArray(32)
            digest.doFinal(out, 0)
            val actual = uz.eimzo.sdk.crypto.HexUtils.toHex(out).lowercase()
            val ok = actual == expected
            if (ok) {
                android.util.Log.i("EImzoSDK", "OzDST1106 self-test PASSED: hash(\"abc\")=$actual")
            } else {
                android.util.Log.e("EImzoSDK", "OzDST1106 self-test FAILED:\n  got     =$actual\n  expected=$expected")
            }
        }

        /**
         * EC math self-test using the OzDST 1092:2009 standard test vector.
         * Verifies that Q = G*d and that sign with fixed k produces expected r, s.
         */
        private fun selfTestEcMath() {
            try {
                val p = java.math.BigInteger("8000000000000000000000000000000000000000000000000000000000000431", 16)
                val a = java.math.BigInteger("7", 16)
                val n = java.math.BigInteger("8000000000000000000000000000000150FE8A1892976154C59CFC193ACCF5B3", 16)
                val gx = java.math.BigInteger("2", 16)
                val gy = java.math.BigInteger("8E2A8A0E65147D4BD6316030E16D19C85C97F0A9CA267122B96ABBCEA7E8FC8", 16)
                val d = java.math.BigInteger("7A929ADE789BB9BE10ED359DD39A72C11B60961F49397EEE1D19CE9891EC3B28", 16)
                val k = java.math.BigInteger("77105C9B20BCD3122823C8CF6FCC7B956DE33814E95B7FE64FED924594DCEAB3", 16)
                val hash = java.math.BigInteger("2DFBC1B372D89A1188C09C52E0EEC61FCE52032AB1022E8E67ECE6672B043EE5", 16)
                val expQx = "7F2B49E270DB6D90D8595BEC458B50C58585BA1D4E9B788F6689DBD8E56FD80B"
                val expQy = "26F1B489D6701DD185C8413A977B3CBBAF64D1C593D26627DFFB101A87FF77DA"
                val expR = "41AA28D2F1AB148280CD9ED56FEDA41974053554A42767B83AD043FD39DC0493"
                val expS = "01456C64BA4642A1653C235A98A60249BCD6D3F746B631DF928014F6C5BF9C40"

                val gPoint = uz.eimzo.sdk.crypto.EcPoint(gx, gy, a, p)
                val q = gPoint * d
                val qxHex = q.x.toString(16).uppercase().padStart(64, '0')
                val qyHex = q.y.toString(16).uppercase().padStart(64, '0')
                val qOk = qxHex == expQx && qyHex == expQy
                if (!qOk) {
                    android.util.Log.e("EImzoSDK", "EC self-test Q=G*d FAILED:")
                    android.util.Log.e("EImzoSDK", "  got Qx=$qxHex")
                    android.util.Log.e("EImzoSDK", "  exp Qx=$expQx")
                    android.util.Log.e("EImzoSDK", "  got Qy=$qyHex")
                    android.util.Log.e("EImzoSDK", "  exp Qy=$expQy")
                    return
                }
                android.util.Log.i("EImzoSDK", "EC self-test Q=G*d PASSED")

                // Sign math: e = hash mod n; C = k*G; r = C.x mod n; s = (r*d + k*e) mod n
                var e = hash.mod(n)
                if (e == java.math.BigInteger.ZERO) e = java.math.BigInteger.ONE
                val c = gPoint * k
                val r = c.x.mod(n)
                val s = (r * d + k * e).mod(n)
                val rHex = r.toString(16).uppercase().padStart(64, '0')
                val sHex = s.toString(16).uppercase().padStart(64, '0')
                val sigOk = rHex == expR && sHex == expS
                if (sigOk) {
                    android.util.Log.i("EImzoSDK", "EC self-test sign PASSED: r=$rHex, s=$sHex")
                } else {
                    android.util.Log.e("EImzoSDK", "EC self-test sign FAILED:")
                    android.util.Log.e("EImzoSDK", "  got r=$rHex")
                    android.util.Log.e("EImzoSDK", "  exp r=$expR")
                    android.util.Log.e("EImzoSDK", "  got s=$sHex")
                    android.util.Log.e("EImzoSDK", "  exp s=$expS")
                }
            } catch (e: Exception) {
                android.util.Log.e("EImzoSDK", "EC self-test exception", e)
            }
        }

        fun init(context: Context, config: EImzoConfig = EImzoConfig()) {
            instance ?: synchronized(this) {
                instance ?: EImzoSDK(context.applicationContext, config).also {
                    instance = it
                    selfTestHash()
                    selfTestEcMath()
                }
            }
        }

        fun get(): EImzoSDK = checkNotNull(instance) {
            "EImzoSDK.init(context) ni chaqiring"
        }

        /**
         * License-gated SDK initializer. Call this from the integrator's
         * Activity.onCreate before any other SDK usage:
         *
         * ```
         * EImzoSDK.checkLicenseAndInit(this, EImzoConfig()) { allowed ->
         *   if (!allowed) return@checkLicenseAndInit  // BlockedAppActivity shown
         *   // proceed with normal app flow
         * }
         * ```
         *
         * If the host app is not registered, [BlockedAppActivity] is launched
         * automatically and `onResult(false)` is invoked.
         */
        fun checkLicenseAndInit(
            activity: android.app.Activity,
            config: EImzoConfig = EImzoConfig(),
            onResult: (allowed: Boolean) -> Unit
        ) {
            val scope = kotlinx.coroutines.CoroutineScope(
                kotlinx.coroutines.SupervisorJob() + Dispatchers.Main
            )
            scope.launch {
                val result: LicenseResult = LicenseGuard.verify(activity)
                if (result.isAllowed) {
                    init(activity, config)
                    onResult(true)
                } else {
                    BlockedAppActivity.show(activity, result)
                    activity.finish()
                    onResult(false)
                }
            }
        }
    }
}
