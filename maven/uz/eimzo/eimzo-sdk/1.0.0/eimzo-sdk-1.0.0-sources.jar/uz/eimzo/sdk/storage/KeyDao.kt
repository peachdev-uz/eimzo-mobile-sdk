package uz.eimzo.sdk.storage

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KeyDao {

    @Query("SELECT * FROM keys ORDER BY isDefault DESC, name ASC")
    fun getAllKeys(): Flow<List<KeyEntity>>

    @Query("SELECT * FROM keys ORDER BY isDefault DESC, name ASC")
    suspend fun getAllKeysList(): List<KeyEntity>

    @Query("SELECT * FROM keys WHERE serialNumber = :serialNumber")
    suspend fun getKey(serialNumber: String): KeyEntity?

    @Query("SELECT * FROM keys WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultKey(): KeyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKey(key: KeyEntity)

    @Delete
    suspend fun deleteKey(key: KeyEntity)

    @Query("DELETE FROM keys WHERE serialNumber = :serialNumber")
    suspend fun deleteKeyBySerial(serialNumber: String)

    @Query("UPDATE keys SET isDefault = 0")
    suspend fun clearAllDefaults()

    @Query("UPDATE keys SET isDefault = 1 WHERE serialNumber = :serialNumber")
    suspend fun setDefault(serialNumber: String)

    @Transaction
    suspend fun setDefaultKey(serialNumber: String) {
        clearAllDefaults()
        setDefault(serialNumber)
    }
}
